"""
Termos oficiais do modelo Hydros.

Este arquivo centraliza a terminologia, as fórmulas operacionais,
os agentes, as evidências, os modos de execução e os parâmetros
iniciais usados pelo protótipo.

A arquitetura do Hydros é híbrida e orientada por princípios de
Inteligência Artificial Agêntica. O modelo determina ações de manejo hídrico,
mas não aciona fisicamente equipamentos de irrigação.
"""

# -----------------------------------------------------------------------------
# Identificação do modelo
# -----------------------------------------------------------------------------

MODELO = "Hydros"
VERSAO_ARQUITETURA = "0.4.1-qualificacao-final"

DESCRICAO_ARQUITETURA = (
    "Arquitetura híbrida orientada por princípios de Inteligência Artificial "
    "Agêntica, com agentes especializados, memória temporal, integração de "
    "evidências, regras agronômicas, inferências semânticas e aprendizado "
    "supervisionado."
)

# -----------------------------------------------------------------------------
# Estrutura formal do contexto
# -----------------------------------------------------------------------------

ESTRUTURA_CONTEXTO = {
    "unidade_manejo": "Uᵢ",
    "historico_contexto": "H(Uᵢ)",
    "contexto_temporal": "C(t)",
    "vetor_atributos": "Xₜ",
    "acao_manejo": "D(Uᵢ,t)",
}

FORMULAS = {
    "historico_contexto": "H(Uᵢ) = {C(t₁), C(t₂), ..., C(tₙ)}",
    "contexto_agricola": (
        "C(t) = {loc, solo, cult, p, temp, gd, et, kc, us, ad, "
        "irr, ef, eh, prod}"
    ),
    "estresse_hidrico": "EH = f(solo, ef, kc, ad, us, et)",
    "evidencia_agente": "Eⱼ(t) = Aⱼ(C(t), H(Uᵢ))",
    "conjunto_evidencias": (
        "E(t) = {Eclim, Ehid, Efen, Egeo, Eprod, Ehist}"
    ),
    "qualidade_evidencia": "Qⱼ = completudeⱼ × confiancaⱼ",
    "evidencia_contextual": (
        "Ehc = Σ(wⱼ × Qⱼ × V(Eⱼ)) / Σ(wⱼ × Qⱼ)"
    ),
    "vetor_aps": "Xₜ = F(C(t), H(Uᵢ))",
    "evidencia_aps": "Eaps = M(Xₜ)",
    "evidencia_arg": "Earg = ARG(Xₜ, R)",
    "score_amdh": (
        "S(d) = whc×Shc(d) + warg×Sarg(d) + "
        "waps×Saps(d) - Pconflito(d)"
    ),
    "acao_amdh": "D(Uᵢ,t) = argmax_d S(d)",
}

# -----------------------------------------------------------------------------
# Modos de execução usados no experimento
# -----------------------------------------------------------------------------

MODOS_EXECUCAO = {
    "historico": "Hydros Histórico: utiliza C(t) e H(Uᵢ)",
    "sem_historico": "Hydros sem Histórico: utiliza somente C(t)",
}

MODO_EXECUCAO_PADRAO = "historico"

# Inferência do APS trabalha com uma observação por chamada. Para Random Forest,
# usar um único worker evita o custo de criação repetida de pools paralelos e
# torna os experimentos mais estáveis, sem alterar árvores, probabilidades ou
# previsões do modelo já treinado.
APS_N_JOBS_INFERENCIA = 1

# -----------------------------------------------------------------------------
# Configuração da memória temporal
# -----------------------------------------------------------------------------

# Número de contextos recentes usado por padrão nos cálculos de janela do
# Hydros. O valor pode ser alterado na criação do HydrosEngine sem modificar
# o código dos agentes. A janela representa Wt na formulação Xt = F(H(Ui), Wt).
TAMANHO_JANELA_HISTORICA_PADRAO = 5


def validar_tamanho_janela_historica(valor):
    """Valida e normaliza o número de contextos da janela temporal."""

    if isinstance(valor, bool):
        raise ValueError("O tamanho da janela histórica deve ser um inteiro positivo.")

    try:
        tamanho = int(valor)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            "O tamanho da janela histórica deve ser um inteiro positivo."
        ) from exc

    if tamanho < 1:
        raise ValueError("O tamanho da janela histórica deve ser maior ou igual a 1.")

    return tamanho

# -----------------------------------------------------------------------------
# Agentes e evidências
# -----------------------------------------------------------------------------

AGENTES_CENTRAIS = {
    "AIEC": "Agente Integrador de Evidências Contextuais",
    "ARG": "Agente de Regras Agronômicas",
    "APS": "Agente Preditivo Supervisionado",
    "AMDH": "Agente Motor de Decisão Híbrido",
}

CAMADA_AHC = {
    "AHC": "Agentes de Histórico de Contexto",
}

AGENTES_ESPECIALIZADOS = {
    "Aclim": "Agente Climático",
    "Ahid": "Agente Hídrico",
    "Afen": "Agente Fenológico",
    "Ageo": "Agente Geográfico",
    "Aprod": "Agente Produtivo",
    "Ahist": "Agente Histórico-Contextual",
}

EVIDENCIAS_ESPECIALIZADAS = {
    "Eclim": "Evidência climática",
    "Ehid": "Evidência hídrica",
    "Efen": "Evidência fenológica",
    "Egeo": "Evidência geográfica",
    "Eprod": "Evidência produtiva",
    "Ehist": "Evidência histórico-contextual",
}

EVIDENCIAS_PRINCIPAIS = {
    "Ehc": "Evidência contextual consolidada",
    "Earg": "Evidência agronômica",
    "Eaps": "Evidência preditiva supervisionada",
}

# -----------------------------------------------------------------------------
# Condições hídricas e ações de manejo
# -----------------------------------------------------------------------------

CONDICOES_HIDRICAS = [
    "adequada",
    "atencao",
    "critica",
]

# Alias mantido apenas para compatibilidade com módulos legados.
NIVEIS_CRITICIDADE = list(CONDICOES_HIDRICAS)

# Escala operacional de três níveis usada por AIEC, ARG, APS e AMDH.
# Aliases antigos são aceitos somente na fronteira de compatibilidade.
FUNCAO_V = {
    "adequada": 1,
    "atencao": 2,
    "critica": 3,
    "baixo": 1,
    "moderado": 2,
    "alto": 2,
    "critico": 3,
}

CLASSES_DECISAO = [
    "iniciar_irrigacao",
    "manter_irrigacao",
    "aumentar_irrigacao",
    "reduzir_irrigacao",
    "finalizar_irrigacao",
]

DESCRICOES_DECISAO = {
    "iniciar_irrigacao": "Iniciar irrigação",
    "manter_irrigacao": "Manter irrigação",
    "aumentar_irrigacao": "Aumentar irrigação",
    "reduzir_irrigacao": "Reduzir irrigação",
    "finalizar_irrigacao": "Finalizar irrigação",
}

# Perfil de condição hídrica que oferece maior suporte a cada ação.
# Os valores usam a escala operacional adequada=1, atenção=2 e crítica=3.
ALVOS_CRITICIDADE_ACAO = {
    "finalizar_irrigacao": 1.00,
    "reduzir_irrigacao": 1.45,
    "manter_irrigacao": 1.90,
    "iniciar_irrigacao": 2.55,
    "aumentar_irrigacao": 3.00,
}

# Sobrescritas dependentes do estado operacional. Quando a irrigação está
# inativa, ``manter_irrigacao`` significa manter a ausência de aplicação e
# deve representar uma condição adequada, não a condição de atenção usada
# para manter uma irrigação já ativa. O alvo de ``iniciar_irrigacao`` é
# preservado; somente a semântica de ``manter`` é corrigida por estado.
ALVOS_CRITICIDADE_ACAO_POR_ESTADO = {
    "inativa": {
        "manter_irrigacao": 1.00,
        "iniciar_irrigacao": 2.55,
    },
}

# Penalização aplicada aos escores das ações diante de conflito.
# Ações que alteram o manejo recebem penalização ligeiramente maior
# que a manutenção do estado atual.
PENALIDADES_CONFLITO_ACAO = {
    "finalizar_irrigacao": 0.04,
    "reduzir_irrigacao": 0.03,
    "manter_irrigacao": 0.01,
    "iniciar_irrigacao": 0.04,
    "aumentar_irrigacao": 0.05,
}

ACOES_VALIDAS_POR_ESTADO = {
    "ativa": [
        "finalizar_irrigacao",
        "reduzir_irrigacao",
        "manter_irrigacao",
        "aumentar_irrigacao",
    ],
    "inativa": [
        "manter_irrigacao",
        "iniciar_irrigacao",
    ],
    "desconhecida": list(CLASSES_DECISAO),
}

# Prioridade usada somente em empates numéricos. O comportamento conservador
# prioriza manter o estado atual antes de alterar o manejo.
ORDEM_DESEMPATE_ACOES = [
    "manter_irrigacao",
    "iniciar_irrigacao",
    "aumentar_irrigacao",
    "reduzir_irrigacao",
    "finalizar_irrigacao",
]

# -----------------------------------------------------------------------------
# Variáveis do contexto
# -----------------------------------------------------------------------------

VARIAVEIS_MODELO = {
    "loc": "Localização geográfica",
    "solo": "Tipo de solo",
    "p": "Precipitação",
    "temp": "Temperatura média",
    "gd": "Soma térmica acumulada",
    "et": "Evapotranspiração",
    "kc": "Coeficiente de cultura",
    "us": "Umidade do solo",
    "ad": "Água disponível no solo",
    "irr": "Irrigação aplicada",
    "ef": "Estágio fenológico",
    "eh": "Estresse hídrico",
    "prod": "Produtividade estimada",
}

VARIAVEIS_ADICIONAIS_SOFTWARE = {
    "cultura": "Cultura agrícola analisada",
}

MAPEAMENTO_CSV_MODELO = {
    "loc": "loc",
    "solo": "solo",
    "p": "precipitacao",
    "temp": "temperatura",
    "gd": "soma_termica_acumulada",
    "et": "evapotranspiracao",
    "kc": "coeficiente_cultura",
    "us": "umidade_solo",
    "ad": "agua_disponivel",
    "irr": "irrigacao_aplicada",
    "ef": "estagio_fenologico",
    "eh": "estresse_hidrico",
    "prod": "produtividade",
    "cultura": "cultura",
}

# -----------------------------------------------------------------------------
# Regras e pesos do ARG
# -----------------------------------------------------------------------------

REGRAS_ARG = {
    "r1": "Avalia a precipitação recente ou acumulada",
    "r2": "Avalia a disponibilidade de água no solo",
    "r3": "Avalia a umidade do solo",
    "r4": "Avalia o estágio fenológico e o coeficiente de cultura",
    "r5": (
        "Avalia a evapotranspiração e a tendência de redução "
        "da água disponível"
    ),
    "r6": "Avalia a ocorrência de estresse hídrico",
    "r7": "Avalia os efeitos da irrigação aplicada anteriormente",
    "r8": (
        "Avalia a tendência histórica da condição hídrica "
        "da unidade de manejo"
    ),
}

PESOS_REGRAS_ARG = {
    "wr1": 0.12,
    "wr2": 0.16,
    "wr3": 0.16,
    "wr4": 0.14,
    "wr5": 0.14,
    "wr6": 0.14,
    "wr7": 0.07,
    "wr8": 0.07,
}

# Limiares operacionais preservados da versão 0.4.0. A centralização neste
# dicionário não altera os valores nem constitui nova calibração agronômica.
# O objetivo é evitar números dispersos no código e permitir auditoria,
# documentação e futura fundamentação de cada parâmetro.
LIMIARES_AGENTES = {
    "Aclim": {
        "precipitacao_muito_baixa": 5.0,
        "precipitacao_moderada": 15.0,
        "evapotranspiracao_elevada": 6.5,
        "evapotranspiracao_moderada": 5.5,
        "temperatura_elevada": 36.0,
        "graus_dia_periodo_elevado": 27.0,
        "precipitacao_suficiente": 25.0,
    },
    "Ahid": {
        "umidade_muito_baixa": 30.0,
        "umidade_baixa": 45.0,
        "agua_muito_baixa": 45.0,
        "agua_baixa": 70.0,
        "agua_baixa_solo_arenoso": 70.0,
        "agua_baixa_sem_irrigacao": 70.0,
        "irrigacao_relevante": 20.0,
        "agua_baixa_apos_irrigacao": 60.0,
        "umidade_boa": 65.0,
        "agua_boa": 90.0,
    },
    "Afen": {
        "kc_elevado": 1.05,
        "kc_moderado": 0.85,
        "graus_dia_periodo_elevado": 27.0,
        "kc_baixo_fase_inicial": 0.80,
    },
    "Aprod": {
        "queda_moderada_produtividade": -200.0,
        "queda_forte_produtividade": -400.0,
    },
    "Ahist": {
        "precipitacao_baixa": 5.0,
        "precipitacao_recuperacao": 20.0,
    },
    "AIEC": {
        "score_adequada_max": 1.5,
        "score_atencao_max": 2.5,
    },
    "ARG": {
        "r1_precipitacao_adequada": 20.0,
        "r1_precipitacao_atencao_baixa": 10.0,
        "r1_precipitacao_critica_baixa": 5.0,
        "r2_agua_adequada": 90.0,
        "r2_agua_atencao": 65.0,
        "r2_agua_critica": 40.0,
        "r3_umidade_adequada": 65.0,
        "r3_umidade_atencao": 45.0,
        "r3_umidade_critica": 30.0,
        "r4_kc_critico_reprodutivo": 1.0,
        "r4_kc_atencao": 0.85,
        "r5_et_critica": 6.5,
        "r5_et_atencao_alta": 5.5,
        "r5_et_atencao": 4.5,
        "r7_agua_sem_irrigacao": 65.0,
        "r7_agua_apos_irrigacao_critica": 50.0,
        "r7_umidade_apos_irrigacao": 40.0,
        "r7_agua_apos_irrigacao_adequada": 80.0,
        "r8_precipitacao_baixa": 5.0,
    },
}

# -----------------------------------------------------------------------------
# Pesos e limiares do AIEC e AMDH
# -----------------------------------------------------------------------------

PESOS_AIEC = {
    "Eclim": 0.18,
    "Ehid": 0.24,
    "Efen": 0.16,
    "Egeo": 0.10,
    "Eprod": 0.12,
    "Ehist": 0.20,
}

PESOS_AMDH = {
    "whc": 0.40,
    "warg": 0.30,
    "waps": 0.30,
}

LIMIARES_AMDH = {
    "alpha": 1.5,
    "beta": 2.3,
    "gamma": 2.3,
    "delta": 3.3,
    "confianca_minima": 0.60,
    "completude_minima": 0.70,
    "conflito_maximo": 0.45,
}

# -----------------------------------------------------------------------------
# Política de execução e rastreabilidade
# -----------------------------------------------------------------------------

POLITICA_EXECUCAO = {
    "acionamento_fisico_irrigacao": False,
    "amdh_determina_acao": True,
    "permitir_resultado_inconclusivo": True,
}

# Alias legado. Não representa mais o fluxo operacional do Hydros.
POLITICA_SUPERVISAO = {
    "execucao_automatica_irrigacao": False,
    "decisao_final_humana": False,
    "permitir_aceitar": False,
    "permitir_modificar": False,
    "permitir_rejeitar": False,
}

CAMPOS_RASTREABILIDADE = [
    "modo_execucao",
    "agentes_executados",
    "evidencias_utilizadas",
    "pesos_utilizados",
    "confianca",
    "completude",
    "indice_conflito",
    "status_processamento",
    "motivos_inconclusao",
    "verificacao_semantica",
    "justificativa",
]

# -----------------------------------------------------------------------------
# DSSAT e avaliação experimental
# -----------------------------------------------------------------------------

BENCHMARKS = {
    "DSSAT": (
        "Benchmark externo de simulação agronômica usado para "
        "comparação experimental; não integra a arquitetura interna "
        "do Hydros."
    )
}

COLUNAS_COMPARACAO_DSSAT = [
    "data",
    "cenario_id",
    "decisao_dssat",
    "decisao_hydros_sem_historico",
    "decisao_hydros_historico",
    "irrigacao_dssat_mm",
    "irrigacao_hydros_sem_historico_mm",
    "irrigacao_hydros_historico_mm",
    "umidade_solo",
    "estresse_hidrico",
]

# -----------------------------------------------------------------------------
# Tecnologias e algoritmos
# -----------------------------------------------------------------------------

TECNOLOGIAS_METODOS = {
    "DSSAT": "Decision Support System for Agrotechnology Transfer",
    "IoT": "Internet das Coisas",
    "IA": "Inteligência Artificial",
    "Agentic AI": "Inteligência Artificial Agêntica",
    "ML": "Machine Learning ou Aprendizado de Máquina",
    "Random Forest": (
        "Algoritmo supervisionado utilizado inicialmente pelo APS"
    ),
}

ALGORITMOS_APS = {
    "random_forest": "Random Forest",
    "gradient_boosting": "Gradient Boosting",
    "decision_tree": "Decision Tree",
}

# Compatibilidade com o Agente Preditivo Supervisionado
ALGORITMOS_APS = {
    "random_forest": "Random Forest",
    "gradient_boosting": "Gradient Boosting",
    "decision_tree": "Decision Tree",
}

ALGORITMO_APS_PADRAO = "random_forest"
