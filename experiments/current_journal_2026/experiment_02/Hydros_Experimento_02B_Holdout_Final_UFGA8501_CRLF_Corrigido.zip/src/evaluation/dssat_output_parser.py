"""Leitor estrutural conservador de arquivos de saída do DSSAT.

O parser não atribui significado agronômico a colunas pelo nome. Ele apenas
identifica tabelas delimitadas por cabeçalhos DSSAT iniciados por ``@`` e
preserva os nomes publicados no próprio arquivo. A tradução para variáveis do
Hydros é uma etapa separada e só deve ocorrer após a proveniência ser validada.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import pandas as pd


class DSSATOutputParseError(RuntimeError):
    pass


@dataclass(frozen=True)
class DSSATOutputTable:
    source_file: str
    table_index: int
    header_line_number: int
    columns: tuple[str, ...]
    metadata: tuple[str, ...]
    dataframe: pd.DataFrame


def _normalise_header(line: str) -> list[str]:
    payload = line.lstrip()[1:].strip()
    columns = payload.split()
    if not columns:
        raise DSSATOutputParseError("Cabeçalho DSSAT '@' sem colunas.")
    return columns


def _is_non_data_line(stripped: str) -> bool:
    return (
        not stripped
        or stripped.startswith("!")
        or stripped.startswith("*")
        or stripped.startswith("$")
        or stripped.startswith("#")
    )


def _coerce_series(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    original_nonempty = series.astype(str).str.strip().ne("")
    if original_nonempty.any() and numeric[original_nonempty].notna().all():
        return numeric
    return series


def parse_dssat_output_tables(path: str | Path) -> list[DSSATOutputTable]:
    """Extrai todas as tabelas iniciadas por cabeçalhos ``@``.

    O DSSAT pode escrever metadados e múltiplos blocos no mesmo ``.OUT``.
    Cada bloco é devolvido separadamente. Linhas cuja contagem de campos não
    coincide com o cabeçalho são rejeitadas, em vez de serem deslocadas
    silenciosamente.
    """

    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)

    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    tables: list[DSSATOutputTable] = []
    pending_metadata: list[str] = []
    i = 0
    table_index = 0

    while i < len(lines):
        stripped = lines[i].strip()
        if not stripped.startswith("@"):
            if stripped:
                pending_metadata.append(stripped)
                pending_metadata = pending_metadata[-30:]
            i += 1
            continue

        columns = _normalise_header(lines[i])
        header_line = i + 1
        i += 1
        rows: list[list[str]] = []

        while i < len(lines):
            raw = lines[i]
            current = raw.strip()
            if current.startswith("@"):
                break
            if current.startswith("*"):
                # Novo bloco/execução. Não o consome como dado; será metadado
                # para a próxima tabela encontrada.
                break
            if not current or current.startswith(("!", "$", "#")):
                i += 1
                continue

            fields = current.split()
            if len(fields) != len(columns):
                raise DSSATOutputParseError(
                    f"{path.name}: linha {i + 1} possui {len(fields)} campos, "
                    f"mas o cabeçalho da linha {header_line} possui {len(columns)}."
                )
            rows.append(fields)
            i += 1

        frame = pd.DataFrame(rows, columns=columns)
        for col in frame.columns:
            frame[col] = _coerce_series(frame[col])

        tables.append(
            DSSATOutputTable(
                source_file=path.name,
                table_index=table_index,
                header_line_number=header_line,
                columns=tuple(columns),
                metadata=tuple(pending_metadata),
                dataframe=frame,
            )
        )
        table_index += 1
        pending_metadata = []

        # Se paramos diante de um marcador de novo bloco, deixe-o ser consumido
        # pelo laço externo para preservá-lo como metadado.

    return tables


def find_tables_with_columns(
    tables: Iterable[DSSATOutputTable],
    required_columns: Iterable[str],
) -> list[DSSATOutputTable]:
    required = {str(c).upper() for c in required_columns}
    matches = []
    for table in tables:
        available = {c.upper() for c in table.columns}
        if required.issubset(available):
            matches.append(table)
    return matches


def inventory_dssat_output_file(path: str | Path) -> dict[str, object]:
    path = Path(path)
    tables = parse_dssat_output_tables(path)
    return {
        "file": path.name,
        "size_bytes": path.stat().st_size,
        "tables": [
            {
                "table_index": table.table_index,
                "header_line_number": table.header_line_number,
                "columns": list(table.columns),
                "n_rows": int(len(table.dataframe)),
                "metadata_tail": list(table.metadata[-8:]),
            }
            for table in tables
        ],
    }
