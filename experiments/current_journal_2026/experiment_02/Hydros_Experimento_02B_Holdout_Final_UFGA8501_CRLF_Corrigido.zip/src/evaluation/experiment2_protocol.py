"""Protocolo causal e de integridade para o Experimento II do Hydros.

O contexto registrado no período ``t`` é tratado como estado observado após os
processos daquele período. Portanto, a decisão emitida após ``C(t)`` só pode
ser aplicada ao intervalo seguinte ``t+1``. O módulo também impede atribuir
produtividade/estresse de uma trajetória DSSAT a uma programação de irrigação
que não foi efetivamente simulada.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

from src.evaluation.irrigation_policy import (
    IrrigationPolicyConfig,
    actions_to_schedule,
)


@dataclass(frozen=True)
class ScheduleVerification:
    """Resultado da comparação entre manejo planejado e simulado."""

    exact_match: bool
    first_divergence_index: int | None
    first_divergence_date: str | None
    max_absolute_difference_mm: float
    effect_metrics_allowed: bool
    reason: str

    def to_dict(self) -> dict:
        return asdict(self)


def actions_for_next_interval(
    decisions_after_context: Iterable[str | None],
) -> list[str | None]:
    """Desloca ``D(t)`` para o intervalo seguinte.

    O primeiro intervalo não possui uma decisão Hydros anterior dentro da
    trajetória observada. Assim, recebe ``None``; a decisão do último contexto
    fica registrada, mas só seria aplicável fora do horizonte atual.
    """

    decisions = list(decisions_after_context)
    if not decisions:
        return []
    return [None, *decisions[:-1]]


def schedule_from_causal_actions(
    decisions_after_context: Iterable[str | None],
    config: IrrigationPolicyConfig,
) -> tuple[list[str | None], list[float]]:
    """Converte decisões pós-contexto em lâminas causalmente alinhadas."""

    applied_actions = actions_for_next_interval(decisions_after_context)
    planned_mm = actions_to_schedule(applied_actions, config)
    return applied_actions, planned_mm


def verify_planned_against_simulated(
    planned_mm: Sequence[float],
    simulated_mm: Sequence[float],
    *,
    dates: Sequence[str] | None = None,
    tolerance_mm: float = 1e-9,
) -> ScheduleVerification:
    """Verifica se a programação candidata foi realmente simulada pelo DSSAT."""

    if len(planned_mm) != len(simulated_mm):
        raise ValueError(
            "Programação planejada e trajetória simulada possuem comprimentos diferentes."
        )
    if dates is not None and len(dates) != len(planned_mm):
        raise ValueError("A sequência de datas possui comprimento incompatível.")

    planned = np.asarray(planned_mm, dtype=float)
    simulated = np.asarray(simulated_mm, dtype=float)
    diff = np.abs(planned - simulated)
    diverging = np.flatnonzero(diff > float(tolerance_mm))

    if diverging.size == 0:
        return ScheduleVerification(
            exact_match=True,
            first_divergence_index=None,
            first_divergence_date=None,
            max_absolute_difference_mm=float(diff.max()) if len(diff) else 0.0,
            effect_metrics_allowed=True,
            reason="programacao_hydros_efetivamente_representada_pela_trajetoria_dssat",
        )

    first = int(diverging[0])
    first_date = str(dates[first]) if dates is not None else None
    return ScheduleVerification(
        exact_match=False,
        first_divergence_index=first,
        first_divergence_date=first_date,
        max_absolute_difference_mm=float(diff.max()),
        effect_metrics_allowed=False,
        reason=(
            "programacao_hydros_diverge_da_trajetoria_dssat; "
            "nova_execucao_dssat_obrigatoria_antes_de_metricas_de_efeito"
        ),
    )


def build_verification_table(
    *,
    dates: Sequence[str],
    decisions_after_context: Sequence[str | None],
    applied_actions: Sequence[str | None],
    planned_mm: Sequence[float],
    simulated_mm: Sequence[float],
    processing_status: Sequence[str] | None = None,
) -> pd.DataFrame:
    """Cria tabela auditável separando decisão e manejo aplicado."""

    n = len(dates)
    fields = [decisions_after_context, applied_actions, planned_mm, simulated_mm]
    if any(len(field) != n for field in fields):
        raise ValueError("As sequências do protocolo possuem comprimentos incompatíveis.")
    if processing_status is not None and len(processing_status) != n:
        raise ValueError("Status de processamento com comprimento incompatível.")

    table = pd.DataFrame(
        {
            "data": [str(v) for v in dates],
            "acao_decidida_apos_contexto_t": [
                "inconclusivo" if v in (None, "", "inconclusivo") else str(v)
                for v in decisions_after_context
            ],
            "acao_aplicada_no_intervalo_t": [
                "sem_decisao_hydros_anterior" if v in (None, "", "inconclusivo") else str(v)
                for v in applied_actions
            ],
            "irrigacao_planejada_hydros_mm": [float(v) for v in planned_mm],
            "irrigacao_simulada_candidata_mm": [float(v) for v in simulated_mm],
        }
    )
    if processing_status is not None:
        table["status_processamento_decisao"] = [str(v) for v in processing_status]
    table["diferenca_mm"] = (
        table["irrigacao_planejada_hydros_mm"]
        - table["irrigacao_simulada_candidata_mm"]
    ).round(6)
    return table
