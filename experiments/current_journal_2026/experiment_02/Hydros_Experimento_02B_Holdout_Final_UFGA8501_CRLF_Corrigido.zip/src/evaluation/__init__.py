"""Componentes de avaliação experimental do Hydros."""
