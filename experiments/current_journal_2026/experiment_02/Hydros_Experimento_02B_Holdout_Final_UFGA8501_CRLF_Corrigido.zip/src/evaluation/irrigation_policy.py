"""Política operacional para converter ações discretas do Hydros em lâmina.

A política implementa a formulação I_t = pi(D(U_i,t), I_{t-1}, R_t).
Seus parâmetros devem ser definidos antes da comparação experimental. O
módulo não participa do núcleo decisório do Hydros e existe somente para a
avaliação por cenários.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable

import pandas as pd


@dataclass(frozen=True)
class IrrigationPolicyConfig:
    base_mm: float
    step_mm: float
    min_mm: float
    max_mm: float
    inconclusive_policy: str = "sem_aplicacao"
    provenance: str = "preconfigurada_antes_da_comparacao"

    def to_dict(self) -> dict:
        return asdict(self)


class IrrigationActionPolicy:
    """Converte ações em lâminas mantendo estado operacional simples."""

    def __init__(self, config: IrrigationPolicyConfig) -> None:
        self.config = config
        self.previous_mm = 0.0

    def reset(self) -> None:
        self.previous_mm = 0.0

    def set_previous_mm(self, value: float) -> None:
        """Inicializa explicitamente o estado operacional da política.

        Usado pelo Experimento II-B quando existe um prefixo de manejo fixo
        anterior ao início do controle pelo Hydros.
        """

        value = float(value)
        if value < 0:
            raise ValueError("A lâmina anterior não pode ser negativa.")
        self.previous_mm = max(0.0, min(value, float(self.config.max_mm)))

    def apply(self, action: str | None) -> float:
        c = self.config
        action = None if action is None else str(action)

        if action in (None, "", "inconclusivo"):
            if c.inconclusive_policy != "sem_aplicacao":
                raise ValueError(f"Política inconclusiva não suportada: {c.inconclusive_policy}")
            current = 0.0
        elif action == "iniciar_irrigacao":
            current = c.base_mm if self.previous_mm <= 0 else self.previous_mm
        elif action == "manter_irrigacao":
            current = self.previous_mm if self.previous_mm > 0 else 0.0
        elif action == "aumentar_irrigacao":
            start = self.previous_mm if self.previous_mm > 0 else c.base_mm
            current = min(c.max_mm, start + c.step_mm)
        elif action == "reduzir_irrigacao":
            if self.previous_mm <= 0:
                current = 0.0
            else:
                current = max(0.0, self.previous_mm - c.step_mm)
                if 0.0 < current < c.min_mm:
                    current = c.min_mm
        elif action == "finalizar_irrigacao":
            current = 0.0
        else:
            raise ValueError(f"Ação de manejo não reconhecida: {action}")

        current = max(0.0, min(float(current), float(c.max_mm)))
        self.previous_mm = current
        return round(current, 6)


def derive_policy_from_reference(reference: pd.DataFrame) -> IrrigationPolicyConfig:
    """Deriva parâmetros somente da programação de referência pré-existente.

    Essa parametrização é adequada para o protótipo experimental atual porque
    é determinada independentemente das ações produzidas pelo AMDH. Para a
    avaliação final da tese, os mesmos campos podem ser substituídos por
    valores agronômicos documentados sem alterar o pipeline.
    """

    if "irrigacao_aplicada" not in reference.columns:
        raise ValueError("A referência deve possuir irrigacao_aplicada.")

    events = pd.to_numeric(reference["irrigacao_aplicada"], errors="coerce").dropna()
    events = events[events > 0].sort_values()
    if events.empty:
        raise ValueError("A estratégia de referência não possui eventos de irrigação.")

    unique = sorted(float(v) for v in events.unique())
    diffs = [b - a for a, b in zip(unique, unique[1:]) if b > a]
    step = float(pd.Series(diffs).median()) if diffs else max(float(events.median()) * 0.10, 1.0)

    return IrrigationPolicyConfig(
        base_mm=float(events.median()),
        step_mm=step,
        min_mm=float(events.min()),
        max_mm=float(events.max()),
        inconclusive_policy="sem_aplicacao",
        provenance="derivada_da_programacao_dssat_de_referencia_antes_das_acoes_hydros",
    )


def actions_to_schedule(actions: Iterable[str | None], config: IrrigationPolicyConfig) -> list[float]:
    policy = IrrigationActionPolicy(config)
    return [policy.apply(action) for action in actions]
