"""Utilidades auditáveis para programação de irrigação em arquivos DSSAT .SBX.

O módulo altera somente a tabela de eventos de irrigação de um nível já
existente. Não modifica cultivar, solo, plantio, clima, fertilização ou outros
fatores do experimento.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence


class DSSATExperimentFormatError(ValueError):
    """Erro de estrutura no arquivo experimental DSSAT."""


@dataclass(frozen=True, order=True)
class IrrigationEvent:
    date_code: int
    amount_mm: float
    operation: str = "IR001"

    def __post_init__(self) -> None:
        if int(self.date_code) <= 0:
            raise ValueError("date_code deve ser positivo no formato DSSAT YYDDD.")
        if float(self.amount_mm) < 0:
            raise ValueError("A lâmina de irrigação não pode ser negativa.")
        if not str(self.operation).strip():
            raise ValueError("operation não pode ser vazia.")


def _normalise_events(events: Iterable[IrrigationEvent | tuple[int, float]]) -> list[IrrigationEvent]:
    normalised: list[IrrigationEvent] = []
    for item in events:
        if isinstance(item, IrrigationEvent):
            event = item
        else:
            date_code, amount_mm = item
            event = IrrigationEvent(int(date_code), float(amount_mm))
        if event.amount_mm <= 0:
            # Eventos de 0 mm não precisam ser escritos no arquivo DSSAT.
            continue
        normalised.append(event)

    normalised.sort(key=lambda e: e.date_code)
    dates = [e.date_code for e in normalised]
    if len(dates) != len(set(dates)):
        raise ValueError("A programação contém duas aplicações na mesma data DSSAT.")
    return normalised


def _find_irrigation_section(lines: Sequence[str]) -> tuple[int, int]:
    start = next(
        (i for i, line in enumerate(lines) if line.strip().upper().startswith("*IRRIGATION AND WATER MANAGEMENT")),
        None,
    )
    if start is None:
        raise DSSATExperimentFormatError(
            "Seção '*IRRIGATION AND WATER MANAGEMENT' não encontrada."
        )

    end = len(lines)
    for i in range(start + 1, len(lines)):
        stripped = lines[i].strip()
        if stripped.startswith("*"):
            end = i
            break
    return start, end


def _find_level_event_span(lines: Sequence[str], level: int) -> tuple[int, int]:
    start, end = _find_irrigation_section(lines)
    level = int(level)

    i = start + 1
    while i < end:
        stripped = lines[i].strip()
        if stripped.upper().startswith("@I") and "EFIR" in stripped.upper():
            j = i + 1
            while j < end and not lines[j].strip():
                j += 1
            if j >= end:
                break
            parts = lines[j].split()
            if parts and parts[0].isdigit() and int(parts[0]) == level:
                k = j + 1
                while k < end and not (
                    lines[k].strip().upper().startswith("@I")
                    and "IDATE" in lines[k].strip().upper()
                ):
                    # Um novo cabeçalho de nível antes da tabela de eventos é inválido.
                    if lines[k].strip().upper().startswith("@I") and "EFIR" in lines[k].strip().upper():
                        raise DSSATExperimentFormatError(
                            f"Tabela de eventos não encontrada para o nível de irrigação {level}."
                        )
                    k += 1
                if k >= end:
                    raise DSSATExperimentFormatError(
                        f"Cabeçalho IDATE não encontrado para o nível de irrigação {level}."
                    )

                event_start = k + 1
                event_end = event_start
                while event_end < end:
                    s = lines[event_end].strip()
                    if s.startswith("*"):
                        break
                    if s.upper().startswith("@I") and "EFIR" in s.upper():
                        break
                    if s.upper().startswith("@I") and "IDATE" in s.upper():
                        break
                    # Linhas vazias pertencem ao fim lógico do bloco, mas podem ser
                    # substituídas sem alterar o bloco seguinte.
                    if s.startswith("@"):
                        break
                    event_end += 1
                return event_start, event_end
        i += 1

    raise DSSATExperimentFormatError(
        f"Nível de irrigação {level} não encontrado no arquivo experimental."
    )


def extract_irrigation_events(text: str, level: int) -> list[IrrigationEvent]:
    """Extrai os eventos explícitos de irrigação de um nível do experimento."""

    lines = text.splitlines()
    start, end = _find_level_event_span(lines, level)
    events: list[IrrigationEvent] = []
    for line in lines[start:end]:
        stripped = line.strip()
        if not stripped or stripped.startswith("!"):
            # Linhas iniciadas por ! são comentários DSSAT. Alguns experimentos
            # mantêm eventos de irrigação desativados como linhas comentadas
            # dentro do próprio bloco; eles não podem ser interpretados como
            # eventos ativos.
            continue
        parts = stripped.split()
        if len(parts) < 4:
            continue
        try:
            row_level = int(parts[0])
            date_code = int(parts[1])
            operation = parts[2]
            amount = float(parts[3])
        except ValueError as exc:
            raise DSSATExperimentFormatError(
                f"Linha de irrigação inválida: {line!r}"
            ) from exc
        if row_level != int(level):
            # Se aparecer outro nível sem novo cabeçalho, tratamos como erro.
            raise DSSATExperimentFormatError(
                f"Evento do nível {row_level} dentro do bloco do nível {level}."
            )
        events.append(IrrigationEvent(date_code, amount, operation))
    return events



def get_treatment_factor_level(text: str, treatment: int, factor: str) -> int:
    """Retorna o nível de um fator usado por um tratamento DSSAT.

    A tabela *TREATMENTS pode conter um TNAME com espaços. Por isso os níveis
    dos fatores são lidos a partir do final da linha, usando os nomes dos
    fatores declarados após TNAME no cabeçalho.
    """

    lines = text.splitlines()
    start = next(
        (i for i, line in enumerate(lines) if line.strip().upper().startswith("*TREATMENTS")),
        None,
    )
    if start is None:
        raise DSSATExperimentFormatError("Seção '*TREATMENTS' não encontrada.")

    end = len(lines)
    for i in range(start + 1, len(lines)):
        if lines[i].strip().startswith("*"):
            end = i
            break

    header_index = next(
        (i for i in range(start + 1, end) if lines[i].strip().upper().startswith("@N")),
        None,
    )
    if header_index is None:
        raise DSSATExperimentFormatError("Cabeçalho da seção *TREATMENTS não encontrado.")

    header = lines[header_index].split()
    try:
        tname_index = next(i for i, token in enumerate(header) if token.upper().startswith("TNAME"))
    except StopIteration as exc:
        raise DSSATExperimentFormatError("Coluna TNAME não encontrada em *TREATMENTS.") from exc

    factors = [token.upper() for token in header[tname_index + 1 :]]
    factor = str(factor).strip().upper()
    if factor not in factors:
        raise DSSATExperimentFormatError(
            f"Fator {factor!r} não encontrado em *TREATMENTS."
        )
    factor_pos = factors.index(factor)

    treatment = int(treatment)
    for i in range(header_index + 1, end):
        stripped = lines[i].strip()
        if not stripped or stripped.startswith("!") or stripped.startswith("@"):
            continue
        parts = stripped.split()
        try:
            row_treatment = int(parts[0])
        except (ValueError, IndexError):
            continue
        if row_treatment != treatment:
            continue
        if len(parts) < len(factors) + 4:
            raise DSSATExperimentFormatError(
                f"Linha do tratamento {treatment} não contém todos os fatores esperados."
            )
        factor_values = parts[-len(factors):]
        try:
            return int(factor_values[factor_pos])
        except (ValueError, IndexError) as exc:
            raise DSSATExperimentFormatError(
                f"Nível inválido do fator {factor} no tratamento {treatment}."
            ) from exc

    raise DSSATExperimentFormatError(
        f"Tratamento {treatment} não encontrado em *TREATMENTS."
    )


def extract_treatment_irrigation_events(text: str, treatment: int) -> list[IrrigationEvent]:
    """Extrai a programação realmente referenciada pelo tratamento.

    MI=0 significa tratamento sem nível de manejo de irrigação explícito e,
    portanto, retorna lista vazia em vez de procurar um bloco inexistente.
    """

    level = get_treatment_factor_level(text, treatment, "MI")
    if level == 0:
        return []
    return extract_irrigation_events(text, level)

def _format_amount(value: float) -> str:
    return f"{float(value):.3f}".rstrip("0").rstrip(".")


def replace_irrigation_events(
    text: str,
    *,
    level: int,
    events: Iterable[IrrigationEvent | tuple[int, float]],
) -> str:
    """Substitui apenas os eventos explícitos de um nível de irrigação.

    O cabeçalho e os parâmetros EFIR/IDEP/ITHR do nível são preservados.
    """

    trailing_newline = text.endswith("\n")
    lines = text.splitlines()
    event_start, event_end = _find_level_event_span(lines, level)
    normalised = _normalise_events(events)

    # As linhas de eventos DSSAT são de largura fixa e têm 20 caracteres:
    # nível em colunas 1-2, IDATE em 4-8, IROP em 10-14 e IRVAL em 15-20.
    # O arquivo oficial usa, por exemplo: `` 1 85172 IR001    13``.
    # Não pode haver espaço extra entre IROP e o campo IRVAL.
    new_rows = [
        f"{int(level):2d} {event.date_code:05d} {event.operation:<5s}{_format_amount(event.amount_mm):>6s}"
        for event in normalised
    ]
    updated = lines[:event_start] + new_rows + lines[event_end:]
    result = "\n".join(updated)
    if trailing_newline:
        result += "\n"
    return result


def replace_irrigation_events_file(
    source: str | Path,
    destination: str | Path,
    *,
    level: int,
    events: Iterable[IrrigationEvent | tuple[int, float]],
) -> Path:
    source = Path(source)
    destination = Path(destination)
    text = source.read_text(encoding="utf-8", errors="strict")
    updated = replace_irrigation_events(text, level=level, events=events)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(updated, encoding="utf-8", newline="\n")
    return destination
