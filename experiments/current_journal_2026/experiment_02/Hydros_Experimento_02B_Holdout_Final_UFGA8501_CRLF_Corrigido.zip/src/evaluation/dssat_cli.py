"""Execução do DSSAT CSM por linha de comando para o Experimento II-B.

O contrato segue o modo C do programa CSM oficial: RNMODE='C', arquivo de
experimento e número do tratamento. O nome do arquivo experimental é passado
como basename DSSAT, não como caminho arbitrário.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import subprocess
from typing import Sequence


class DSSATPreflightError(RuntimeError):
    pass


@dataclass(frozen=True)
class DSSATCommandConfig:
    executable: Path
    experiment_file: Path
    treatment: int
    working_directory: Path | None = None
    simulation_control_file: str | None = None
    model_argument: str | None = None
    timeout_seconds: int = 180

    def resolved_working_directory(self) -> Path:
        return Path(self.working_directory or self.experiment_file.parent).resolve()


def build_dssat_command(config: DSSATCommandConfig) -> list[str]:
    experiment_name = Path(config.experiment_file).name
    if len(experiment_name) > 12:
        raise DSSATPreflightError(
            "O CSM oficial usa FILEX com 12 caracteres; use o nome DSSAT padrão, "
            "por exemplo UFGA8501.SBX."
        )
    if int(config.treatment) <= 0:
        raise DSSATPreflightError("O número do tratamento deve ser positivo.")

    cmd = [str(Path(config.executable).resolve())]
    if config.model_argument:
        cmd.append(str(config.model_argument))
    cmd.extend(["C", experiment_name, str(int(config.treatment))])
    if config.simulation_control_file:
        cmd.append(str(config.simulation_control_file))
    return cmd


def preflight_dssat_command(config: DSSATCommandConfig) -> dict[str, object]:
    executable = Path(config.executable).resolve()
    experiment = Path(config.experiment_file).resolve()
    cwd = config.resolved_working_directory()

    problems: list[str] = []
    if not executable.is_file():
        problems.append(f"executável ausente: {executable}")
    if not experiment.is_file():
        problems.append(f"arquivo experimental ausente: {experiment}")
    if not cwd.is_dir():
        problems.append(f"diretório de execução ausente: {cwd}")
    elif experiment.is_file() and experiment.parent.resolve() != cwd:
        # O modo C recebe apenas FILEX de 12 caracteres. Para evitar ambiguidade,
        # exigimos que a cópia experimental esteja no diretório de execução.
        problems.append(
            "o arquivo experimental deve estar diretamente no diretório de execução "
            "usado pelo backend"
        )

    command: Sequence[str] | None = None
    try:
        command = build_dssat_command(config)
    except DSSATPreflightError as exc:
        problems.append(str(exc))

    return {
        "ready": not problems,
        "problems": problems,
        "executable": str(executable),
        "experiment_file": str(experiment),
        "working_directory": str(cwd),
        "command": list(command) if command else None,
        "run_mode": "C",
    }


def run_dssat_command(config: DSSATCommandConfig) -> subprocess.CompletedProcess[str]:
    status = preflight_dssat_command(config)
    if not status["ready"]:
        raise DSSATPreflightError("; ".join(status["problems"]))

    return subprocess.run(
        build_dssat_command(config),
        cwd=config.resolved_working_directory(),
        text=True,
        capture_output=True,
        timeout=int(config.timeout_seconds),
        check=False,
    )
