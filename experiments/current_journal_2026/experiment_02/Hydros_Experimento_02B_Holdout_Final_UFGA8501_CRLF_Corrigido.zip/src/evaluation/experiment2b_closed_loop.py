"""Orquestrador causal do Experimento II-B em ciclo fechado.

O DSSAT normalmente executa uma trajetória completa. Para preservar causalidade
sem usar estados futuros, o runner pode reexecutar a temporada a cada decisão:

1. simula com o manejo já conhecido e zero nos intervalos futuros;
2. lê somente o histórico até C(t);
3. o Hydros decide após C(t);
4. a política converte a ação em manejo para t+1;
5. reexecuta o DSSAT com o novo prefixo de manejo;
6. aceita C(t+1) somente se a lâmina simulada coincidir com a programada.

Esse desenho é deliberadamente custoso, mas impede reutilizar estados futuros de
uma trajetória que não executou as ações do Hydros.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Protocol, Sequence

import numpy as np
import pandas as pd

from src.evaluation.irrigation_policy import IrrigationActionPolicy


class FullSeasonSimulationBackend(Protocol):
    """Contrato mínimo de um backend DSSAT para o runner fechado."""

    def simulate(self, irrigation_schedule_mm: Sequence[float]) -> pd.DataFrame:
        """Executa a temporada com a programação informada e retorna estados diários."""


DecisionFunction = Callable[[pd.DataFrame], str | None]


@dataclass(frozen=True)
class ClosedLoopResult:
    irrigation_schedule_mm: tuple[float, ...]
    trajectory: pd.DataFrame
    trace: pd.DataFrame
    n_simulations: int
    causal_alignment: str = "C(t)_determina_manejo_t+1"


class ClosedLoopProtocolError(RuntimeError):
    pass


def _validate_trajectory(
    trajectory: pd.DataFrame,
    n_periods: int,
    irrigation_column: str,
) -> None:
    if not isinstance(trajectory, pd.DataFrame) or trajectory.empty:
        raise ClosedLoopProtocolError("O backend retornou trajetória vazia ou inválida.")
    if len(trajectory) != n_periods:
        raise ClosedLoopProtocolError(
            f"O backend retornou {len(trajectory)} períodos; esperado: {n_periods}."
        )
    if irrigation_column not in trajectory.columns:
        raise ClosedLoopProtocolError(
            f"A trajetória não contém a coluna {irrigation_column}."
        )


def _verify_schedule_prefix(
    trajectory: pd.DataFrame,
    schedule: Sequence[float],
    end_index: int,
    irrigation_column: str,
    tolerance_mm: float,
) -> None:
    simulated = pd.to_numeric(
        trajectory[irrigation_column].iloc[: end_index + 1], errors="coerce"
    ).to_numpy(dtype=float)
    planned = np.asarray(schedule[: end_index + 1], dtype=float)
    if np.isnan(simulated).any():
        raise ClosedLoopProtocolError("A irrigação simulada contém valor não numérico.")
    if not np.allclose(simulated, planned, rtol=0.0, atol=tolerance_mm):
        diff = np.abs(simulated - planned)
        idx = int(np.argmax(diff))
        raise ClosedLoopProtocolError(
            "O DSSAT não reproduziu o prefixo de manejo solicitado: "
            f"índice {idx}, planejado={planned[idx]:.6f}, simulado={simulated[idx]:.6f}."
        )


def _verify_exogenous_prefix(
    baseline: pd.DataFrame,
    current: pd.DataFrame,
    columns: Sequence[str],
    end_index: int,
) -> None:
    for col in columns:
        if col not in baseline.columns or col not in current.columns:
            raise ClosedLoopProtocolError(f"Variável exógena ausente: {col}")
        a = baseline[col].iloc[: end_index + 1].reset_index(drop=True)
        b = current[col].iloc[: end_index + 1].reset_index(drop=True)
        if pd.api.types.is_numeric_dtype(a) and pd.api.types.is_numeric_dtype(b):
            if not np.allclose(a.astype(float), b.astype(float), rtol=0.0, atol=1e-9, equal_nan=True):
                raise ClosedLoopProtocolError(
                    f"Variável exógena {col} mudou entre reexecuções até o índice {end_index}."
                )
        elif not a.astype(str).equals(b.astype(str)):
            raise ClosedLoopProtocolError(
                f"Variável exógena {col} mudou entre reexecuções até o índice {end_index}."
            )


def run_closed_loop(
    *,
    backend: FullSeasonSimulationBackend,
    decision_fn: DecisionFunction,
    policy: IrrigationActionPolicy,
    n_periods: int,
    fixed_prefix_mm: Sequence[float] | None = None,
    control_start_index: int = 0,
    irrigation_column: str = "irrigacao_aplicada",
    exogenous_columns: Sequence[str] = (),
    tolerance_mm: float = 1e-6,
) -> ClosedLoopResult:
    """Executa o controle causal por reexecuções sucessivas da temporada.

    ``fixed_prefix_mm`` representa manejo exógeno anterior ao início do controle,
    por exemplo irrigação de estabelecimento. O primeiro índice controlado é
    ``control_start_index + 1`` porque a decisão após C(t) só vale para t+1.
    """

    if n_periods < 2:
        raise ValueError("O ciclo fechado exige pelo menos dois períodos.")
    if control_start_index < 0 or control_start_index >= n_periods - 1:
        raise ValueError("control_start_index fora do intervalo causal válido.")

    schedule = [0.0] * n_periods
    prefix = list(fixed_prefix_mm or [])
    if len(prefix) > n_periods:
        raise ValueError("O prefixo fixo é maior que a temporada.")
    for idx, value in enumerate(prefix):
        value = float(value)
        if value < 0:
            raise ValueError("O prefixo de irrigação não pode conter valores negativos.")
        schedule[idx] = value

    if prefix and control_start_index < len(prefix) - 1:
        raise ValueError(
            "O controle pelo Hydros não pode começar antes do fim do prefixo fixo."
        )

    previous_mm = schedule[control_start_index]
    policy.set_previous_mm(previous_mm)

    trajectory = backend.simulate(schedule)
    n_simulations = 1
    _validate_trajectory(trajectory, n_periods, irrigation_column)
    baseline_exogenous = trajectory.copy()
    _verify_schedule_prefix(
        trajectory, schedule, control_start_index, irrigation_column, tolerance_mm
    )

    trace_rows: list[dict[str, object]] = []

    for t in range(control_start_index, n_periods - 1):
        history = trajectory.iloc[: t + 1].copy().reset_index(drop=True)
        action = decision_fn(history)
        planned_next = float(policy.apply(action))
        schedule[t + 1] = planned_next

        new_trajectory = backend.simulate(schedule)
        n_simulations += 1
        _validate_trajectory(new_trajectory, n_periods, irrigation_column)
        _verify_schedule_prefix(
            new_trajectory, schedule, t + 1, irrigation_column, tolerance_mm
        )
        if exogenous_columns:
            _verify_exogenous_prefix(
                baseline_exogenous,
                new_trajectory,
                exogenous_columns,
                t + 1,
            )

        row = {
            "context_index_t": t,
            "applied_index_t_plus_1": t + 1,
            "acao_decidida_apos_contexto_t": action,
            "irrigacao_planejada_t_plus_1_mm": round(planned_next, 6),
            "irrigacao_simulada_t_plus_1_mm": round(
                float(new_trajectory.iloc[t + 1][irrigation_column]), 6
            ),
            "prefixo_verificado_ate_indice": t + 1,
        }
        for col in ("data", "dia_safra"):
            if col in trajectory.columns:
                row[f"contexto_{col}"] = trajectory.iloc[t][col]
            if col in new_trajectory.columns:
                row[f"manejo_{col}"] = new_trajectory.iloc[t + 1][col]
        trace_rows.append(row)
        trajectory = new_trajectory

    # A trajetória final precisa coincidir integralmente com o manejo produzido.
    _verify_schedule_prefix(
        trajectory, schedule, n_periods - 1, irrigation_column, tolerance_mm
    )

    return ClosedLoopResult(
        irrigation_schedule_mm=tuple(round(float(v), 6) for v in schedule),
        trajectory=trajectory.copy(),
        trace=pd.DataFrame(trace_rows),
        n_simulations=n_simulations,
    )
