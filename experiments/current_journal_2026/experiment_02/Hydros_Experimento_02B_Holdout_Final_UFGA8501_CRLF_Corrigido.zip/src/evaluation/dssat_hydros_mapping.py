"""Contrato de tradução entre saídas DSSAT e variáveis do Hydros no Experimento II-B.

Este módulo NÃO modifica o núcleo decisório do Hydros. Ele documenta e calcula
variáveis auxiliares de compatibilidade para o experimento com DSSAT, preservando
sempre os valores físicos originais e a proveniência de cada transformação.

Princípios:
1. nenhuma transformação silenciosa de variável física;
2. índices de compatibilidade recebem nomes próprios e não substituem o dado bruto;
3. parâmetros do solo são específicos do perfil DSSAT utilizado;
4. estágio fenológico só pode ser convertido quando houver um código DSSAT de
   proveniência verificável;
5. produtividade final não é tratada como estimativa diária para o Aprod.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable

import pandas as pd


@dataclass(frozen=True)
class SoilLayer:
    bottom_cm: float
    ll_vwc: float
    dul_vwc: float
    sat_vwc: float


@dataclass(frozen=True)
class SoilHydraulicProfile:
    soil_id: str
    description: str
    broad_texture_class: str
    layers: tuple[SoilLayer, ...]
    provenance: str

    def hydraulic_summary(self) -> dict[str, float | str]:
        previous_cm = 0.0
        ll_total = 0.0
        dul_total = 0.0
        sat_total = 0.0
        depth_mm = 0.0

        for layer in self.layers:
            thickness_mm = (float(layer.bottom_cm) - previous_cm) * 10.0
            if thickness_mm <= 0:
                raise ValueError("As camadas do perfil devem ter profundidades crescentes.")
            depth_mm += thickness_mm
            ll_total += thickness_mm * float(layer.ll_vwc)
            dul_total += thickness_mm * float(layer.dul_vwc)
            sat_total += thickness_mm * float(layer.sat_vwc)
            previous_cm = float(layer.bottom_cm)

        pawc = dul_total - ll_total
        return {
            "soil_id": self.soil_id,
            "description": self.description,
            "broad_texture_class": self.broad_texture_class,
            "profile_depth_mm": round(depth_mm, 6),
            "LL_total_mm": round(ll_total, 6),
            "DUL_total_mm": round(dul_total, 6),
            "SAT_total_mm": round(sat_total, 6),
            "PAWC_LL_to_DUL_mm": round(pawc, 6),
            "weighted_LL_vwc": round(ll_total / depth_mm, 9),
            "weighted_DUL_vwc": round(dul_total / depth_mm, 9),
            "weighted_SAT_vwc": round(sat_total / depth_mm, 9),
            "provenance": self.provenance,
        }


IBSB910015 = SoilHydraulicProfile(
    soil_id="IBSB910015",
    description="Millhopper Fine Sand",
    broad_texture_class="arenoso",
    layers=(
        SoilLayer(5, 0.023, 0.086, 0.230),
        SoilLayer(15, 0.023, 0.086, 0.230),
        SoilLayer(30, 0.023, 0.086, 0.230),
        SoilLayer(45, 0.023, 0.086, 0.230),
        SoilLayer(60, 0.023, 0.086, 0.230),
        SoilLayer(90, 0.021, 0.076, 0.230),
        SoilLayer(120, 0.020, 0.076, 0.230),
        SoilLayer(150, 0.027, 0.130, 0.230),
        SoilLayer(180, 0.070, 0.258, 0.360),
    ),
    provenance=(
        "DSSAT dssat-csm-data, Soil/SOIL.SOL, perfil IBSB910015; "
        "valores preservados para auditoria do Experimento II-B"
    ),
)


@dataclass(frozen=True)
class WaterStatusBridge:
    """Descritores auxiliares derivados da água extraível do perfil.

    ``relative_extractable_water`` pode exceder 1 quando o perfil contém água
    acima do limite de drenagem superior (DUL). Isso é preservado no campo
    ``unbounded``. O valor ``clipped`` serve somente a índices de compatibilidade.

    ``synthetic_moisture_compatibility_index`` reproduz apenas a transformação
    determinística central usada na geração sintética do Experimento I:
    10 + 82 * fração de água. O gerador original acrescentava ruído. Portanto,
    esse índice NÃO é umidade volumétrica e NÃO deve ser apresentado como dado
    físico do DSSAT.
    """

    extractable_water_mm: float
    pawc_mm: float
    relative_extractable_water_unbounded: float
    relative_extractable_water_clipped: float
    synthetic_moisture_compatibility_index: float

    def to_dict(self) -> dict:
        return asdict(self)


def derive_water_status_bridge(
    extractable_water_mm: float,
    profile: SoilHydraulicProfile = IBSB910015,
) -> WaterStatusBridge:
    summary = profile.hydraulic_summary()
    pawc = float(summary["PAWC_LL_to_DUL_mm"])
    if pawc <= 0:
        raise ValueError("PAWC deve ser positiva.")

    raw = float(extractable_water_mm)
    fraction = raw / pawc
    clipped = max(0.0, min(1.0, fraction))
    compatibility = max(5.0, min(95.0, 10.0 + 82.0 * clipped))

    return WaterStatusBridge(
        extractable_water_mm=round(raw, 6),
        pawc_mm=round(pawc, 6),
        relative_extractable_water_unbounded=round(fraction, 9),
        relative_extractable_water_clipped=round(clipped, 9),
        synthetic_moisture_compatibility_index=round(compatibility, 6),
    )


def add_experiment2b_water_audit_columns(
    df: pd.DataFrame,
    *,
    source_column: str = "agua_disponivel",
    profile: SoilHydraulicProfile = IBSB910015,
) -> pd.DataFrame:
    """Adiciona colunas auxiliares sem substituir nenhuma coluna do Hydros."""

    if source_column not in df.columns:
        raise ValueError(f"Coluna ausente para auditoria: {source_column}")

    result = df.copy()
    values = pd.to_numeric(result[source_column], errors="coerce")
    if values.isna().any():
        raise ValueError(f"A coluna {source_column} possui valores não numéricos.")

    bridges = [derive_water_status_bridge(v, profile) for v in values]
    result["dssat_agua_extraivel_mm_auditoria"] = [b.extractable_water_mm for b in bridges]
    result["fracao_agua_extraivel_perfil_sem_corte"] = [
        b.relative_extractable_water_unbounded for b in bridges
    ]
    result["fracao_agua_extraivel_perfil"] = [
        b.relative_extractable_water_clipped for b in bridges
    ]
    result["indice_umidade_compativel_exp1"] = [
        b.synthetic_moisture_compatibility_index for b in bridges
    ]
    result["indice_umidade_compativel_exp1_semantica"] = (
        "indice_relativo_experimental_nao_umidade_volumetrica"
    )
    result["perfil_solo_hidraulico"] = profile.soil_id
    return result


def map_soil_to_broad_texture(soil_id: str) -> tuple[str | None, str]:
    """Mapeia somente perfis explicitamente cadastrados no contrato experimental."""

    key = str(soil_id).strip().upper()
    if key == IBSB910015.soil_id:
        return IBSB910015.broad_texture_class, (
            "mapeamento_por_perfil_oficial_IBSB910015_Millhopper_Fine_Sand"
        )
    return None, "perfil_sem_mapeamento_explicito"


def phenology_mapping_status(values: Iterable[object]) -> dict[str, object]:
    """Bloqueia conversão fenológica quando a origem do código não é verificável."""

    unique = sorted({str(v).strip() for v in values if pd.notna(v)})
    hydros_vr = {"V3", "V4", "V5", "R1", "R2", "R3", "R4", "R5"}
    direct = [v for v in unique if v.upper() in hydros_vr]
    unverified = [v for v in unique if v.upper() not in hydros_vr]
    return {
        "values": unique,
        "direct_hydros_categories": direct,
        "unverified_categories": unverified,
        "safe_to_map_current_csv": len(unverified) == 0,
        "policy": (
            "usar_codigo_fenologico_DSSAT_verificavel_na_nova_extracao; "
            "nao_inventar_correspondencia_V_R_para_rotulos_textuais_atuais"
        ),
    }


def productivity_semantics_status(series: pd.Series) -> dict[str, object]:
    """Classifica se a série parece adequada como produtividade estimada diária."""

    values = pd.to_numeric(series, errors="coerce")
    if values.isna().any():
        return {
            "safe_for_daily_aprod": False,
            "reason": "valores_nao_numericos",
        }

    n = int(len(values))
    zeros = int((values == 0).sum())
    nonzero = int((values != 0).sum())
    terminal_only = n > 1 and nonzero <= max(1, int(round(0.05 * n)))
    return {
        "n": n,
        "n_zero": zeros,
        "n_nonzero": nonzero,
        "terminal_only_pattern": bool(terminal_only),
        "safe_for_daily_aprod": not terminal_only,
        "reason": (
            "serie_compativel_com_resultado_final_nao_estimativa_diaria"
            if terminal_only
            else "serie_possivelmente_dinamica_requer_confirmacao_de_proveniencia"
        ),
    }


def required_dssat_outputs_for_closed_loop() -> tuple[str, ...]:
    """Variáveis mínimas desejáveis para o runner fechado do Experimento II-B."""

    return (
        "data/dia_da_simulacao",
        "precipitacao",
        "temperatura_minima_maxima_ou_media",
        "evapotranspiracao_real_e_potencial",
        "irrigacao_aplicada",
        "SWXD_agua_extraivel_do_perfil_mm",
        "SWTD_agua_total_do_perfil_mm",
        "agua_do_solo_por_camada",
        "LL_DUL_SAT_por_camada",
        "RDPD_profundidade_radicular",
        "WSPD_ou_WSPAV_estresse_hidrico",
        "codigo_estagio_fenologico_DSSAT",
        "produtividade_final",
        "drenagem_ou_excesso_de_agua_quando_disponivel",
    )

# -----------------------------------------------------------------------------
# Ponte diária corrigida para o Experimento II-B
# -----------------------------------------------------------------------------

FAO_SOYBEAN_KC = {
    "initial": 0.35,
    "development": 0.75,
    "mid_season": 1.10,
    "late_season": 0.60,
}


def _load_single_table(output_dir: str | "Path", filename: str) -> pd.DataFrame:
    """Carrega uma tabela diária DSSAT preservando os nomes CDE originais."""

    from pathlib import Path
    from src.evaluation.dssat_output_parser import parse_dssat_output_tables

    path = Path(output_dir) / filename
    tables = parse_dssat_output_tables(path)
    if not tables:
        raise ValueError(f"Nenhuma tabela DSSAT encontrada em {path}")
    if len(tables) != 1:
        raise ValueError(
            f"O arquivo {path.name} possui {len(tables)} tabelas; "
            "a ponte diária exige um único bloco para o tratamento executado."
        )
    return tables[0].dataframe.copy()


def _merge_on_das(base: pd.DataFrame, other: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    keep = ["DAS"] + [c for c in columns if c in other.columns]
    missing = [c for c in columns if c not in other.columns]
    if missing:
        raise ValueError(f"Colunas DSSAT ausentes: {', '.join(missing)}")
    right = other[keep].copy()
    return base.merge(right, on="DAS", how="left", validate="one_to_one")


def _root_zone_water_metrics(row: pd.Series) -> dict[str, float]:
    """Calcula água na zona radicular a partir de SW, LL, DUL e RDPD.

    A profundidade radicular RDPD é publicada pelo DSSAT em metros. O cálculo
    integra somente a fração de cada camada efetivamente alcançada pelas raízes.
    Valores de SW acima de DUL são truncados em DUL para o cálculo de água
    extraível, evitando chamar água gravitacional de água disponível à cultura.
    """

    root_depth_cm = max(0.0, min(180.0, float(row["RDPD"]) * 100.0))
    previous_cm = 0.0
    aw_mm = 0.0
    taw_mm = 0.0
    water_mm = 0.0
    rooted_depth_mm = 0.0

    for idx, layer in enumerate(IBSB910015.layers, start=1):
        layer_top = previous_cm
        layer_bottom = float(layer.bottom_cm)
        rooted_bottom = min(root_depth_cm, layer_bottom)
        rooted_cm = max(0.0, rooted_bottom - layer_top)
        previous_cm = layer_bottom
        if rooted_cm <= 0:
            continue

        thickness_mm = rooted_cm * 10.0
        sw = float(row[f"SW{idx}D"])
        ll = float(row[f"LL{idx}D"])
        dul = float(row[f"DUL{idx}D"])
        bounded_sw = max(ll, min(sw, dul))

        rooted_depth_mm += thickness_mm
        water_mm += thickness_mm * max(sw, 0.0)
        aw_mm += thickness_mm * max(0.0, bounded_sw - ll)
        taw_mm += thickness_mm * max(0.0, dul - ll)

    if taw_mm <= 0.0:
        rew = 1.0 if root_depth_cm <= 0 else 0.0
    else:
        rew = max(0.0, min(1.0, aw_mm / taw_mm))

    full_pawc = float(IBSB910015.hydraulic_summary()["PAWC_LL_to_DUL_mm"])
    equivalent_full_profile_mm = rew * full_pawc

    return {
        "profundidade_radicular_cm": root_depth_cm,
        "profundidade_radicular_integrada_mm": rooted_depth_mm,
        "agua_total_zona_radicular_mm": water_mm,
        "agua_extraivel_zona_radicular_mm": aw_mm,
        "taw_zona_radicular_mm": taw_mm,
        "fracao_agua_extraivel_zona_radicular": rew,
        # Campos de compatibilidade explicitamente normalizados. Eles não são
        # apresentados como medições físicas brutas do DSSAT.
        "umidade_solo_hydros_pct": 100.0 * rew,
        "agua_disponivel_hydros_mm_equivalente": equivalent_full_profile_mm,
    }


def _map_gstd_to_hydros_stage(gstd: float, leaf_number: float) -> tuple[str, str]:
    """Converte o estado atual CROPGRO para a taxonomia V/R usada pelo Hydros.

    O mapeamento usa somente GSTD e L#SD do mesmo dia, portanto não consulta
    datas fenológicas futuras. GSTD 0 é refinado pela contagem corrente de
    folhas apenas para representar V3/V4/V5 no contrato atual do protótipo.
    Para as fases reprodutivas, o Hydros trata R3/R4/R5 com a mesma criticidade
    fenológica, então o mapeamento conserva a progressão sem inventar datas.
    """

    g = int(round(float(gstd)))
    leaves = max(0.0, float(leaf_number))
    if g <= 0:
        if leaves < 3.5:
            return "V3", "GSTD0_L#SD<3.5"
        if leaves < 4.5:
            return "V4", "GSTD0_3.5<=L#SD<4.5"
        return "V5", "GSTD0_L#SD>=4.5"
    if g == 1:
        return "R1", "GSTD1"
    if g == 3:
        return "R3", "GSTD3"
    if g == 5:
        return "R5", "GSTD5"
    if g >= 7:
        return "R5", f"GSTD{g}_maturacao"
    # Códigos intermediários não vistos no diagnóstico são aproximados para a
    # classe reprodutiva mais próxima e ficam registrados na proveniência.
    if g == 2:
        return "R2", "GSTD2"
    if g == 4:
        return "R4", "GSTD4"
    return "R5", f"GSTD{g}_compatibilidade"


def _kc_for_daily_state(gstd: float, hydros_stage: str) -> tuple[float, str]:
    """Atribui Kc de soja por fase, sem usar ET real do próprio DSSAT.

    Os valores são parâmetros externos de referência e permanecem identificados
    como tal. Isso evita a circularidade anterior de tratar ETAA/EOAA como Kc.
    """

    g = int(round(float(gstd)))
    if g <= 0:
        if hydros_stage == "V3":
            return FAO_SOYBEAN_KC["initial"], "FAO_soja_initial"
        return FAO_SOYBEAN_KC["development"], "FAO_soja_development"
    if g in (1, 2, 3, 4, 5):
        return FAO_SOYBEAN_KC["mid_season"], "FAO_soja_mid_season"
    return FAO_SOYBEAN_KC["late_season"], "FAO_soja_late_season"


def _stress_class_from_dssat(wspd: float, wsgd: float) -> tuple[str, float]:
    """Converte o maior estresse hídrico diário DSSAT para classes legadas Hydros."""

    value = max(0.0, min(1.0, max(float(wspd), float(wsgd))))
    if value < 0.25:
        return "baixo", value
    if value < 0.50:
        return "moderado", value
    if value < 0.75:
        return "alto", value
    return "critico", value


def build_hydros_context_from_dssat_outputs(
    output_dir: str | "Path",
    *,
    scenario_id: str,
    location: str = "EUA_FL_Gainesville",
    soil_id: str = "IBSB910015",
    crop: str = "soja",
    management_unit: str | None = None,
) -> pd.DataFrame:
    """Constrói contextos diários auditáveis a partir dos ``.OUT`` reais.

    O DataFrame resultante contém duas famílias de campos:

    1. os campos canônicos exigidos pelo Hydros;
    2. colunas ``dssat_*`` e ``bridge_*`` com dados físicos e proveniência.

    Nenhum resultado terminal futuro é copiado para dias anteriores. O campo
    ``produtividade`` usa somente GWAD do próprio dia como proxy causal de massa
    de grãos acumulada, e a limitação semântica fica registrada no DataFrame.
    """

    from pathlib import Path

    output_dir = Path(output_dir)
    soil_class, soil_provenance = map_soil_to_broad_texture(soil_id)
    if soil_class is None:
        raise ValueError(f"Perfil de solo não mapeado para o Experimento II-B: {soil_id}")

    weather = _load_single_table(output_dir, "Weather.OUT")
    plant = _load_single_table(output_dir, "PlantGro.OUT")
    soilwat = _load_single_table(output_dir, "SoilWat.OUT")
    soilwater = _load_single_table(output_dir, "SoilWater.OUT")
    et = _load_single_table(output_dir, "ET.OUT")

    # PlantGro e Weather usam DAS 1..N. SoilWat contém uma linha DAS=0 para o
    # estado inicial, necessária para diferenciar a irrigação cumulativa IRRC.
    base = weather[["YEAR", "DOY", "DAS", "PRED", "TMXD", "TMND", "TAVD"]].copy()
    base = _merge_on_das(base, plant, ["DAP", "L#SD", "GSTD", "GWAD", "RDPD", "WSPD", "WSGD", "LAID"])
    base = _merge_on_das(base, soilwater, [
        *[f"LL{i}D" for i in range(1, 10)],
        *[f"DUL{i}D" for i in range(1, 10)],
        *[f"SW{i}D" for i in range(1, 10)],
    ])
    base = _merge_on_das(base, et, ["ETAA", "EOAA", "EOPA", "EOSA"])

    sw = soilwat.copy().sort_values("DAS", kind="stable")
    sw["IRR_DAILY_EFFECTIVE"] = pd.to_numeric(sw["IRRC"], errors="raise").diff().fillna(
        pd.to_numeric(sw["IRRC"], errors="raise")
    )
    sw["DRN_DAILY"] = pd.to_numeric(sw["DRNC"], errors="raise").diff().fillna(
        pd.to_numeric(sw["DRNC"], errors="raise")
    )
    base = _merge_on_das(
        base,
        sw,
        ["SWTD", "SWXD", "DRNC", "ROFC", "IRRC", "IR#C", "IRR_DAILY_EFFECTIVE", "DRN_DAILY"],
    )

    if base.isna().any().any():
        missing = base.columns[base.isna().any()].tolist()
        raise ValueError(f"Falha de alinhamento entre saídas DSSAT. Colunas com NA: {missing}")

    # O gerador DSSAT legado do projeto já usa TAVD - 10 como incremento
    # térmico. Preservamos o mesmo contrato para permitir comparação direta.
    base["graus_dia_periodo"] = (pd.to_numeric(base["TAVD"]) - 10.0).clip(lower=0.0)
    base["soma_termica_acumulada"] = base["graus_dia_periodo"].cumsum()

    root_metrics = pd.DataFrame([_root_zone_water_metrics(row) for _, row in base.iterrows()])
    base = pd.concat([base.reset_index(drop=True), root_metrics], axis=1)

    stages: list[str] = []
    stage_sources: list[str] = []
    kcs: list[float] = []
    kc_sources: list[str] = []
    stress_classes: list[str] = []
    stress_values: list[float] = []

    for _, row in base.iterrows():
        stage, stage_source = _map_gstd_to_hydros_stage(row["GSTD"], row["L#SD"])
        kc, kc_source = _kc_for_daily_state(row["GSTD"], stage)
        stress_class, stress_value = _stress_class_from_dssat(row["WSPD"], row["WSGD"])
        stages.append(stage)
        stage_sources.append(stage_source)
        kcs.append(kc)
        kc_sources.append(kc_source)
        stress_classes.append(stress_class)
        stress_values.append(stress_value)

    unit = management_unit or scenario_id
    dates = pd.to_datetime(
        base["YEAR"].astype(int).astype(str) + base["DOY"].astype(int).astype(str).str.zfill(3),
        format="%Y%j",
    )

    out = pd.DataFrame({
        "data": dates.dt.strftime("%Y/%m/%d"),
        "talhao": unit,
        "unidade_manejo": unit,
        "propriedade_id": "UF_Gainesville",
        "cenario_id": scenario_id,
        "dssat_run": scenario_id,
        "loc": location,
        "solo": soil_class,
        "cultura": crop,
        "precipitacao": pd.to_numeric(base["PRED"]).astype(float),
        "temperatura": pd.to_numeric(base["TAVD"]).astype(float),
        "temp_maxima": pd.to_numeric(base["TMXD"]).astype(float),
        "temp_minima": pd.to_numeric(base["TMND"]).astype(float),
        "graus_dia_periodo": base["graus_dia_periodo"].astype(float),
        "soma_termica_acumulada": base["soma_termica_acumulada"].astype(float),
        "graus_dia": base["graus_dia_periodo"].astype(float),
        "evapotranspiracao": pd.to_numeric(base["ETAA"]).astype(float),
        "coeficiente_cultura": kcs,
        "umidade_solo": base["umidade_solo_hydros_pct"].astype(float),
        "agua_disponivel": base["agua_disponivel_hydros_mm_equivalente"].astype(float),
        "irrigacao_aplicada": pd.to_numeric(base["IRR_DAILY_EFFECTIVE"]).clip(lower=0.0).astype(float),
        "irrigacao_ativa": pd.to_numeric(base["IRR_DAILY_EFFECTIVE"]).gt(0.0),
        "origem_estado_irrigacao": "DSSAT_SoilWat_IRRC_incremento_efetivo",
        "estagio_fenologico": stages,
        "estresse_hidrico": stress_classes,
        # Proxy causal, não previsão de rendimento terminal. Mantido porque o
        # Aprod atual exige valor numérico e porque GWAD não consulta o futuro.
        "produtividade": pd.to_numeric(base["GWAD"]).astype(float),
        "dia_safra": pd.to_numeric(base["DAS"]).astype(int),
        "dap": pd.to_numeric(base["DAP"]).astype(int),
    })

    # Dados brutos e derivados para auditoria científica.
    out["dssat_soil_id"] = soil_id
    out["dssat_soil_description"] = IBSB910015.description
    out["bridge_solo_proveniencia"] = soil_provenance
    out["dssat_SWTD_mm"] = pd.to_numeric(base["SWTD"]).astype(float)
    out["dssat_SWXD_mm"] = pd.to_numeric(base["SWXD"]).astype(float)
    out["dssat_RDPD_m"] = pd.to_numeric(base["RDPD"]).astype(float)
    out["dssat_WSPD"] = pd.to_numeric(base["WSPD"]).astype(float)
    out["dssat_WSGD"] = pd.to_numeric(base["WSGD"]).astype(float)
    out["dssat_estresse_max"] = stress_values
    out["dssat_GSTD"] = pd.to_numeric(base["GSTD"]).astype(float)
    out["dssat_L#SD"] = pd.to_numeric(base["L#SD"]).astype(float)
    out["dssat_GWAD_kg_ha"] = pd.to_numeric(base["GWAD"]).astype(float)
    out["dssat_LAID"] = pd.to_numeric(base["LAID"]).astype(float)
    out["dssat_ETAA_mm"] = pd.to_numeric(base["ETAA"]).astype(float)
    out["dssat_EOAA_mm"] = pd.to_numeric(base["EOAA"]).astype(float)
    out["dssat_IRRC_cumulativo_efetivo_mm"] = pd.to_numeric(base["IRRC"]).astype(float)
    out["dssat_IR_apps_cumulativas"] = pd.to_numeric(base["IR#C"]).astype(float)
    out["dssat_drenagem_cumulativa_mm"] = pd.to_numeric(base["DRNC"]).astype(float)
    out["dssat_drenagem_diaria_mm"] = pd.to_numeric(base["DRN_DAILY"]).clip(lower=0.0).astype(float)
    out["dssat_escoamento_cumulativo_mm"] = pd.to_numeric(base["ROFC"]).astype(float)
    for col in root_metrics.columns:
        out[f"bridge_{col}"] = root_metrics[col].astype(float).values
    out["bridge_estagio_proveniencia"] = stage_sources
    out["bridge_kc_proveniencia"] = kc_sources
    out["bridge_umidade_semantica"] = "percentual_agua_extraivel_na_zona_radicular_REW"
    out["bridge_agua_disponivel_semantica"] = (
        "REW_zona_radicular_normalizada_pela_PAWC_total_do_perfil_mm_equivalente"
    )
    out["bridge_produtividade_semantica"] = (
        "GWAD_massa_de_graos_acumulada_proxy_causal_nao_produtividade_final_estimada"
    )
    out["bridge_kc_semantica"] = "Kc_externo_por_fase_soja_nao_derivado_de_ETAA_EOAA"
    out["bridge_thermal_semantica"] = "TAVD_menos_10C_contrato_legado_do_experimento"

    return out
