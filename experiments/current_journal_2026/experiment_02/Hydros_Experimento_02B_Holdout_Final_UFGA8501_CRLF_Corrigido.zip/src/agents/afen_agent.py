"""
Afen Agent do Hydros.

Afen significa Agente Fenológico.

Responsabilidade no modelo Hydros:
analisar as variáveis fenológicas do histórico de contexto
e produzir a evidência fenológica Efen.

Variáveis analisadas:
ef = estágio fenológico
kc = coeficiente de cultura
gd = soma térmica

Saída:
Efen em {adequada, atencao, critica}
"""


from src.config.hydros_terms import (
    LIMIARES_AGENTES,
    TAMANHO_JANELA_HISTORICA_PADRAO,
    validar_tamanho_janela_historica,
)

class AfenAgent:
    """
    Agente fenológico do modelo Hydros.
    """

    def __init__(self, tamanho_janela=TAMANHO_JANELA_HISTORICA_PADRAO):
        """
        Inicializa o agente fenológico.
        """

        self.tamanho_janela = validar_tamanho_janela_historica(tamanho_janela)
        self.nome_evidencia = "Efen"
        self.limiares = dict(LIMIARES_AGENTES["Afen"])

        self.variaveis_modelo = [
            "ef",
            "kc",
            "gd"
        ]

        self.colunas_csv = [
            "estagio_fenologico",
            "coeficiente_cultura",
            "graus_dia_periodo",
            "soma_termica_acumulada"
        ]

    def analisar(self, df):
        """
        Analisa o histórico de contexto e gera a evidência fenológica Efen.
        """

        janela = df.tail(self.tamanho_janela)
        contexto_atual = janela.iloc[-1]

        estagio_fenologico = str(
            contexto_atual["estagio_fenologico"]
        ).upper()

        coeficiente_cultura = contexto_atual["coeficiente_cultura"]
        graus_dia_periodo_atual = contexto_atual["graus_dia_periodo"]
        soma_termica_acumulada = contexto_atual["soma_termica_acumulada"]

        kc_medio = janela["coeficiente_cultura"].mean()
        graus_dia_periodo_medio = janela["graus_dia_periodo"].mean()

        primeiro_kc = janela["coeficiente_cultura"].iloc[0]
        ultimo_kc = janela["coeficiente_cultura"].iloc[-1]

        primeira_soma_termica = janela["soma_termica_acumulada"].iloc[0]
        ultima_soma_termica = janela["soma_termica_acumulada"].iloc[-1]
        incremento_termico_janela = ultima_soma_termica - primeira_soma_termica

        if ultimo_kc > primeiro_kc:
            tendencia_kc = "aumento"
        elif ultimo_kc < primeiro_kc:
            tendencia_kc = "queda"
        else:
            tendencia_kc = "estavel"

        # A soma térmica acumulada é monotônica por definição. Por isso, sua
        # simples tendência de aumento não é usada como criticidade. O agente
        # registra o acumulado e o incremento térmico recente para rastreabilidade.
        tendencia_soma_termica = (
            "aumento" if incremento_termico_janela > 0 else "estavel"
        )

        score = 0
        regras_acionadas = []

        # Regra fenológica 1:
        # fases reprodutivas tendem a ser mais sensíveis ao déficit hídrico
        if estagio_fenologico in ["R1", "R2"]:
            score += 1
            regras_acionadas.append(
                "fase reprodutiva inicial com maior atenção hídrica"
            )

        elif estagio_fenologico in ["R3", "R4", "R5"]:
            score += 2
            regras_acionadas.append(
                "fase reprodutiva sensível ao déficit hídrico"
            )

        # Regra fenológica 2:
        # fases vegetativas avançadas também exigem atenção
        if estagio_fenologico in ["V4", "V5", "V6"]:
            score += 1
            regras_acionadas.append(
                "fase vegetativa avançada com demanda crescente"
            )

        # Regra fenológica 3:
        # Kc elevado indica maior demanda hídrica da cultura
        if coeficiente_cultura >= self.limiares["kc_elevado"]:
            score += 2
            regras_acionadas.append(
                "coeficiente de cultura elevado"
            )

        elif coeficiente_cultura >= self.limiares["kc_moderado"]:
            score += 1
            regras_acionadas.append(
                "coeficiente de cultura moderadamente elevado"
            )

        # Regra fenológica 4:
        # o limiar legado de 27 refere-se ao incremento térmico do período,
        # não à soma térmica acumulada. O acumulado permanece como descritor
        # fenológico e não recebe um limiar arbitrário nesta versão.
        if graus_dia_periodo_atual >= self.limiares["graus_dia_periodo_elevado"]:
            score += 1
            regras_acionadas.append(
                "incremento térmico do período elevado"
            )

        # Regra fenológica 5:
        # aumento do Kc indica crescimento da demanda hídrica
        if tendencia_kc == "aumento":
            score += 1
            regras_acionadas.append(
                "tendência de aumento do coeficiente de cultura"
            )

        # A soma térmica acumulada cresce ao longo do ciclo por construção;
        # seu aumento não acrescenta criticidade automaticamente. A informação
        # permanece disponível nos indicadores e no APS.

        # Regra de redução:
        # fase inicial e Kc baixo indicam menor demanda fenológica
        if (
            estagio_fenologico in ["V1", "V2", "V3"]
            and coeficiente_cultura < self.limiares["kc_baixo_fase_inicial"]
        ):
            score -= 1
            regras_acionadas.append(
                "fase inicial com baixo coeficiente de cultura"
            )

        if score < 0:
            score = 0

        evidencia = self.converter_score_para_evidencia(score)
        confianca = self.calcular_confianca(score)

        return {
            "agente": "Afen",
            "nome_agente": "Agente Fenológico",
            "evidencia_nome": self.nome_evidencia,
            "Efen": evidencia,
            "evidencia": evidencia,
            "criticidade": evidencia,
            "score": score,
            "confianca": confianca,
            "variaveis_modelo": self.variaveis_modelo,
            "colunas_csv": self.colunas_csv,
            "indicadores": {
                "estagio_fenologico": estagio_fenologico,
                "coeficiente_cultura_atual": coeficiente_cultura,
                "coeficiente_cultura_medio": round(kc_medio, 2),
                "graus_dia_periodo_atual": graus_dia_periodo_atual,
                "graus_dia_periodo_medio": round(graus_dia_periodo_medio, 2),
                "soma_termica_acumulada": soma_termica_acumulada,
                "incremento_termico_janela": round(incremento_termico_janela, 2),
                "tendencia_kc": tendencia_kc,
                "tendencia_soma_termica": tendencia_soma_termica
            },
            "regras_acionadas": regras_acionadas,
            "motivo": "análise fenológica baseada em estágio fenológico, coeficiente de cultura e soma térmica"
        }

    def converter_score_para_evidencia(self, score):
        """
        Converte o score fenológico em evidência Efen.
        """

        if score <= 1:
            return "adequada"

        if score <= 3:
            return "atencao"

        if score <= 5:
            return "atencao"

        return "critica"

    def calcular_confianca(self, score):
        """
        Calcula uma confiança simples para a evidência fenológica.
        """

        confianca = score / 6

        if confianca > 1:
            confianca = 1

        return round(confianca, 2)
