"""Motor principal do Hydros.

Coordena o fluxo da arquitetura híbrida orientada por princípios de
Agentic AI:

H(Ui) -> agentes especializados -> AIEC -> Ehc
C(t), H(Ui) -> ARG -> Earg
C(t), H(Ui) -> APS -> Eaps
Ehc, Earg, Eaps -> AMDH -> D(Ui)

O motor oferece dois modos experimentais:

- historico: utiliza C(t) e H(Ui);
- sem_historico: utiliza somente C(t).

Além de manter todas as chaves usadas pela interface atual, o motor agora
gera ``registro_execucao`` e ``rastreabilidade`` em formato serializável.
Esses registros documentam agentes, evidências, regras, resultado preditivo,
confiança, completude, conflito, ação, verificação semântica e rastreabilidade.
"""

from __future__ import annotations

from typing import Any, Dict, Optional
from time import perf_counter

import pandas as pd

from src.agents.aclim_agent import AclimAgent
from src.agents.ahid_agent import AhidAgent
from src.agents.afen_agent import AfenAgent
from src.agents.ageo_agent import AgeoAgent
from src.agents.aprod_agent import AprodAgent
from src.agents.ahist_agent import AhistAgent
from src.agents.aiec_agent import AIECAgent
from src.agents.arg_agent import ARGAgent
from src.agents.aps_agent import APSAgent
from src.agents.amdh_agent import AMDHAgent
from src.config.hydros_terms import (
    MODO_EXECUCAO_PADRAO,
    MODOS_EXECUCAO,
    TAMANHO_JANELA_HISTORICA_PADRAO,
    VERSAO_ARQUITETURA,
    validar_tamanho_janela_historica,
)
from src.core.contracts import build_execution_trace
from src.core.evidence_quality import enrich_agent_evidence
from src.core.irrigation_state import infer_irrigation_state
from src.core.thermal_time import normalizar_tempo_termico
from src.ontology.hydros_onto import HydrosOnto


class HydrosEngine:
    """Executa o fluxo completo do modelo Hydros."""

    def __init__(
        self,
        algoritmo_aps: str = "random_forest",
        modo_execucao: str = MODO_EXECUCAO_PADRAO,
        tamanho_janela_historica: int = TAMANHO_JANELA_HISTORICA_PADRAO,
    ) -> None:
        self.tamanho_janela_historica = validar_tamanho_janela_historica(
            tamanho_janela_historica
        )

        self.aclim = AclimAgent(self.tamanho_janela_historica)
        self.ahid = AhidAgent(self.tamanho_janela_historica)
        self.afen = AfenAgent(self.tamanho_janela_historica)
        self.ageo = AgeoAgent()
        self.aprod = AprodAgent(self.tamanho_janela_historica)
        self.ahist = AhistAgent(self.tamanho_janela_historica)

        self.aiec = AIECAgent()
        self.arg = ARGAgent(self.tamanho_janela_historica)

        self.algoritmo_aps = algoritmo_aps
        self.aps = APSAgent(
            algoritmo=algoritmo_aps,
            tamanho_janela=self.tamanho_janela_historica,
        )
        self.amdh = AMDHAgent()
        self.hydros_onto = HydrosOnto()

        self.modo_execucao = self.validar_modo(modo_execucao)

    def executar(
        self,
        df: pd.DataFrame,
        modo_execucao: Optional[str] = None,
        propriedade_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Mantém compatibilidade com a interface atual."""
        return self.processar(
            df,
            modo_execucao=modo_execucao,
            propriedade_id=propriedade_id,
        )

    def processar(
        self,
        df: pd.DataFrame,
        modo_execucao: Optional[str] = None,
        propriedade_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Executa o Hydros no modo histórico ou sem histórico."""

        inicio_processamento = perf_counter()
        self.validar_dataframe(df)
        dataframe_normalizado = normalizar_tempo_termico(df)
        propriedade_resolvida = self.resolver_propriedade_id(
            dataframe_normalizado,
            propriedade_id,
        )
        if "propriedade_id" not in dataframe_normalizado.columns:
            dataframe_normalizado = dataframe_normalizado.copy()
            dataframe_normalizado["propriedade_id"] = propriedade_resolvida

        modo = self.validar_modo(
            modo_execucao if modo_execucao is not None else self.modo_execucao
        )

        historico_completo = dataframe_normalizado.copy()
        contexto_atual_df = historico_completo.tail(1).copy()
        contexto_atual = contexto_atual_df.iloc[-1].to_dict()

        # O estado operacional é tratado separadamente da lâmina aplicada.
        # Fontes que informam irrigacao_ativa possuem prioridade; na ausência
        # desse campo, o sistema registra que realizou uma inferência por
        # irrigacao_aplicada, sem ocultar essa aproximação.
        estado_irrigacao = infer_irrigation_state(contexto_atual)
        contexto_atual["irrigacao_ativa"] = estado_irrigacao.active
        contexto_atual["origem_estado_irrigacao"] = estado_irrigacao.source
        contexto_atual["confianca_estado_irrigacao"] = (
            estado_irrigacao.confidence
        )

        # No modo histórico, os agentes recebem H(Ui).
        # No modo sem Histórico, recebem apenas C(t).
        dados_execucao = (
            historico_completo
            if modo == "historico"
            else contexto_atual_df
        )

        resultado_aclim = enrich_agent_evidence(
            self.aclim.analisar(dados_execucao),
            dados_execucao,
            "Aclim",
            modo,
            history_window_size=self.tamanho_janela_historica,
        )
        resultado_ahid = enrich_agent_evidence(
            self.ahid.analisar(dados_execucao),
            dados_execucao,
            "Ahid",
            modo,
            history_window_size=self.tamanho_janela_historica,
        )
        resultado_afen = enrich_agent_evidence(
            self.afen.analisar(dados_execucao),
            dados_execucao,
            "Afen",
            modo,
            history_window_size=self.tamanho_janela_historica,
        )
        resultado_ageo = enrich_agent_evidence(
            self.ageo.analisar(dados_execucao),
            dados_execucao,
            "Ageo",
            modo,
            history_window_size=1,
        )
        resultado_aprod = enrich_agent_evidence(
            self.aprod.analisar(dados_execucao),
            dados_execucao,
            "Aprod",
            modo,
            history_window_size=self.tamanho_janela_historica,
        )

        if modo == "historico":
            resultado_ahist = enrich_agent_evidence(
                self.ahist.analisar(historico_completo),
                historico_completo,
                "Ahist",
                modo,
                history_window_size=self.tamanho_janela_historica,
            )
        else:
            resultado_ahist = enrich_agent_evidence(
                self.criar_evidencia_historica_desativada(),
                contexto_atual_df,
                "Ahist",
                modo,
                history_window_size=self.tamanho_janela_historica,
            )

        resultado_aiec = self.aiec.integrar(
            resultado_aclim,
            resultado_ahid,
            resultado_afen,
            resultado_ageo,
            resultado_aprod,
            resultado_ahist,
        )
        resultado_aiec["modo_execucao"] = modo

        resultado_arg = enrich_agent_evidence(
            self.arg.avaliar(dados_execucao),
            dados_execucao,
            "ARG",
            modo,
            history_window_size=self.tamanho_janela_historica,
        )
        resultado_arg["agente_modelo"] = "ARG"
        resultado_arg["evidencia_nome"] = "Earg"
        resultado_arg["Earg"] = resultado_arg.get(
            "evidencia",
            resultado_arg.get("criticidade", "atencao"),
        )
        resultado_arg["modo_execucao"] = modo

        # A HydrosOnto é consultada somente após Earg. A inferência semântica
        # verifica a condição hídrica, mas não altera confiança, peso ou escore.
        inferencia_semantica = self.hydros_onto.infer(
            dados_execucao,
            mode=modo,
            condition_hint=resultado_arg.get("Earg"),
            arg_rules=list(resultado_arg.get("regras_acionadas", [])),
        )
        inferencia_semantica_dict = inferencia_semantica.to_dict()
        resultado_arg["inferencia_semantica"] = inferencia_semantica_dict
        resultado_arg["consistencia_semantica"] = (
            inferencia_semantica_dict["consistency"]
        )
        resultado_arg["impacto_semantico"] = 0.0
        resultado_arg["regras_semanticas"] = list(
            inferencia_semantica_dict.get("rules_triggered", [])
        )

        resultado_aps = self.aps.classificar(dados_execucao)
        resultado_aps["agente_modelo"] = "APS"
        resultado_aps["evidencia_nome"] = "Eaps"
        resultado_aps["Eaps"] = resultado_aps.get(
            "evidencia",
            resultado_aps.get("criticidade", "moderado"),
        )
        resultado_aps["modo_execucao"] = modo

        resultado_amdh = self.amdh.decidir(
            resultado_arg,
            resultado_aiec,
            resultado_aps,
            contexto_atual,
            estado_irrigacao=estado_irrigacao,
            verificacao_semantica=inferencia_semantica_dict,
        )
        resultado_amdh["modo_execucao"] = modo
        resultado_amdh["contextos_utilizados"] = len(dados_execucao)

        rastreabilidade_semantica = self.hydros_onto.build_action_trace(
            action=resultado_amdh.get("D(Ui)"),
            unit_id=str(
                contexto_atual.get(
                    "unidade_manejo",
                    contexto_atual.get("talhao", "unidade_nao_informada"),
                )
            ),
            timestamp=str(
                contexto_atual.get("data", "periodo_nao_informado")
            ),
            semantic_inference=inferencia_semantica_dict,
            evidence_names=["Ehc", "Earg", "Eaps"],
            agronomic_rules=list(resultado_arg.get("regras_acionadas", [])),
        )
        resultado_amdh["rastreabilidade_semantica"] = rastreabilidade_semantica

        resultados_agentes = {
            "aclim": resultado_aclim,
            "ahid": resultado_ahid,
            "afen": resultado_afen,
            "ageo": resultado_ageo,
            "aprod": resultado_aprod,
            "ahist": resultado_ahist,
            "aiec": resultado_aiec,
            "arg": resultado_arg,
            "aps": resultado_aps,
        }

        tempo_processamento_ms = (perf_counter() - inicio_processamento) * 1000.0

        registro_execucao = build_execution_trace(
            mode=modo,
            architecture_version=VERSAO_ARQUITETURA,
            history_dataframe=historico_completo,
            current_context=contexto_atual,
            available_contexts=len(historico_completo),
            used_contexts=len(dados_execucao),
            agent_results=resultados_agentes,
            amdh_result=resultado_amdh,
            semantic_inferences=[inferencia_semantica_dict],
            property_id=propriedade_resolvida,
            processing_time_ms=tempo_processamento_ms,
            metadata={
                "aps_algorithm": self.algoritmo_aps,
                "history_window_size": self.tamanho_janela_historica,
                "aps_training_window_size": self.aps.tamanho_janela_treinamento,
                "aps_window_compatible": self.aps.janela_compativel_modelo,
                "ontology_integrated": "semantic_verification_and_traceability",
                "ontology": "HydrosOnto",
                "ontology_version": inferencia_semantica_dict[
                    "ontology_version"
                ],
                "ontology_backend": inferencia_semantica_dict["backend"],
                "physical_irrigation_actuation": False,
                "thermal_time_contract": {
                    "gd": "soma_termica_acumulada",
                    "period_increment": "graus_dia_periodo",
                    "legacy_alias": "graus_dia",
                },
                "semantic_traceability": rastreabilidade_semantica,
                "irrigation_state": estado_irrigacao.to_dict(),
            },
        ).to_dict()

        return {
            "modo_execucao": modo,
            "descricao_modo": MODOS_EXECUCAO[modo],
            "propriedade_id": propriedade_resolvida,
            "tempo_processamento_ms": registro_execucao["processing_time_ms"],
            "quantidade_contextos_disponiveis": len(historico_completo),
            "quantidade_contextos_utilizados": len(dados_execucao),
            "tamanho_janela_historica": self.tamanho_janela_historica,
            "H(Ui)": (
                "histórico completo utilizado"
                if modo == "historico"
                else "histórico preservado, mas não utilizado no processamento"
            ),
            "C(t)": contexto_atual,
            "ultimo_contexto": contexto_atual,
            "estado_irrigacao": estado_irrigacao.to_dict(),
            "hydros_onto": inferencia_semantica_dict,
            "inferencias_semanticas": [inferencia_semantica_dict],
            "rastreabilidade_semantica": rastreabilidade_semantica,
            "aclim": resultado_aclim,
            "ahid": resultado_ahid,
            "afen": resultado_afen,
            "ageo": resultado_ageo,
            "aprod": resultado_aprod,
            "ahist": resultado_ahist,
            "aiec": resultado_aiec,
            "arg": resultado_arg,
            "aps": resultado_aps,
            "amdh": resultado_amdh,
            # Novos contratos padronizados. As duas chaves apontam para o
            # mesmo conteúdo para facilitar o uso pela API, banco e artigo.
            "registro_execucao": registro_execucao,
            "rastreabilidade": registro_execucao,
        }

    @staticmethod
    def resolver_propriedade_id(
        df: pd.DataFrame,
        propriedade_id: Optional[str] = None,
    ) -> str:
        """Resolve a propriedade associada à execução sem criar um cadastro novo."""

        if propriedade_id is not None and str(propriedade_id).strip():
            return str(propriedade_id).strip()

        for coluna in ("propriedade_id", "propriedade", "property_id"):
            if coluna not in df.columns:
                continue
            valores = [
                str(valor).strip()
                for valor in df[coluna].dropna().unique().tolist()
                if str(valor).strip()
            ]
            if len(valores) > 1:
                raise ValueError(
                    "Uma execução do Hydros deve estar associada a uma única propriedade."
                )
            if valores:
                return valores[0]

        return "propriedade_nao_informada"

    @staticmethod
    def validar_modo(modo_execucao: str) -> str:
        modo = str(modo_execucao or "").strip().lower()

        aliases = {
            "histórico": "historico",
            "instantaneo": "sem_historico",
            "instantâneo": "sem_historico",
            "sem histórico": "sem_historico",
            "sem-historico": "sem_historico",
            "sem-histórico": "sem_historico",
        }
        modo = aliases.get(modo, modo)

        if modo not in MODOS_EXECUCAO:
            modos_validos = ", ".join(sorted(MODOS_EXECUCAO.keys()))
            raise ValueError(
                f"Modo de execução inválido: {modo_execucao}. "
                f"Use um destes valores: {modos_validos}."
            )

        return modo

    @staticmethod
    def validar_dataframe(df: pd.DataFrame) -> None:
        if not isinstance(df, pd.DataFrame):
            raise TypeError("A entrada do Hydros deve ser um DataFrame.")

        if df.empty:
            raise ValueError("O histórico de contexto não pode estar vazio.")

        for coluna in ("unidade_manejo", "talhao", "unit_id"):
            if coluna not in df.columns:
                continue
            unidades = [
                str(valor).strip()
                for valor in df[coluna].dropna().unique().tolist()
                if str(valor).strip()
            ]
            if len(unidades) > 1:
                raise ValueError(
                    "Uma execução do Hydros deve conter contextos de uma única unidade de manejo."
                )
            break

    @staticmethod
    def criar_evidencia_historica_desativada() -> Dict[str, Any]:
        """Produz uma evidência neutra e de peso efetivo zero."""

        return {
            "agente": "Ahist",
            "nome_agente": "Agente Histórico-Contextual",
            "evidencia_nome": "Ehist",
            "Ehist": "atencao",
            "evidencia": "atencao",
            "criticidade": "atencao",
            "condicao_hidrica": "atencao",
            "score": 0.0,
            "confianca": 0.0,
            "completude": 0.0,
            "qualidade": 0.0,
            "desativado": True,
            "modo_execucao": "sem_historico",
            "variaveis_modelo": [],
            "indicadores": {
                "historico_utilizado": False,
                "quantidade_contextos": 0,
            },
            "regras_acionadas": [],
            "motivo": (
                "Ehist foi desativada porque o modo sem Histórico utiliza "
                "somente o contexto atual C(t)."
            ),
        }
