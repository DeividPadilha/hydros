"""Validador do CSV de entrada do Hydros.

O contrato canônico usa ``soma_termica_acumulada`` para representar ``gd``
da tese. Arquivos legados com ``graus_dia`` continuam aceitos, mas são
normalizados para ``graus_dia_periodo`` + ``soma_termica_acumulada`` antes da
validação.
"""

import pandas as pd

from src.core.thermal_time import normalizar_tempo_termico


class CSVValidator:
    """Valida e normaliza históricos de contexto agrícolas."""

    def __init__(self):
        self.colunas_obrigatorias = [
            "data",
            "talhao",
            "cultura",
            "loc",
            "solo",
            "precipitacao",
            "temperatura",
            "graus_dia_periodo",
            "soma_termica_acumulada",
            "evapotranspiracao",
            "coeficiente_cultura",
            "umidade_solo",
            "agua_disponivel",
            "irrigacao_aplicada",
            "estagio_fenologico",
            "estresse_hidrico",
            "produtividade",
        ]
        self.colunas_numericas = [
            "precipitacao",
            "temperatura",
            "graus_dia_periodo",
            "soma_termica_acumulada",
            "evapotranspiracao",
            "coeficiente_cultura",
            "umidade_solo",
            "agua_disponivel",
            "irrigacao_aplicada",
            "produtividade",
        ]

    def validar(self, df):
        """Retorna validade, erros e o DataFrame normalizado quando possível."""

        erros = []
        if not isinstance(df, pd.DataFrame):
            return {
                "valido": False,
                "erros": ["A entrada deve ser um DataFrame."],
                "dataframe_normalizado": None,
            }
        if df.empty:
            return {
                "valido": False,
                "erros": ["O arquivo CSV está vazio."],
                "dataframe_normalizado": df.copy(),
            }

        try:
            normalizado = normalizar_tempo_termico(df)
        except Exception as exc:
            return {
                "valido": False,
                "erros": [f"Tempo térmico inválido: {exc}"],
                "dataframe_normalizado": None,
            }

        for coluna in self.colunas_obrigatorias:
            if coluna not in normalizado.columns:
                erros.append(f"Coluna obrigatória ausente: {coluna}")

        if erros:
            return {
                "valido": False,
                "erros": erros,
                "dataframe_normalizado": normalizado,
            }

        if normalizado[self.colunas_obrigatorias].isnull().any().any():
            erros.append("Existem campos obrigatórios vazios.")

        try:
            pd.to_datetime(
                normalizado["data"],
                format="mixed",
                dayfirst=True,
                errors="raise",
            )
        except Exception:
            erros.append("A coluna data possui valores inválidos.")

        for coluna in self.colunas_numericas:
            try:
                normalizado[coluna] = pd.to_numeric(normalizado[coluna])
            except Exception:
                erros.append(f"A coluna {coluna} deve conter apenas números.")

        for coluna in self.colunas_numericas:
            if coluna in normalizado.columns and (normalizado[coluna] < 0).any():
                erros.append(f"A coluna {coluna} possui valores negativos inválidos.")

        if "coeficiente_cultura" in normalizado.columns:
            if (normalizado["coeficiente_cultura"] <= 0).any():
                erros.append(
                    "A coluna coeficiente_cultura deve possuir valores maiores que zero."
                )

        if "umidade_solo" in normalizado.columns:
            if (normalizado["umidade_solo"] > 100).any():
                erros.append("A coluna umidade_solo não pode ser maior que 100.")

        return {
            "valido": len(erros) == 0,
            "erros": erros,
            "dataframe_normalizado": normalizado,
        }
