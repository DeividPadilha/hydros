"""Normalização do tempo térmico usado pelo Hydros.

A tese define ``gd`` como soma térmica acumulada. Versões anteriores do
protótipo usavam a coluna ``graus_dia`` para um incremento térmico do período,
o que gerava ambiguidade semântica. A partir do checkpoint C, o contrato é:

- ``graus_dia_periodo``: incremento térmico observado no período;
- ``soma_termica_acumulada``: soma cronológica dos incrementos térmicos;
- ``graus_dia``: alias legado aceito apenas para compatibilidade de entrada.

A função deste módulo não inventa valores agronômicos. Quando recebe apenas a
coluna legada, ela a preserva como incremento do período e calcula a soma
acumulada por trajetória em ordem cronológica.
"""

from __future__ import annotations

from typing import Iterable, Sequence

import pandas as pd


LEGACY_THERMAL_COLUMN = "graus_dia"
PERIOD_THERMAL_COLUMN = "graus_dia_periodo"
ACCUMULATED_THERMAL_COLUMN = "soma_termica_acumulada"


def _group_columns(df: pd.DataFrame) -> list[str]:
    """Seleciona identificadores conservadores para reiniciar a soma térmica."""

    if "dssat_run" in df.columns:
        columns = ["dssat_run"]
        if "talhao" in df.columns:
            columns.append("talhao")
        return columns

    for identifier in ("trajetoria_id", "cenario_id", "cenario", "execucao_id", "safra"):
        if identifier in df.columns and df[identifier].nunique(dropna=False) > 1:
            columns = [identifier]
            if "talhao" in df.columns:
                columns.append("talhao")
            return columns

    columns: list[str] = []
    if "talhao" in df.columns:
        columns.append("talhao")
    if "cultura" in df.columns:
        columns.append("cultura")
    return columns


def _sort_columns(df: pd.DataFrame, group_columns: Sequence[str]) -> list[str]:
    columns = list(group_columns)
    if "data" in df.columns:
        columns.append("__hydros_data_termica")
    elif "dia_safra" in df.columns:
        columns.append("dia_safra")
    columns.append("__hydros_ordem_termica")
    return columns


def normalizar_tempo_termico(
    dataframe: pd.DataFrame,
    *,
    group_columns: Iterable[str] | None = None,
    preserve_legacy_alias: bool = True,
) -> pd.DataFrame:
    """Retorna uma cópia com tempo térmico semanticamente explícito.

    A prioridade é preservar ``soma_termica_acumulada`` quando ela já existe.
    Caso contrário, a soma é calculada a partir de ``graus_dia_periodo`` ou,
    por compatibilidade, da antiga coluna ``graus_dia``.
    """

    if not isinstance(dataframe, pd.DataFrame):
        raise TypeError("O tempo térmico deve ser normalizado em um DataFrame.")
    if dataframe.empty:
        return dataframe.copy()

    df = dataframe.copy()
    df["__hydros_ordem_termica"] = range(len(df))

    if "data" in df.columns:
        df["__hydros_data_termica"] = pd.to_datetime(
            df["data"], format="mixed", dayfirst=True, errors="coerce"
        )

    if PERIOD_THERMAL_COLUMN in df.columns:
        period = pd.to_numeric(df[PERIOD_THERMAL_COLUMN], errors="coerce")
    elif LEGACY_THERMAL_COLUMN in df.columns:
        period = pd.to_numeric(df[LEGACY_THERMAL_COLUMN], errors="coerce")
        df[PERIOD_THERMAL_COLUMN] = period
    else:
        period = None

    if ACCUMULATED_THERMAL_COLUMN in df.columns:
        accumulated = pd.to_numeric(
            df[ACCUMULATED_THERMAL_COLUMN], errors="coerce"
        )
        df[ACCUMULATED_THERMAL_COLUMN] = accumulated

        # Quando só há a soma acumulada, o incremento do período é recuperado
        # por diferença dentro da mesma trajetória. O primeiro valor equivale
        # ao incremento desde a origem da trajetória representada.
        if period is None:
            groups = list(group_columns or _group_columns(df))
            sorted_df = df.sort_values(_sort_columns(df, groups), kind="stable")
            if groups:
                recovered = sorted_df.groupby(groups, dropna=False)[
                    ACCUMULATED_THERMAL_COLUMN
                ].diff()
                first_mask = sorted_df.groupby(groups, dropna=False).cumcount().eq(0)
            else:
                recovered = sorted_df[ACCUMULATED_THERMAL_COLUMN].diff()
                first_mask = pd.Series(False, index=sorted_df.index)
                first_mask.iloc[0] = True
            recovered.loc[first_mask] = sorted_df.loc[
                first_mask, ACCUMULATED_THERMAL_COLUMN
            ]
            df.loc[sorted_df.index, PERIOD_THERMAL_COLUMN] = recovered.clip(lower=0)
            period = pd.to_numeric(df[PERIOD_THERMAL_COLUMN], errors="coerce")
    else:
        if period is None:
            raise ValueError(
                "Informe soma_termica_acumulada, graus_dia_periodo ou a coluna "
                "legada graus_dia."
            )

        groups = list(group_columns or _group_columns(df))
        sorted_df = df.sort_values(_sort_columns(df, groups), kind="stable")
        if groups:
            accumulated = sorted_df.groupby(groups, dropna=False)[
                PERIOD_THERMAL_COLUMN
            ].cumsum()
        else:
            accumulated = sorted_df[PERIOD_THERMAL_COLUMN].cumsum()
        df.loc[sorted_df.index, ACCUMULATED_THERMAL_COLUMN] = accumulated

    for column in (PERIOD_THERMAL_COLUMN, ACCUMULATED_THERMAL_COLUMN):
        df[column] = pd.to_numeric(df[column], errors="coerce").round(6)
        if df[column].isna().any():
            bad = df.index[df[column].isna()].tolist()[:10]
            raise ValueError(
                f"Valores térmicos inválidos em {column}. Linhas: {bad}"
            )
        if (df[column] < 0).any():
            raise ValueError(f"A coluna {column} não pode possuir valores negativos.")

    if preserve_legacy_alias:
        # O alias fica explicitamente associado ao incremento do período para
        # permitir leitura de arquivos antigos sem reintroduzir a ambiguidade
        # no contrato interno canônico.
        df[LEGACY_THERMAL_COLUMN] = df[PERIOD_THERMAL_COLUMN]

    drop_columns = ["__hydros_ordem_termica", "__hydros_data_termica"]
    return df.drop(columns=[c for c in drop_columns if c in df.columns])
