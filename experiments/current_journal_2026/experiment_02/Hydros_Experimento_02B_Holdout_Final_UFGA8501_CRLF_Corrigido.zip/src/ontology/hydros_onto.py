"""Integração semântica da HydrosOnto com o protótipo Hydros.

A fonte ontológica oficial é ``ontology/hydrosonto.owl``, implementada no
Protégé. Esta camada não cria limiares agronômicos próprios e não participa do
cálculo do escore do AMDH. Ela realiza duas funções compatíveis com a tese:

1. verificar semanticamente a condição hídrica por meio dos axiomas OWL que
   relacionam ``CondicaoHidrica`` às regras ``Regra_Condicao_*``;
2. produzir um registro semântico de rastreabilidade para a ação determinada
   pelo AMDH.

O protótipo usa RDFLib para consultar a ontologia. O raciocinador HermiT
continua sendo a referência para a avaliação formal no Protégé; aqui é aplicada
somente a consequência específica dos axiomas ``equivalentClass`` +
``hasValue`` presentes na própria HydrosOnto.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional
from uuid import uuid4

import pandas as pd
from rdflib import BNode, Graph, Namespace, OWL, RDF, URIRef
from rdflib.collection import Collection

from src.core.contracts import normalize_internal_level


HYDROS = Namespace("http://www.semanticweb.org/deivid/hydrosonto#")


@dataclass(frozen=True)
class SemanticInference:
    """Resultado de verificação/inferência semântica da HydrosOnto."""

    inference_id: str
    ontology: str
    ontology_version: str
    unit_id: str
    timestamp: str
    mode: str
    semantic_condition: str
    ontology_class: str
    source_rule: str
    consistency: str
    confidence: float
    completeness: float
    rules_triggered: List[str] = field(default_factory=list)
    facts_used: Dict[str, Any] = field(default_factory=dict)
    explanation: str = ""
    backend: str = "rdflib_axiom_verifier"
    affects_amdh_score: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class HydrosOnto:
    """Consulta a HydrosOnto oficial sem alterar o cálculo híbrido do Hydros."""

    ONTOLOGY_VERSION = "0.1"

    CONDITION_RULES = {
        "adequada": HYDROS.Regra_Condicao_Adequada,
        "atencao": HYDROS.Regra_Condicao_Atencao,
        "critica": HYDROS.Regra_Condicao_Critica,
    }

    CONDITION_CLASSES = {
        "adequada": HYDROS.CondicaoAdequada,
        "atencao": HYDROS.CondicaoAtencao,
        "critica": HYDROS.CondicaoCritica,
    }

    ACTION_CLASSES = {
        "iniciar_irrigacao": HYDROS.IniciarIrrigacao,
        "manter_irrigacao": HYDROS.ManterIrrigacao,
        "aumentar_irrigacao": HYDROS.AumentarIrrigacao,
        "reduzir_irrigacao": HYDROS.ReduzirIrrigacao,
        "finalizar_irrigacao": HYDROS.FinalizarIrrigacao,
    }

    REQUIRED_ENTITIES = (
        HYDROS.UnidadeManejo,
        HYDROS.HistoricoContexto,
        HYDROS.ContextoAgricola,
        HYDROS.CondicaoHidrica,
        HYDROS.CondicaoAdequada,
        HYDROS.CondicaoAtencao,
        HYDROS.CondicaoCritica,
        HYDROS.Evidencia,
        HYDROS.RegraAgronomica,
        HYDROS.AgenteInteligente,
        HYDROS.AcaoManejoHidrico,
        HYDROS.possuiHistoricoContexto,
        HYDROS.possuiContexto,
        HYDROS.possuiContextoDaUnidade,
        HYDROS.condicaoRelacionadaARegra,
        HYDROS.acaoParaUnidade,
        HYDROS.acaoConsideraContexto,
        HYDROS.acaoConsideraCondicao,
        HYDROS.acaoFundamentadaPorEvidencia,
        HYDROS.acaoAssociadaARegra,
        HYDROS.acaoDeterminadaPor,
        HYDROS.AMDH,
    )

    def __init__(self, ontology_path: Optional[str | Path] = None) -> None:
        root = Path(__file__).resolve().parents[2]
        self.ontology_path = Path(
            ontology_path or root / "ontology" / "hydrosonto.owl"
        )
        self.graph = Graph()
        self.backend = "rdflib_axiom_verifier"
        self.validation = self.validate_ontology()

    def validate_ontology(self) -> Dict[str, Any]:
        """Valida o OWL oficial e o vocabulário mínimo necessário ao Hydros."""

        if not self.ontology_path.exists():
            raise FileNotFoundError(
                f"Arquivo da HydrosOnto não encontrado: {self.ontology_path}"
            )

        self.graph.parse(self.ontology_path, format="xml")

        missing: List[str] = []
        for entity in self.REQUIRED_ENTITIES:
            if not any(self.graph.triples((entity, None, None))) and not any(
                self.graph.triples((None, None, entity))
            ):
                missing.append(self._local_name(entity))

        if missing:
            raise ValueError(
                "A HydrosOnto oficial não contém o vocabulário mínimo: "
                + ", ".join(missing)
            )

        classes = {
            item
            for item in self.graph.subjects(RDF.type, OWL.Class)
            if isinstance(item, URIRef) and str(item).startswith(str(HYDROS))
        }
        object_properties = set(
            self.graph.subjects(RDF.type, OWL.ObjectProperty)
        )
        datatype_properties = set(
            self.graph.subjects(RDF.type, OWL.DatatypeProperty)
        )
        individuals = set(self.graph.subjects(RDF.type, OWL.NamedIndividual))

        return {
            "path": str(self.ontology_path),
            "exists": True,
            "minimum_vocabulary_valid": True,
            "rdfxml_syntax_validated": True,
            "triples": len(self.graph),
            "classes": len(classes),
            "object_properties": len(object_properties),
            "datatype_properties": len(datatype_properties),
            "individuals": len(individuals),
            "backend": self.backend,
        }

    def infer(
        self,
        dataframe: pd.DataFrame,
        mode: str,
        condition_hint: Optional[str] = None,
        arg_rules: Optional[List[str]] = None,
    ) -> SemanticInference:
        """Infere a classe semântica a partir da regra ontológica associada.

        ``condition_hint`` representa a conclusão produzida pelo processamento
        agronômico. Ela é usada somente para selecionar a instância de regra
        formalizada na ontologia. O resultado da ontologia não altera Earg,
        Ehc, Eaps, seus pesos ou o escore do AMDH.
        """

        if not isinstance(dataframe, pd.DataFrame):
            raise TypeError("A HydrosOnto deve receber um DataFrame.")
        if dataframe.empty:
            raise ValueError("A HydrosOnto não pode verificar dados vazios.")

        normalized_mode = self._normalize_mode(mode)
        current = dataframe.iloc[-1]
        canonical_hint = normalize_internal_level(
            condition_hint
            if condition_hint is not None
            else current.get("estresse_hidrico", "atencao")
        )

        rule_uri = self.CONDITION_RULES[canonical_hint]
        inferred_class_uri = self._infer_class_from_rule(rule_uri)
        semantic_condition = self._condition_from_class(inferred_class_uri)

        unit_id = self._first_text(
            current, "unidade_manejo", "talhao", "unit_id", "cenario_id"
        )
        timestamp = self._first_text(
            current, "data", "timestamp", "data_hora", "date"
        )

        required_fields = (
            "precipitacao",
            "umidade_solo",
            "agua_disponivel",
            "evapotranspiracao",
            "estagio_fenologico",
        )
        available = sum(
            1
            for field_name in required_fields
            if field_name in dataframe.columns
            and pd.notna(current.get(field_name))
        )
        completeness = available / len(required_fields)

        consistency = (
            "concordante"
            if semantic_condition == canonical_hint
            else "divergente"
        )
        ontology_class = self._local_name(inferred_class_uri)
        source_rule = self._local_name(rule_uri)

        explanation = (
            "A HydrosOnto relacionou a condição hídrica à regra "
            f"{source_rule} e, pelos axiomas de equivalência implementados, "
            f"inferiu {ontology_class}. A inferência foi usada somente como "
            "verificação semântica e não alterou o escore do AMDH."
        )

        return SemanticInference(
            inference_id=str(uuid4()),
            ontology="HydrosOnto",
            ontology_version=self.ONTOLOGY_VERSION,
            unit_id=unit_id or "unidade_nao_informada",
            timestamp=timestamp or datetime.now(timezone.utc).isoformat(),
            mode=normalized_mode,
            semantic_condition=semantic_condition,
            ontology_class=ontology_class,
            source_rule=source_rule,
            consistency=consistency,
            confidence=1.0 if inferred_class_uri else 0.0,
            completeness=round(completeness, 4),
            rules_triggered=[source_rule] + list(arg_rules or []),
            facts_used={
                "condition_hint": canonical_hint,
                "rule_individual": source_rule,
                "axiom": (
                    "CondicaoHidrica and "
                    f"condicaoRelacionadaARegra value {source_rule}"
                ),
                "contextos_analisados": int(len(dataframe)),
            },
            explanation=explanation,
            backend=self.backend,
            affects_amdh_score=False,
        )

    def build_action_trace(
        self,
        *,
        action: Optional[str],
        unit_id: str,
        timestamp: str,
        semantic_inference: Mapping[str, Any],
        evidence_names: List[str],
        agronomic_rules: List[str],
    ) -> Dict[str, Any]:
        """Constrói a rastreabilidade semântica da ação sem alterar o OWL."""

        if not action:
            return {
                "registered": False,
                "reason": "processamento_inconclusivo_sem_acao",
                "ontology": "HydrosOnto",
            }

        action_class = self.ACTION_CLASSES.get(action)
        if action_class is None:
            return {
                "registered": False,
                "reason": "acao_nao_mapeada_na_ontologia",
                "action": action,
                "ontology": "HydrosOnto",
            }

        return {
            "registered": True,
            "ontology": "HydrosOnto",
            "action": action,
            "action_class": self._local_name(action_class),
            "determined_by": "AMDH",
            "unit_id": unit_id,
            "timestamp": timestamp,
            "semantic_condition": semantic_inference.get(
                "semantic_condition"
            ),
            "condition_class": semantic_inference.get("ontology_class"),
            "evidences": list(evidence_names),
            "agronomic_rules": list(agronomic_rules),
            "properties": {
                "acaoDeterminadaPor": "AMDH",
                "acaoParaUnidade": unit_id,
                "acaoConsideraContexto": timestamp,
                "acaoConsideraCondicao": semantic_inference.get(
                    "ontology_class"
                ),
                "acaoFundamentadaPorEvidencia": list(evidence_names),
                "acaoAssociadaARegra": list(agronomic_rules),
            },
            "persisted_in_ontology_file": False,
            "note": (
                "Registro semântico produzido para rastreabilidade. "
                "A persistência de novas instâncias no arquivo OWL é uma "
                "etapa operacional posterior."
            ),
        }

    def _infer_class_from_rule(self, rule_uri: URIRef) -> URIRef:
        """Aplica a consequência do equivalentClass/hasValue da ontologia."""

        for condition_class in self.CONDITION_CLASSES.values():
            for equivalent in self.graph.objects(
                condition_class, OWL.equivalentClass
            ):
                if not isinstance(equivalent, BNode):
                    continue
                list_node = self.graph.value(equivalent, OWL.intersectionOf)
                if list_node is None:
                    continue
                for item in Collection(self.graph, list_node):
                    if not isinstance(item, BNode):
                        continue
                    on_property = self.graph.value(item, OWL.onProperty)
                    has_value = self.graph.value(item, OWL.hasValue)
                    if (
                        on_property == HYDROS.condicaoRelacionadaARegra
                        and has_value == rule_uri
                    ):
                        return condition_class

        raise ValueError(
            "Não foi encontrado axioma de classificação para a regra "
            f"{self._local_name(rule_uri)}."
        )

    def _condition_from_class(self, class_uri: URIRef) -> str:
        for condition, uri in self.CONDITION_CLASSES.items():
            if uri == class_uri:
                return condition
        raise ValueError(
            "Classe de condição hídrica não reconhecida: "
            f"{self._local_name(class_uri)}"
        )

    @staticmethod
    def _normalize_mode(mode: str) -> str:
        text = str(mode or "").strip().lower()
        aliases = {
            "histórico": "historico",
            "instantaneo": "sem_historico",
            "instantâneo": "sem_historico",
            "sem histórico": "sem_historico",
            "sem-historico": "sem_historico",
            "sem-histórico": "sem_historico",
        }
        normalized = aliases.get(text, text)
        if normalized not in {"historico", "sem_historico"}:
            raise ValueError(f"Modo semântico inválido: {mode}")
        return normalized

    @staticmethod
    def _first_text(row: Mapping[str, Any], *keys: str) -> str:
        for key in keys:
            value = row.get(key)
            if value is not None and not pd.isna(value) and str(value).strip():
                return str(value)
        return ""

    @staticmethod
    def _local_name(uri: Any) -> str:
        text = str(uri)
        return text.rsplit("#", 1)[-1].rsplit("/", 1)[-1]
