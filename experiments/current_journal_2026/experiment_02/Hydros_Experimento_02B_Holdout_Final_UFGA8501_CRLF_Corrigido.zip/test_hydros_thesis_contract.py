"""Verificação simples do contrato do protótipo descrito no Capítulo 6 da tese.

O objetivo deste teste não é medir contribuição científica. Ele apenas comprova
que o protótipo executa os componentes e preserva a rastreabilidade prevista.
"""

from __future__ import annotations

from pathlib import Path
import tempfile

import pandas as pd

from src.database.database import Database
from src.services.hydros_engine import HydrosEngine


EXPECTED_AGENTS = {
    "Aclim", "Ahid", "Afen", "Ageo", "Aprod", "Ahist",
    "AIEC", "ARG", "APS", "AMDH",
}
EXPECTED_EVIDENCES = {
    "aclim", "ahid", "afen", "ageo", "aprod", "ahist",
    "aiec", "arg", "aps",
}
VALID_ACTIONS = {
    "iniciar_irrigacao",
    "manter_irrigacao",
    "aumentar_irrigacao",
    "reduzir_irrigacao",
    "finalizar_irrigacao",
    "nenhuma",
}


def main() -> None:
    data_path = Path("data/historico_contexto_exemplo.csv")
    dataframe = pd.read_csv(data_path)
    engine = HydrosEngine()

    result = engine.processar(
        dataframe,
        modo_execucao="historico",
        propriedade_id="P1_qualificacao",
    )
    trace = result["registro_execucao"]

    # 1-4: entrada, propriedade/unidade, contextos/histórico e atributos.
    assert trace["property_id"] == "P1_qualificacao"
    assert trace["unit_id"] == "Talhao_01"
    assert trace["available_contexts"] == len(dataframe)
    assert trace["used_contexts"] == len(dataframe)
    assert trace["historical_window"]["history_used"] is True
    assert "soma_termica_acumulada" in trace["current_context"]

    # 5-10: agentes, AIEC, ARG, APS, HydrosOnto e AMDH.
    assert set(trace["agents_executed"]) == EXPECTED_AGENTS
    assert set(trace["evidences"]) == EXPECTED_EVIDENCES
    assert "aiec" in result and "arg" in result and "aps" in result and "amdh" in result
    assert trace["semantic_inferences"]
    assert trace["consistency"]["semantic_verification"]["affects_amdh_score"] is False

    # 11-13: consistência/conflitos, ação e registro completo.
    assert 0.0 <= float(trace["consistency"]["decision_conflict"]) <= 1.0
    assert trace["decision"]["action"] in VALID_ACTIONS
    assert trace["decision"]["processing_status"] in {"conclusivo", "inconclusivo"}
    assert float(trace["processing_time_ms"]) >= 0.0
    assert trace["agronomic_rules"] is not None
    assert trace["predictive_result"]

    # A mesma arquitetura deve executar sem histórico, mudando apenas o acesso à memória.
    no_history = engine.processar(
        dataframe,
        modo_execucao="sem_historico",
        propriedade_id="P1_qualificacao",
    )["registro_execucao"]
    assert no_history["property_id"] == "P1_qualificacao"
    assert no_history["used_contexts"] == 1
    assert no_history["historical_window"]["history_used"] is False
    assert no_history["evidences"]["ahist"]["active"] is False

    # Evita misturar históricos de unidades distintas em uma mesma execução.
    mixed = dataframe.copy()
    mixed.loc[mixed.index[-1], "talhao"] = "Talhao_02"
    try:
        engine.processar(mixed, propriedade_id="P1_qualificacao")
    except ValueError as exc:
        assert "única unidade de manejo" in str(exc)
    else:
        raise AssertionError("O Hydros aceitou duas unidades na mesma execução.")

    # Persistência mínima da associação espacial e do tempo de processamento.
    with tempfile.TemporaryDirectory() as tmp:
        db = Database(str(Path(tmp) / "hydros.db"))
        execution_id = db.salvar_registro_execucao(trace)
        saved = db.buscar_execucao(execution_id)
        assert saved["property_id"] == "P1_qualificacao"
        assert saved["unit_id"] == "Talhao_01"
        assert float(saved["tempo_processamento_ms"]) >= 0.0

    print("CONTRATO DA TESE: OK")
    print("13 itens funcionais do protótipo verificados em fluxo integrado.")


if __name__ == "__main__":
    main()
