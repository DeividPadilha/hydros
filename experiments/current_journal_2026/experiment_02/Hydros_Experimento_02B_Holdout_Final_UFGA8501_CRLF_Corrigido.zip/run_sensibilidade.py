"""Módulo 6: análise de sensibilidade do Hydros.

A análise varia um fator por vez em torno da configuração-base e mantém
constantes os dados, evidências e o modelo APS. Não procura a configuração
com melhor resultado. O objetivo é medir estabilidade e identificar quais
pesos/limiares alteram materialmente o comportamento do Hydros Histórico.

Saídas em ``results/modulo_6_sensibilidade``.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping

import pandas as pd
from sklearn.metrics import accuracy_score, matthews_corrcoef, precision_recall_fscore_support

from src.agents.aiec_agent import AIECAgent
from src.agents.amdh_agent import AMDHAgent
from src.config.hydros_terms import PESOS_AIEC, PESOS_AMDH
from src.integrations.dssat_adapter import DSSATAdapter
from src.agents.aclim_agent import AclimAgent
from src.agents.ahid_agent import AhidAgent
from src.agents.afen_agent import AfenAgent
from src.agents.ageo_agent import AgeoAgent
from src.agents.aprod_agent import AprodAgent
from src.agents.ahist_agent import AhistAgent
from src.agents.arg_agent import ARGAgent
from src.agents.aps_agent import APSAgent
from src.core.evidence_quality import enrich_agent_evidence
from src.core.irrigation_state import infer_irrigation_state


ARQUIVO_CENARIOS = Path("data/hydros_soja_dssat_real_v2.csv")
PASTA_SAIDA = Path("results/modulo_6_sensibilidade")
PERTURBACAO_RELATIVA = 0.25

CLASSES_ACAO = [
    "finalizar_irrigacao",
    "reduzir_irrigacao",
    "manter_irrigacao",
    "iniciar_irrigacao",
    "aumentar_irrigacao",
]
ACOES_INTENSIFICACAO = {"iniciar_irrigacao", "aumentar_irrigacao"}


@dataclass(frozen=True)
class ConfiguracaoSensibilidade:
    id: str
    grupo: str
    descricao: str
    pesos_amdh: Mapping[str, float]
    pesos_aiec: Mapping[str, float]
    limiares_amdh: Mapping[str, float]


def _normalizar_pesos(pesos: Mapping[str, float]) -> Dict[str, float]:
    total = sum(max(float(v), 0.0) for v in pesos.values())
    if total <= 0:
        raise ValueError("Os pesos devem possuir soma positiva.")
    return {k: max(float(v), 0.0) / total for k, v in pesos.items()}


def _perturbar_peso(base: Mapping[str, float], chave: str, fator: float) -> Dict[str, float]:
    pesos = dict(base)
    pesos[chave] = float(pesos[chave]) * fator
    return _normalizar_pesos(pesos)


def gerar_configuracoes() -> list[ConfiguracaoSensibilidade]:
    base_amdh = _normalizar_pesos(PESOS_AMDH)
    base_aiec = _normalizar_pesos(PESOS_AIEC)
    limiares_base = {
        "confianca_critica": 0.35,
        "conflito_critico": 0.80,
        "completude_minima": 0.70,
    }

    configs = [
        ConfiguracaoSensibilidade(
            id="base",
            grupo="base",
            descricao="Configuração-base do Hydros",
            pesos_amdh=base_amdh,
            pesos_aiec=base_aiec,
            limiares_amdh=limiares_base,
        )
    ]

    for chave in base_amdh:
        for sinal, fator in (("menos25", 1.0 - PERTURBACAO_RELATIVA), ("mais25", 1.0 + PERTURBACAO_RELATIVA)):
            configs.append(
                ConfiguracaoSensibilidade(
                    id=f"amdh_{chave}_{sinal}",
                    grupo="pesos_amdh",
                    descricao=f"{chave} {sinal.replace('menos', '-').replace('mais', '+')}% relativo, demais renormalizados",
                    pesos_amdh=_perturbar_peso(base_amdh, chave, fator),
                    pesos_aiec=base_aiec,
                    limiares_amdh=limiares_base,
                )
            )

    for chave in base_aiec:
        for sinal, fator in (("menos25", 1.0 - PERTURBACAO_RELATIVA), ("mais25", 1.0 + PERTURBACAO_RELATIVA)):
            configs.append(
                ConfiguracaoSensibilidade(
                    id=f"aiec_{chave}_{sinal}",
                    grupo="pesos_aiec",
                    descricao=f"{chave} {sinal.replace('menos', '-').replace('mais', '+')}% relativo, demais renormalizados",
                    pesos_amdh=base_amdh,
                    pesos_aiec=_perturbar_peso(base_aiec, chave, fator),
                    limiares_amdh=limiares_base,
                )
            )

    limiar_variacoes = {
        "confianca_critica": (0.30, 0.40),
        "conflito_critico": (0.70, 0.90),
        "completude_minima": (0.60, 0.80),
    }
    for chave, (baixo, alto) in limiar_variacoes.items():
        for sufixo, valor in (("baixo", baixo), ("alto", alto)):
            limiares = dict(limiares_base)
            limiares[chave] = valor
            configs.append(
                ConfiguracaoSensibilidade(
                    id=f"limiar_{chave}_{sufixo}",
                    grupo="limiares_amdh",
                    descricao=f"{chave}={valor:.2f}",
                    pesos_amdh=base_amdh,
                    pesos_aiec=base_aiec,
                    limiares_amdh=limiares,
                )
            )

    return configs


def preparar_cache() -> list[dict[str, Any]]:
    """Executa os agentes uma vez por observação e preserva as evidências.

    A HydrosOnto e a persistência de rastreabilidade não são reexecutadas
    porque a sensibilidade altera somente pesos e limiares do AIEC/AMDH.
    Isso evita custo cumulativo sem mudar as evidências analisadas.
    """

    adapter = DSSATAdapter()
    dados = adapter.carregar_csv(ARQUIVO_CENARIOS)
    execucoes = adapter.separar_execucoes(dados)

    tamanho_janela = 5
    aclim = AclimAgent(tamanho_janela)
    ahid = AhidAgent(tamanho_janela)
    afen = AfenAgent(tamanho_janela)
    ageo = AgeoAgent()
    aprod = AprodAgent(tamanho_janela)
    ahist = AhistAgent(tamanho_janela)
    arg = ARGAgent(tamanho_janela)
    aps = APSAgent(algoritmo="random_forest", tamanho_janela=tamanho_janela)

    cache: list[dict[str, Any]] = []
    total = sum(len(g) for g in execucoes.values())
    n = 0

    print("Preparando cache das evidências para sensibilidade...")
    for cenario_id, grupo in execucoes.items():
        contexto = adapter.contexto_hydros(grupo)
        for indice in range(len(grupo)):
            historico = contexto.iloc[: indice + 1].copy()
            contexto_atual = historico.iloc[-1].to_dict()
            estado = infer_irrigation_state(contexto_atual)
            contexto_atual["irrigacao_ativa"] = estado.active
            contexto_atual["origem_estado_irrigacao"] = estado.source
            contexto_atual["confianca_estado_irrigacao"] = estado.confidence

            r_aclim = enrich_agent_evidence(aclim.analisar(historico), historico, "Aclim", "historico", history_window_size=tamanho_janela)
            r_ahid = enrich_agent_evidence(ahid.analisar(historico), historico, "Ahid", "historico", history_window_size=tamanho_janela)
            r_afen = enrich_agent_evidence(afen.analisar(historico), historico, "Afen", "historico", history_window_size=tamanho_janela)
            r_ageo = enrich_agent_evidence(ageo.analisar(historico), historico, "Ageo", "historico", history_window_size=1)
            r_aprod = enrich_agent_evidence(aprod.analisar(historico), historico, "Aprod", "historico", history_window_size=tamanho_janela)
            r_ahist = enrich_agent_evidence(ahist.analisar(historico), historico, "Ahist", "historico", history_window_size=tamanho_janela)

            r_arg = enrich_agent_evidence(
                arg.avaliar(historico),
                historico,
                "ARG",
                "historico",
                history_window_size=tamanho_janela,
            )
            r_arg["agente_modelo"] = "ARG"
            r_arg["evidencia_nome"] = "Earg"
            r_arg["Earg"] = r_arg.get("evidencia", r_arg.get("criticidade", "atencao"))
            r_arg["modo_execucao"] = "historico"

            r_aps = aps.classificar(historico)
            r_aps["agente_modelo"] = "APS"
            r_aps["evidencia_nome"] = "Eaps"
            r_aps["Eaps"] = r_aps.get("evidencia", r_aps.get("criticidade", "atencao"))
            r_aps["modo_execucao"] = "historico"

            linha = grupo.iloc[indice]
            cache.append({
                "cenario_id": cenario_id,
                "data": linha["data"],
                "acao_referencia": linha["decisao_dssat"],
                "contexto_atual": contexto_atual,
                "estado_irrigacao": estado.to_dict(),
                "verificacao_semantica": {},
                "aclim": r_aclim, "ahid": r_ahid, "afen": r_afen,
                "ageo": r_ageo, "aprod": r_aprod, "ahist": r_ahist,
                "arg": r_arg, "aps": r_aps,
            })
            n += 1
            if n % 50 == 0 or n == total:
                print(f"  {n}/{total}")
    return cache


def executar_configuracao(config: ConfiguracaoSensibilidade, cache: Iterable[Mapping[str, Any]]) -> pd.DataFrame:
    aiec = AIECAgent()
    aiec.pesos = dict(config.pesos_aiec)
    amdh = AMDHAgent()
    amdh.pesos = dict(config.pesos_amdh)
    amdh.limiares.update(dict(config.limiares_amdh))

    linhas = []
    for item in cache:
        r_aiec = aiec.integrar(
            item["aclim"], item["ahid"], item["afen"], item["ageo"], item["aprod"], item["ahist"]
        )
        r_amdh = amdh.decidir(
            item["arg"],
            r_aiec,
            item["aps"],
            item["contexto_atual"],
            estado_irrigacao=item["estado_irrigacao"],
            verificacao_semantica=item["verificacao_semantica"],
        )
        acao = r_amdh.get("D(Ui)")
        linhas.append(
            {
                "config_id": config.id,
                "grupo": config.grupo,
                "cenario_id": item["cenario_id"],
                "data": item["data"],
                "acao_referencia": item["acao_referencia"],
                "acao_hydros": acao,
                "saida_hydros": acao if acao is not None else "inconclusivo",
                "acao_candidata": r_amdh.get("acao_candidata"),
                "conclusivo": bool(r_amdh.get("processamento_conclusivo", acao is not None)),
                "confianca": float(r_amdh.get("confianca", 0.0)),
                "conflito": float(r_amdh.get("indice_conflito", 0.0)),
                "Ehc": r_aiec.get("Ehc"),
                "Earg": item["arg"].get("Earg"),
                "Eaps": item["aps"].get("Eaps"),
            }
        )
    return pd.DataFrame(linhas)


def calcular_resumo(config: ConfiguracaoSensibilidade, df: pd.DataFrame, base: pd.DataFrame | None) -> dict[str, Any]:
    y_true = df["acao_referencia"].astype(str)
    y_pred = df["saida_hydros"].astype(str)
    conclusivo = df["conclusivo"].astype(bool)

    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=CLASSES_ACAO, average="macro", zero_division=0
    )
    # A média de recall das cinco ações é a acurácia balanceada operacional
    # usada aqui, mantendo inconclusivos como erros da classe de referência.
    bal_acc = recall
    mcc = matthews_corrcoef(y_true, y_pred)

    ref_pos = y_true.isin(ACOES_INTENSIFICACAO)
    pred_pos = y_pred.isin(ACOES_INTENSIFICACAO)
    tp = int((ref_pos & pred_pos).sum())
    fp = int((~ref_pos & pred_pos).sum())
    fn = int((ref_pos & ~pred_pos).sum())
    prec_pos = tp / (tp + fp) if tp + fp else 0.0
    rec_pos = tp / (tp + fn) if tp + fn else 0.0

    if base is None:
        taxa_mesma = 1.0
        n_diferentes = 0
    else:
        merged = df[["cenario_id", "data", "saida_hydros"]].merge(
            base[["cenario_id", "data", "saida_hydros"]],
            on=["cenario_id", "data"], suffixes=("", "_base"), validate="one_to_one"
        )
        iguais = merged["saida_hydros"].eq(merged["saida_hydros_base"])
        taxa_mesma = float(iguais.mean())
        n_diferentes = int((~iguais).sum())

    row: dict[str, Any] = {
        "config_id": config.id,
        "grupo": config.grupo,
        "descricao": config.descricao,
        "n_observacoes": int(len(df)),
        "n_conclusivas": int(conclusivo.sum()),
        "taxa_conclusiva": round(float(conclusivo.mean()), 6),
        "acuracia_global": round(float(accuracy_score(y_true, y_pred)), 6),
        "acuracia_balanceada_operacional": round(float(bal_acc), 6),
        "precisao_macro": round(float(precision), 6),
        "recall_macro": round(float(recall), 6),
        "f1_macro": round(float(f1), 6),
        "mcc": round(float(mcc), 6),
        "eventos_intensificacao_referencia": int(ref_pos.sum()),
        "eventos_intensificacao_detectados": tp,
        "falsos_positivos_intensificacao": fp,
        "precisao_intensificacao": round(float(prec_pos), 6),
        "recall_intensificacao": round(float(rec_pos), 6),
        "confianca_media": round(float(df["confianca"].mean()), 6),
        "conflito_medio": round(float(df["conflito"].mean()), 6),
        "n_saidas_diferentes_da_base": n_diferentes,
        "estabilidade_em_relacao_base": round(taxa_mesma, 6),
    }
    for k, v in config.pesos_amdh.items():
        row[f"peso_amdh_{k}"] = round(float(v), 6)
    for k, v in config.pesos_aiec.items():
        row[f"peso_aiec_{k}"] = round(float(v), 6)
    for k, v in config.limiares_amdh.items():
        row[f"limiar_{k}"] = round(float(v), 6)
    return row


def main() -> None:
    PASTA_SAIDA.mkdir(parents=True, exist_ok=True)
    configs = gerar_configuracoes()
    cache = preparar_cache()

    detalhes = []
    resumos = []
    base_df: pd.DataFrame | None = None

    for i, config in enumerate(configs, start=1):
        print(f"Sensibilidade {i}/{len(configs)}: {config.id}")
        df = executar_configuracao(config, cache)
        if config.id == "base":
            base_df = df.copy()
        resumos.append(calcular_resumo(config, df, None if config.id == "base" else base_df))
        detalhes.append(df)

    resumo = pd.DataFrame(resumos)
    detalhe = pd.concat(detalhes, ignore_index=True)
    resumo.to_csv(PASTA_SAIDA / "resumo_sensibilidade.csv", index=False)
    detalhe.to_csv(PASTA_SAIDA / "detalhes_sensibilidade.csv", index=False)

    # Síntese por grupo, sem ranking por desempenho: estabilidade mínima,
    # mediana e máxima observadas nas perturbações daquele grupo.
    grupos = []
    for grupo, g in resumo[resumo["config_id"] != "base"].groupby("grupo", sort=False):
        grupos.append(
            {
                "grupo": grupo,
                "n_configuracoes": int(len(g)),
                "estabilidade_minima": round(float(g["estabilidade_em_relacao_base"].min()), 6),
                "estabilidade_mediana": round(float(g["estabilidade_em_relacao_base"].median()), 6),
                "estabilidade_maxima": round(float(g["estabilidade_em_relacao_base"].max()), 6),
                "taxa_conclusiva_min": round(float(g["taxa_conclusiva"].min()), 6),
                "taxa_conclusiva_max": round(float(g["taxa_conclusiva"].max()), 6),
                "recall_intensificacao_min": round(float(g["recall_intensificacao"].min()), 6),
                "recall_intensificacao_max": round(float(g["recall_intensificacao"].max()), 6),
            }
        )
    pd.DataFrame(grupos).to_csv(PASTA_SAIDA / "sintese_por_grupo.csv", index=False)

    print("\nConfiguração-base:")
    print(resumo[resumo["config_id"] == "base"].to_string(index=False))
    print("\nEstabilidade por grupo:")
    print(pd.DataFrame(grupos).to_string(index=False))
    print(f"\nSaídas: {PASTA_SAIDA.resolve()}")
    print("MODULO 6: OK")


if __name__ == "__main__":
    main()
