from pathlib import Path
from tempfile import TemporaryDirectory

import pandas as pd

from src.database.database import Database
from src.services.hydros_engine import HydrosEngine
from src.services.interface_adapter import (
    build_comparison_rows,
    build_execution_view,
    persist_execution,
)


def main() -> None:
    dataframe = pd.read_csv("data/historico_contexto_exemplo.csv")
    engine = HydrosEngine(algoritmo_aps="random_forest")

    historical = engine.executar(dataframe.copy(), modo_execucao="historico")
    without_history = engine.executar(
        dataframe.copy(), modo_execucao="sem_historico"
    )

    historical_view = build_execution_view(historical)
    without_history_view = build_execution_view(without_history)

    assert historical_view["mode"] == "historico"
    assert without_history_view["mode"] == "sem_historico"
    assert historical_view["used_contexts"] == len(dataframe)
    assert without_history_view["used_contexts"] == 1
    assert historical_view["evidence_count"] == 9
    assert without_history_view["evidence_count"] == 9
    assert historical_view["physical_actuation"] is False
    assert historical_view["ontology_integrated"] == (
        "semantic_verification_and_traceability"
    )
    assert historical_view["execution_id"]
    assert without_history_view["execution_id"]

    comparison = build_comparison_rows([historical, without_history])
    assert len(comparison) == 2
    assert {row["Modo"] for row in comparison} == {
        "Hydros Histórico",
        "Hydros sem Histórico",
    }

    with TemporaryDirectory() as temp_dir:
        database = Database(str(Path(temp_dir) / "hydros_interface_test.db"))
        historical_id = persist_execution(database, historical)
        without_history_id = persist_execution(database, without_history)

        assert historical_id == historical_view["execution_id"]
        assert without_history_id == without_history_view["execution_id"]
        assert database.quantidade_execucoes() == 2

        loaded = database.buscar_execucao(historical_id)
        assert loaded is not None
        assert loaded["status_processamento"] == historical_view[
            "processing_status"
        ]
        assert loaded["revisao_humana"] == 0

    print("\n=== INTERFACE HYDROS ===")
    print(f"Modo histórico: {historical_view['action']}")
    print(f"Modo sem histórico: {without_history_view['action']}")
    print(f"Contextos históricos utilizados: {historical_view['used_contexts']}")
    print(
        "Contextos sem histórico utilizados:",
        without_history_view["used_contexts"],
    )
    print(f"Evidências por execução: {historical_view['evidence_count']}")
    print("Persistência integral: OK")
    print("Acionamento físico: desativado")
    print("INTERFACE HYDROS: OK")


if __name__ == "__main__":
    main()
