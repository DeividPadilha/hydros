# Status do Hydros em 13/08/2026

## Estado geral

Versão: `0.4.1-qualificacao-final`.

O protótipo está funcional e alinhado ao modelo descrito na versão atual da tese. As entregas anteriores e os resultados de cada módulo foram preservados para rollback e auditoria.

## Implementado

- históricos de contextos por unidade de manejo;
- modos `historico` e `sem_historico`;
- dez agentes: Aclim, Ahid, Afen, Ageo, Aprod, Ahist, AIEC, ARG, APS e AMDH;
- escala `adequada`, `atencao`, `critica`;
- cinco ações de manejo hídrico;
- processamento inconclusivo quando necessário;
- remoção do fluxo operacional de aceitar, modificar ou rejeitar a ação;
- HydrosOnto oficial em OWL;
- verificação semântica e rastreabilidade sem influência no score;
- janela histórica configurável;
- APS em três classes com governança de prontidão científica;
- persistência e interface Streamlit;
- DSSAT isolado como recurso de avaliação;
- Experimento I Histórico versus sem Histórico;
- análise de sensibilidade;
- Experimento II com política operacional explícita;
- validação integral e congelamento de release.

## Experimento I

Base atual: 256 observações pareadas e duas execuções DSSAT.

| Indicador | Histórico | sem Histórico |
|---|---:|---:|
| Conclusivos | 254 | 255 |
| Taxa conclusiva | 0,9922 | 0,9961 |
| Acurácia global | 0,9492 | 0,9531 |
| Acurácia entre conclusivas | 0,9567 | 0,9569 |
| F1 macro | 0,1948 | 0,1952 |

Ocorreu 1 saída diferente entre os modos. Nenhum modo detectou os 11 eventos de `iniciar_irrigacao` da referência atual.

## Tempo térmico

O campo canônico `gd` da tese é implementado como `soma_termica_acumulada`. O valor diário/periódico permanece em `graus_dia_periodo`. Arquivos antigos com `graus_dia` são normalizados automaticamente e preservam esse campo apenas como alias legado. O APS foi retreinado com o contrato térmico corrigido e continua classificado como provisório.

## APS

O APS ativo utiliza as três classes canônicas, mas permanece `provisorio` para uso científico. A base de janelas possui 417 exemplos `atencao`, 78 `adequada` e apenas 1 `critica`. Validação e teste não contêm a classe crítica e a base deriva de uma única trajetória.

## Sensibilidade

Foram avaliadas 25 configurações. Após a correção do contrato de confiança, a configuração-base da sensibilidade passou a reproduzir exatamente o Hydros Histórico do Experimento I. Perturbações dos pesos do AMDH mantiveram estabilidade mínima de 0,992188; as perturbações dos pesos do AIEC mantiveram as mesmas ações da base. Nenhuma variação recuperou os eventos de intensificação.

## Experimento II

No único par DSSAT compatível atual:

- Hydros Histórico: 0 mm de irrigação, 3061 kg/ha, 17 períodos de estresse;
- referência: 85 mm, 3114 kg/ha, 2 períodos de estresse.

O resultado é não favorável ao Hydros nessa trajetória. Houve redução de 85 mm de irrigação, mas produtividade 53 kg/ha menor e aumento de estresse. Nenhum parâmetro foi ajustado depois da observação do resultado.

## Limitações abertas

1. ampliar a base do APS com trajetórias independentes e representação das três classes;
2. ampliar o Experimento I para mais cenários e referências menos desbalanceadas;
3. ampliar o Experimento II para múltiplas trajetórias e política agronômica documentada;
4. incluir variável adequada para excesso/drenagem quando disponível;
5. avaliar posteriormente com dados agrícolas reais.

## Classificação do software

O Hydros é um **protótipo funcional, rastreável e reproduzível em avaliação experimental**. Não constitui sistema agronomicamente validado para uso operacional em propriedades rurais.
