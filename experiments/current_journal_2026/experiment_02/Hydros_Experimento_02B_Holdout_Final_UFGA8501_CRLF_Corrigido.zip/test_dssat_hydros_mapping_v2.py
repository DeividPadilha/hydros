from pathlib import Path

import pandas as pd

from src.evaluation.dssat_hydros_mapping import (
    IBSB910015,
    build_hydros_context_from_dssat_outputs,
)


ROOT = Path(__file__).resolve().parent
PROBE = ROOT / "results" / "experimento_2b" / "dssat_probe"


def _dir(treatment: str) -> Path:
    matches = sorted(PROBE.glob(f"ufga7901_UFGA7901_{treatment}_*"))
    assert matches
    return matches[-1]


def test_bridge_v2_preserva_128_dias_e_sem_vazamento_de_produtividade():
    df = build_hydros_context_from_dssat_outputs(_dir("T1"), scenario_id="UFGA7901_T1")
    assert len(df) == 128
    assert df["dia_safra"].tolist() == list(range(1, 129))
    assert float(df["produtividade"].iloc[0]) == 0.0
    assert float(df["produtividade"].iloc[-1]) == 3114.0
    # O valor terminal não pode ser retropropagado para o início da série.
    assert (df["produtividade"].iloc[:70] == 3114.0).sum() == 0


def test_bridge_v2_agua_radicular_tem_limites_fisicos():
    df = build_hydros_context_from_dssat_outputs(_dir("T2"), scenario_id="UFGA7901_T2")
    assert df["bridge_fracao_agua_extraivel_zona_radicular"].between(0.0, 1.0).all()
    assert df["umidade_solo"].between(0.0, 100.0).all()
    pawc = float(IBSB910015.hydraulic_summary()["PAWC_LL_to_DUL_mm"])
    assert df["agua_disponivel"].between(0.0, pawc + 1e-9).all()
    assert (df["bridge_agua_extraivel_zona_radicular_mm"] <= df["bridge_taw_zona_radicular_mm"] + 1e-9).all()


def test_bridge_v2_clima_igual_e_irrigacao_diferente_t1_t2():
    t1 = build_hydros_context_from_dssat_outputs(_dir("T1"), scenario_id="UFGA7901_T1")
    t2 = build_hydros_context_from_dssat_outputs(_dir("T2"), scenario_id="UFGA7901_T2")
    for col in ["data", "precipitacao", "temperatura", "temp_maxima", "temp_minima"]:
        pd.testing.assert_series_equal(t1[col], t2[col], check_names=False)
    assert abs(float(t1["irrigacao_aplicada"].sum()) - 85.0) < 1e-9
    assert abs(float(t2["irrigacao_aplicada"].sum())) < 1e-9


def test_bridge_v2_estagio_usa_estado_diario_dssat():
    df = build_hydros_context_from_dssat_outputs(_dir("T1"), scenario_id="UFGA7901_T1")
    allowed = {"V3", "V4", "V5", "R1", "R2", "R3", "R4", "R5"}
    assert set(df["estagio_fenologico"]).issubset(allowed)
    # GSTD=1 observado no próprio dia é R1; não depende de datas futuras.
    rows = df[df["dssat_GSTD"] == 1]
    assert not rows.empty
    assert set(rows["estagio_fenologico"]) == {"R1"}
