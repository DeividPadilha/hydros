# Hydros 0.4.1-audit-checkpointB

## Objetivo

Separar conceitualmente e operacionalmente **criticidade** de **confiança** sem alterar pesos, regras agronômicas, modelo APS ou HydrosOnto.

## Alterações

1. `confianca` dos agentes especializados e do ARG passa a representar a sustentação da evidência pelos dados disponíveis.
2. O valor legado derivado da severidade é preservado em `confianca_criticidade_legada` apenas para auditoria.
3. O AIEC usa explicitamente `confianca_dados` e `qualidade_dados` na integração.
4. O ARG passou a receber a mesma avaliação de completude/qualidade aplicada às evidências especializadas.
5. A rastreabilidade registra a confiança legada e o método de confiança atual.
6. O Random Forest do APS usa `n_jobs=1` somente na inferência registro a registro. Isso evita overhead/timeout sem alterar árvores, probabilidades ou previsões do modelo.
7. O teste funcional do cenário de condição adequada foi corrigido: com dados completos, baixa criticidade não implica baixa confiança. O mecanismo de inconclusão continua coberto pelos testes de governança.

## Validação

- Compilação Python: OK.
- Testes: **23/23 OK**.
- Cenários funcionais: **4/4 OK**.
- Modelos APS e `ontology/hydrosonto.owl`: preservados, sem alteração de artefato.
- Experimento I: regenerado após a migração de confiança.
- Diagnóstico e artefatos do Experimento I: regenerados.

## Efeito observado no Experimento I

A correção alterou principalmente o status de processamento, porque condições adequadas deixaram de receber confiança baixa apenas por apresentarem baixa criticidade.

### Antes, Checkpoint A

- Histórico: 167/256 conclusivos, taxa 0,6523, acurácia 0,6172, F1 macro 0,1534, confiança média 0,3740.
- Sem Histórico: 36/256 conclusivos, taxa 0,1406, acurácia 0,1250, F1 macro 0,0456, confiança média 0,3350.

### Depois, Checkpoint B

- Histórico: 254/256 conclusivos, taxa 0,9922, acurácia 0,9492, F1 macro 0,1948, confiança média 0,6816.
- Sem Histórico: 255/256 conclusivos, taxa 0,9961, acurácia 0,9531, F1 macro 0,1952, confiança média 0,5844.
- Apenas 1 saída divergiu entre Histórico e sem Histórico.
- Os 11 eventos de referência `iniciar_irrigacao` continuam sem detecção por ambos os modos.

## Interpretação

O resultado anterior que mostrava grande vantagem do modo Histórico na taxa de conclusão era fortemente influenciado pela fórmula legada de confiança, que misturava severidade com confiabilidade. Após a separação correta, essa vantagem praticamente desaparece no conjunto DSSAT atual.

Isso não é tratado como erro a ser "corrigido" por ajuste de pesos. É um resultado científico importante: **o conjunto experimental atual ainda não demonstra contribuição clara do histórico para a ação final**, embora o histórico continue implementado como memória temporal e altere evidências internas.

## Resultados que não foram regenerados neste checkpoint

A análise de sensibilidade e o Experimento II permanecem preservados como resultados do checkpoint anterior. Eles não devem ser interpretados como resultados do Checkpoint B. Serão regenerados após o próximo checkpoint, que corrige a variável térmica e exige retreinamento do APS.
