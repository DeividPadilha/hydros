"""Testes da configuração central da janela histórica do Hydros."""

import pandas as pd
import pytest

from src.config.hydros_terms import TAMANHO_JANELA_HISTORICA_PADRAO
from src.services.hydros_engine import HydrosEngine


def carregar_historico():
    return pd.read_csv("data/historico_contexto_exemplo.csv")


def test_janela_padrao_preserva_configuracao_legada():
    engine = HydrosEngine()

    assert engine.tamanho_janela_historica == TAMANHO_JANELA_HISTORICA_PADRAO == 5
    assert engine.aclim.tamanho_janela == 5
    assert engine.ahid.tamanho_janela == 5
    assert engine.afen.tamanho_janela == 5
    assert engine.aprod.tamanho_janela == 5
    assert engine.ahist.tamanho_janela == 5
    assert engine.arg.tamanho_janela == 5
    assert engine.aps.extrator.tamanho_janela == 5


def test_janela_configuravel_e_propagada_para_componentes_temporais():
    engine = HydrosEngine(tamanho_janela_historica=3)

    assert engine.tamanho_janela_historica == 3
    assert engine.aclim.tamanho_janela == 3
    assert engine.ahid.tamanho_janela == 3
    assert engine.afen.tamanho_janela == 3
    assert engine.aprod.tamanho_janela == 3
    assert engine.ahist.tamanho_janela == 3
    assert engine.arg.tamanho_janela == 3
    assert engine.aps.extrator.tamanho_janela == 3


def test_agente_climatico_usa_a_janela_configurada():
    df = carregar_historico()
    engine = HydrosEngine(tamanho_janela_historica=3)
    resultado = engine.executar(df, modo_execucao="historico")

    esperado = round(float(df.tail(3)["precipitacao"].sum()), 2)
    observado = resultado["aclim"]["indicadores"]["precipitacao_acumulada"]

    assert observado == esperado
    assert resultado["tamanho_janela_historica"] == 3
    assert resultado["aclim"]["tamanho_janela_historica"] == 3


def test_sem_historico_continua_usando_apenas_contexto_atual():
    df = carregar_historico()
    engine = HydrosEngine(tamanho_janela_historica=3)
    resultado = engine.executar(df, modo_execucao="sem_historico")

    assert resultado["quantidade_contextos_utilizados"] == 1
    assert resultado["ahist"]["evidencia_ativa"] is False
    assert resultado["tamanho_janela_historica"] == 3


def test_aps_sinaliza_janela_diferente_da_usada_no_treinamento():
    df = carregar_historico()
    engine = HydrosEngine(tamanho_janela_historica=3)
    resultado = engine.executar(df, modo_execucao="historico")
    aps = resultado["aps"]

    assert aps["tamanho_janela_historica"] == 3
    assert aps["tamanho_janela_treinamento"] == 5
    assert aps["janela_compativel_modelo"] is False
    assert aps["uso_cientifico_restrito"] is True
    assert aps["status_dominio"] == "fora_dominio"
    assert aps["compatibilidade_dominio"] == 0.0
    assert aps["confianca"] == 0.0
    assert any("janela histórica" in aviso.lower() for aviso in aps["avisos"])


def test_janela_invalida_e_rejeitada():
    with pytest.raises(ValueError):
        HydrosEngine(tamanho_janela_historica=0)
