"""Compara Hydros Histórico e Hydros sem Histórico."""

import pandas as pd

from src.services.hydros_engine import HydrosEngine


def resumir(nome, resultado):
    amdh = resultado["amdh"]
    print(f"\n=== {nome.upper()} ===")
    print("Contextos utilizados:", resultado["quantidade_contextos_utilizados"])
    print("Ehist:", resultado["ahist"]["Ehist"])
    print("Ehc:", resultado["aiec"]["Ehc"])
    print("Earg:", resultado["arg"]["Earg"])
    print("Eaps:", resultado["aps"]["Eaps"])
    print("D(Ui,t):", amdh["D(Ui)"])
    print("Status:", amdh["status_processamento"])
    print("Score:", amdh["score_hibrido"])
    print("Confiança:", amdh["confianca"])
    print("Conflito:", amdh["indice_conflito"])


def main():
    df = pd.read_csv("data/historico_contexto_exemplo.csv")
    engine = HydrosEngine()

    historico = engine.executar(df, modo_execucao="historico")
    sem_historico = engine.executar(df, modo_execucao="sem_historico")

    resumir("Hydros Histórico", historico)
    resumir("Hydros sem Histórico", sem_historico)

    print("\n=== COMPARAÇÃO ===")
    print("Mesma ação:", historico["amdh"]["D(Ui)"] == sem_historico["amdh"]["D(Ui)"])
    print(
        "Diferença de confiança:",
        round(historico["amdh"]["confianca"] - sem_historico["amdh"]["confianca"], 4),
    )


if __name__ == "__main__":
    main()
