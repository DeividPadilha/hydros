# HYDROS EXP02B: congelamento antes do holdout UFGA8501

Data: 2026-08-14

## Resultado dos cenários de desenvolvimento

### UFGA7801

Referência DSSAT:
- irrigação efetiva: 147 mm
- irrigação bruta: 206 mm
- produtividade: 2806 kg/ha
- dias de estresse >= 0,25: 20
- soma de estresse: 11,392
- drenagem: 286 mm

Hydros em ciclo fechado:
- irrigação efetiva: 158 mm
- irrigação bruta: 210 mm
- produtividade: 3272 kg/ha
- dias de estresse >= 0,25: 7
- soma de estresse: 3,710
- drenagem: 275 mm

Interpretação: o Hydros usou 4 mm brutos a mais, mas elevou a produtividade em 466 kg/ha, reduziu fortemente o estresse e reduziu a drenagem. A produtividade por mm de irrigação bruta passou de aproximadamente 13,62 para 15,58 kg/ha/mm, aumento de aproximadamente 14,4%.

### UFGA8401

Referência DSSAT:
- irrigação efetiva: 341 mm
- produtividade: 3381 kg/ha
- dias de estresse >= 0,25: 0
- soma de estresse: 0,308
- drenagem: 244 mm

Hydros em ciclo fechado:
- irrigação efetiva: 171 mm
- produtividade: 3250 kg/ha
- dias de estresse >= 0,25: 6
- soma de estresse: 3,094
- drenagem: 149 mm

Interpretação: o Hydros reduziu a irrigação em 170 mm, aproximadamente 49,85%, mantendo 96,13% da produtividade. A produtividade por mm de irrigação passou de aproximadamente 9,91 para 19,01 kg/ha/mm.

## Decisão de congelamento

Os dois cenários de desenvolvimento apresentam comportamentos úteis e distintos. UFGA7801 mostra ganho de produtividade e redução de estresse com pequeno aumento de água. UFGA8401 mostra forte economia de água com pequena perda de produtividade. Como o objetivo desta etapa era desenvolver e validar o ciclo fechado sem consultar o holdout, a versão é congelada neste ponto.

Não será realizada nova calibração antes do UFGA8501.

## Holdout final

O UFGA8501 permanece como holdout. O protocolo v2 estabelece:
- mesmo tratamento-base 2 nos dois ramos;
- referência com programação oficial MI=1 aplicada ao nível MI=2;
- Hydros com prefixo fixo 85172/13 mm e 85175/10 mm;
- depois do prefixo, ciclo fechado C(t) -> Hydros -> manejo(t+1) -> nova execução DSSAT;
- nenhuma calibração após observar o resultado do holdout.

O script `run_holdout_final_exp02b.py` implementa esse contrato.

## Verificação do pacote

A suíte automatizada foi executada antes da geração do pacote final de holdout:

`51 passed`

O pacote não altera pesos AMDH, limiares dos agentes, APS, ontologia ou regras após os resultados de desenvolvimento informados acima.
