"""Experimento I do Hydros: contribuição do histórico de contextos.

Compara, sobre as mesmas observações e com todos os demais componentes
mantidos, duas configurações do Hydros:

- Hydros Histórico: utiliza C(t) e H(Ui);
- Hydros sem Histórico: utiliza somente C(t).

Os cenários agrícolas são provenientes do conjunto DSSAT já preparado para a
avaliação. A ação de referência é usada como referência operacional comum aos
dois modos e não como verdade agronômica absoluta.

Saídas em ``results/experimento_1``:
- comparacao_detalhada.csv
- metricas_resumo.csv
- metricas_por_cenario.csv
- comparacao_pareada.csv
- resumo_pareado.csv
- matriz_confusao_historico.csv
- matriz_confusao_sem_historico.csv
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    cohen_kappa_score,
    confusion_matrix,
    precision_recall_fscore_support,
)

from src.integrations.dssat_adapter import DSSATAdapter
from src.services.hydros_engine import HydrosEngine


ARQUIVO_CENARIOS = Path("data/hydros_soja_dssat_real_v2.csv")
PASTA_SAIDA = Path("results/experimento_1")

CLASSES_ACAO = [
    "finalizar_irrigacao",
    "reduzir_irrigacao",
    "manter_irrigacao",
    "iniciar_irrigacao",
    "aumentar_irrigacao",
]

MODOS = ("historico", "sem_historico")


def _serie_analise(serie: pd.Series) -> pd.Series:
    """Normaliza ausência de ação como saída inconclusiva para análise."""

    return serie.fillna("inconclusivo").astype(str)


def calcular_metricas(
    referencia: pd.Series,
    previsao: pd.Series,
    conclusivo: pd.Series,
    modo: str,
) -> Dict[str, float | str | int]:
    """Calcula métricas do modo sem ocultar processamentos inconclusivos."""

    y_true = referencia.astype(str)
    y_pred = _serie_analise(previsao)
    conclusivo = conclusivo.astype(bool)

    precisao, recall, f1, _ = precision_recall_fscore_support(
        y_true,
        y_pred,
        labels=CLASSES_ACAO,
        average="macro",
        zero_division=0,
    )

    if conclusivo.any():
        concordancia_condicional = accuracy_score(
            y_true[conclusivo], y_pred[conclusivo]
        )
    else:
        concordancia_condicional = 0.0

    return {
        "modo": modo,
        "n_observacoes": int(len(y_true)),
        "n_conclusivas": int(conclusivo.sum()),
        "taxa_conclusiva": round(float(conclusivo.mean()), 4),
        "acuracia": round(float(accuracy_score(y_true, y_pred)), 4),
        "acuracia_condicional_conclusivas": round(
            float(concordancia_condicional), 4
        ),
        "precisao_macro": round(float(precisao), 4),
        "recall_macro": round(float(recall), 4),
        "f1_macro": round(float(f1), 4),
        "kappa_cohen": round(float(cohen_kappa_score(y_true, y_pred)), 4),
    }


def salvar_matriz_confusao(
    referencia: pd.Series,
    previsao: pd.Series,
    nome_arquivo: str,
) -> None:
    """Salva matriz de confusão incluindo a saída inconclusiva."""

    labels_predicao = CLASSES_ACAO + ["inconclusivo"]
    y_true = referencia.astype(str)
    y_pred = _serie_analise(previsao)

    # Matriz retangular explícita: linhas são as cinco ações de referência e
    # colunas são as cinco ações do Hydros mais a possibilidade inconclusiva.
    matriz = []
    for classe_ref in CLASSES_ACAO:
        mascara = y_true.eq(classe_ref)
        matriz.append(
            [int((y_pred[mascara] == classe_pred).sum()) for classe_pred in labels_predicao]
        )

    df_matriz = pd.DataFrame(
        matriz,
        index=[f"referencia_{classe}" for classe in CLASSES_ACAO],
        columns=[f"hydros_{classe}" for classe in labels_predicao],
    )
    df_matriz.to_csv(PASTA_SAIDA / nome_arquivo, index=True)


def executar_experimento() -> pd.DataFrame:
    """Executa os dois modos sobre exatamente a mesma sequência de contextos."""

    adapter = DSSATAdapter()
    dados = adapter.carregar_csv(ARQUIVO_CENARIOS)
    execucoes = adapter.separar_execucoes(dados)

    engine_historico = HydrosEngine(modo_execucao="historico")
    engine_sem_historico = HydrosEngine(modo_execucao="sem_historico")

    registros: List[Dict[str, object]] = []
    total = sum(len(grupo) for grupo in execucoes.values())
    processados = 0

    print("\n=== EXPERIMENTO I: HISTÓRICO x SEM HISTÓRICO ===")
    print(f"Arquivo de cenários: {ARQUIVO_CENARIOS}")
    print(f"Execuções DSSAT: {len(execucoes)}")
    print(f"Observações pareadas: {total}")

    for cenario_id, grupo in execucoes.items():
        contexto_completo = adapter.contexto_hydros(grupo)
        print(f"\nProcessando {cenario_id}: {len(grupo)} observações")

        for indice in range(len(grupo)):
            historico_ate_data = contexto_completo.iloc[: indice + 1].copy()
            linha = grupo.iloc[indice]

            try:
                resultado_h = engine_historico.executar(
                    historico_ate_data, modo_execucao="historico"
                )
                resultado_s = engine_sem_historico.executar(
                    historico_ate_data, modo_execucao="sem_historico"
                )
            except Exception as erro:
                raise RuntimeError(
                    "Falha no Experimento I em "
                    f"cenario_id={cenario_id}, data={linha['data']}, indice={indice}. "
                    f"Erro original: {erro}"
                ) from erro

            amdh_h = resultado_h["amdh"]
            amdh_s = resultado_s["amdh"]
            acao_ref = linha["decisao_dssat"]
            acao_h = amdh_h.get("D(Ui)")
            acao_s = amdh_s.get("D(Ui)")
            conclusivo_h = bool(amdh_h.get("processamento_conclusivo", acao_h is not None))
            conclusivo_s = bool(amdh_s.get("processamento_conclusivo", acao_s is not None))

            saida_h = acao_h if acao_h is not None else "inconclusivo"
            saida_s = acao_s if acao_s is not None else "inconclusivo"
            correto_h = bool(conclusivo_h and acao_h == acao_ref)
            correto_s = bool(conclusivo_s and acao_s == acao_ref)

            registros.append(
                {
                    "cenario_id": cenario_id,
                    "cenario": linha.get("cenario", ""),
                    "dssat_run": linha.get("dssat_run", ""),
                    "data": linha["data"],
                    "dia_safra": linha.get("dia_safra", indice + 1),
                    "acao_referencia": acao_ref,
                    "acao_hydros_historico": acao_h,
                    "acao_hydros_sem_historico": acao_s,
                    "saida_hydros_historico": saida_h,
                    "saida_hydros_sem_historico": saida_s,
                    "acao_candidata_historico": amdh_h.get("acao_candidata"),
                    "acao_candidata_sem_historico": amdh_s.get("acao_candidata"),
                    "processamento_conclusivo_historico": conclusivo_h,
                    "processamento_conclusivo_sem_historico": conclusivo_s,
                    "status_processamento_historico": amdh_h.get("status_processamento", ""),
                    "status_processamento_sem_historico": amdh_s.get("status_processamento", ""),
                    "motivos_inconclusao_historico": " | ".join(amdh_h.get("motivos_inconclusao", [])),
                    "motivos_inconclusao_sem_historico": " | ".join(amdh_s.get("motivos_inconclusao", [])),
                    "concordancia_referencia_historico": correto_h,
                    "concordancia_referencia_sem_historico": correto_s,
                    "mesma_saida_hydros": saida_h == saida_s,
                    "confianca_historico": amdh_h.get("confianca", 0.0),
                    "confianca_sem_historico": amdh_s.get("confianca", 0.0),
                    "conflito_historico": amdh_h.get("indice_conflito", 0.0),
                    "conflito_sem_historico": amdh_s.get("indice_conflito", 0.0),
                    "avisos_governanca_historico": " | ".join(amdh_h.get("avisos_governanca", [])),
                    "avisos_governanca_sem_historico": " | ".join(amdh_s.get("avisos_governanca", [])),
                    "status_aps_historico": resultado_h["aps"].get("status_dominio", "nao_informado"),
                    "status_aps_sem_historico": resultado_s["aps"].get("status_dominio", "nao_informado"),
                    "compatibilidade_aps_historico": resultado_h["aps"].get("compatibilidade_dominio", 0.0),
                    "compatibilidade_aps_sem_historico": resultado_s["aps"].get("compatibilidade_dominio", 0.0),
                    "peso_efetivo_aps_historico": amdh_h.get("dependencia_aps", {}).get("peso_efetivo_aps", 0.0),
                    "peso_efetivo_aps_sem_historico": amdh_s.get("dependencia_aps", {}).get("peso_efetivo_aps", 0.0),
                    "acao_sem_aps_historico": amdh_h.get("dependencia_aps", {}).get("decisao_sem_aps", ""),
                    "acao_sem_aps_sem_historico": amdh_s.get("dependencia_aps", {}).get("decisao_sem_aps", ""),
                    "dependencia_material_aps_historico": bool(amdh_h.get("dependencia_aps", {}).get("influencia_material", False)),
                    "dependencia_material_aps_sem_historico": bool(amdh_s.get("dependencia_aps", {}).get("influencia_material", False)),
                    "score_historico": amdh_h.get("score_hibrido", 0.0),
                    "score_sem_historico": amdh_s.get("score_hibrido", 0.0),
                    "contextos_utilizados_historico": resultado_h.get("quantidade_contextos_utilizados", amdh_h.get("contextos_utilizados", 0)),
                    "contextos_utilizados_sem_historico": resultado_s.get("quantidade_contextos_utilizados", amdh_s.get("contextos_utilizados", 0)),
                    "condicao_semantica_historico": amdh_h.get("verificacao_semantica", {}).get("semantic_condition", ""),
                    "condicao_semantica_sem_historico": amdh_s.get("verificacao_semantica", {}).get("semantic_condition", ""),
                    "umidade_solo_pct": linha["umidade_solo"],
                    "agua_disponivel_mm": linha["agua_disponivel"],
                    "irrigacao_referencia_mm": linha["irrigacao_aplicada"],
                    "estresse_dssat_original": linha.get("estresse_hidrico_dssat_original", linha.get("estresse_hidrico", "")),
                    "estresse_hydros": linha["estresse_hidrico"],
                    "produtividade_kg_ha": linha["produtividade"],
                    "ehc_historico": resultado_h["aiec"]["Ehc"],
                    "earg_historico": resultado_h["arg"]["Earg"],
                    "eaps_historico": resultado_h["aps"]["Eaps"],
                    "ehc_sem_historico": resultado_s["aiec"]["Ehc"],
                    "earg_sem_historico": resultado_s["arg"]["Earg"],
                    "eaps_sem_historico": resultado_s["aps"]["Eaps"],
                }
            )

            processados += 1
            if processados % 25 == 0 or processados == total:
                print(f"  Progresso: {processados}/{total}")

    return pd.DataFrame(registros)


def gerar_comparacao_pareada(resultados: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Gera comparação descritiva pareada entre os dois modos."""

    pares = resultados[
        [
            "cenario_id",
            "data",
            "dia_safra",
            "acao_referencia",
            "saida_hydros_historico",
            "saida_hydros_sem_historico",
            "processamento_conclusivo_historico",
            "processamento_conclusivo_sem_historico",
            "concordancia_referencia_historico",
            "concordancia_referencia_sem_historico",
            "confianca_historico",
            "confianca_sem_historico",
            "conflito_historico",
            "conflito_sem_historico",
        ]
    ].copy()

    pares["diferenca_saida"] = (
        pares["saida_hydros_historico"] != pares["saida_hydros_sem_historico"]
    )
    pares["diferenca_confianca_hist_menos_sem"] = (
        pares["confianca_historico"] - pares["confianca_sem_historico"]
    ).round(6)
    pares["diferenca_conflito_hist_menos_sem"] = (
        pares["conflito_historico"] - pares["conflito_sem_historico"]
    ).round(6)

    h_ok = pares["concordancia_referencia_historico"].astype(bool)
    s_ok = pares["concordancia_referencia_sem_historico"].astype(bool)
    pares["resultado_pareado"] = "ambos_nao_concordam"
    pares.loc[h_ok & s_ok, "resultado_pareado"] = "ambos_concordam"
    pares.loc[h_ok & ~s_ok, "resultado_pareado"] = "vantagem_historico"
    pares.loc[~h_ok & s_ok, "resultado_pareado"] = "vantagem_sem_historico"

    resumo = pd.DataFrame(
        [
            {
                "n_observacoes_pareadas": int(len(pares)),
                "n_saidas_diferentes": int(pares["diferenca_saida"].sum()),
                "taxa_saidas_diferentes": round(float(pares["diferenca_saida"].mean()), 4),
                "n_vantagem_historico": int((pares["resultado_pareado"] == "vantagem_historico").sum()),
                "n_vantagem_sem_historico": int((pares["resultado_pareado"] == "vantagem_sem_historico").sum()),
                "n_ambos_concordam": int((pares["resultado_pareado"] == "ambos_concordam").sum()),
                "n_ambos_nao_concordam": int((pares["resultado_pareado"] == "ambos_nao_concordam").sum()),
                "taxa_conclusiva_historico": round(float(pares["processamento_conclusivo_historico"].mean()), 4),
                "taxa_conclusiva_sem_historico": round(float(pares["processamento_conclusivo_sem_historico"].mean()), 4),
                "diferenca_media_confianca_hist_menos_sem": round(float(pares["diferenca_confianca_hist_menos_sem"].mean()), 4),
                "diferenca_media_conflito_hist_menos_sem": round(float(pares["diferenca_conflito_hist_menos_sem"].mean()), 4),
            }
        ]
    )
    return pares, resumo


def gerar_metricas_por_cenario(resultados: pd.DataFrame) -> pd.DataFrame:
    linhas: list[dict[str, object]] = []
    for cenario_id, grupo in resultados.groupby("cenario_id", sort=False):
        for modo in MODOS:
            metricas = calcular_metricas(
                grupo["acao_referencia"],
                grupo[f"acao_hydros_{modo}"],
                grupo[f"processamento_conclusivo_{modo}"],
                modo,
            )
            metricas["cenario_id"] = cenario_id
            linhas.append(metricas)
    colunas = ["cenario_id", "modo"] + [
        c for c in linhas[0].keys() if c not in {"cenario_id", "modo"}
    ] if linhas else []
    return pd.DataFrame(linhas)[colunas] if linhas else pd.DataFrame()


def main() -> None:
    PASTA_SAIDA.mkdir(parents=True, exist_ok=True)

    resultados = executar_experimento()
    resultados.to_csv(PASTA_SAIDA / "comparacao_detalhada.csv", index=False)

    referencia = resultados["acao_referencia"]
    metricas = pd.DataFrame(
        [
            calcular_metricas(
                referencia,
                resultados["acao_hydros_historico"],
                resultados["processamento_conclusivo_historico"],
                "historico",
            ),
            calcular_metricas(
                referencia,
                resultados["acao_hydros_sem_historico"],
                resultados["processamento_conclusivo_sem_historico"],
                "sem_historico",
            ),
        ]
    )

    metricas["confianca_media"] = [
        round(float(resultados["confianca_historico"].mean()), 4),
        round(float(resultados["confianca_sem_historico"].mean()), 4),
    ]
    metricas["conflito_medio"] = [
        round(float(resultados["conflito_historico"].mean()), 4),
        round(float(resultados["conflito_sem_historico"].mean()), 4),
    ]
    metricas["compatibilidade_aps_media"] = [
        round(float(resultados["compatibilidade_aps_historico"].mean()), 4),
        round(float(resultados["compatibilidade_aps_sem_historico"].mean()), 4),
    ]
    metricas["peso_efetivo_aps_medio"] = [
        round(float(resultados["peso_efetivo_aps_historico"].mean()), 4),
        round(float(resultados["peso_efetivo_aps_sem_historico"].mean()), 4),
    ]
    metricas["taxa_dependencia_material_aps"] = [
        round(float(resultados["dependencia_material_aps_historico"].mean()), 4),
        round(float(resultados["dependencia_material_aps_sem_historico"].mean()), 4),
    ]
    metricas.to_csv(PASTA_SAIDA / "metricas_resumo.csv", index=False)

    pares, resumo_pareado = gerar_comparacao_pareada(resultados)
    pares.to_csv(PASTA_SAIDA / "comparacao_pareada.csv", index=False)
    resumo_pareado.to_csv(PASTA_SAIDA / "resumo_pareado.csv", index=False)
    gerar_metricas_por_cenario(resultados).to_csv(
        PASTA_SAIDA / "metricas_por_cenario.csv", index=False
    )

    salvar_matriz_confusao(
        referencia,
        resultados["acao_hydros_historico"],
        "matriz_confusao_historico.csv",
    )
    salvar_matriz_confusao(
        referencia,
        resultados["acao_hydros_sem_historico"],
        "matriz_confusao_sem_historico.csv",
    )

    print("\n=== MÉTRICAS RESUMO ===")
    print(metricas.to_string(index=False))
    print("\n=== COMPARAÇÃO PAREADA ===")
    print(resumo_pareado.to_string(index=False))
    print(f"\nResultados salvos em: {PASTA_SAIDA.resolve()}")
    print("EXPERIMENTO I: OK")


if __name__ == "__main__":
    main()
