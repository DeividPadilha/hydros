import pandas as pd
from src.evaluation.irrigation_policy import IrrigationActionPolicy, IrrigationPolicyConfig, derive_policy_from_reference

ref = pd.DataFrame({'irrigacao_aplicada':[0,8,10,12,0,10]})
cfg = derive_policy_from_reference(ref)
assert cfg.base_mm == 10.0
assert cfg.min_mm == 8.0
assert cfg.max_mm == 12.0
assert cfg.step_mm == 2.0  # diferenças 2,2 -> mediana 2

p = IrrigationActionPolicy(IrrigationPolicyConfig(base_mm=10, step_mm=2, min_mm=6, max_mm=14))
seq = [p.apply(a) for a in ['manter_irrigacao','iniciar_irrigacao','manter_irrigacao','aumentar_irrigacao','reduzir_irrigacao','finalizar_irrigacao',None]]
assert seq == [0.0,10.0,10.0,12.0,10.0,0.0,0.0], seq
print('TEST EXPERIMENT 2: OK')
