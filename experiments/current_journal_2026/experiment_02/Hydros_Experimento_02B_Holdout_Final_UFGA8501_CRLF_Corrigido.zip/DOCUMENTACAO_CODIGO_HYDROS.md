# Documentação técnica do Hydros 0.4.1-qualificacao-final

## 1. Objetivo do protótipo

O Hydros materializa o modelo computacional descrito na tese para gerenciamento hídrico inteligente em unidades de manejo agrícola. O software organiza dados em históricos de contextos, executa agentes especializados, integra evidências e determina uma ação de manejo hídrico rastreável.

O protótipo não aciona equipamentos físicos. Quando as evidências não permitem uma determinação segura, o AMDH registra o processamento como inconclusivo.

## 2. Fluxo principal

```text
Contextos + histórico H(Ui)
        |
        +--> Aclim, Ahid, Afen, Ageo, Aprod, Ahist
        |                |
        |               AIEC -> Ehc
        |
        +--> ARG -> Earg
        |
        +--> APS -> Eaps

Ehc + Earg + Eaps
        |
       AMDH
        |
verificação de consistência
        |
 ação ou processamento inconclusivo
        |
rastreabilidade semântica
```

A HydrosOnto é consultada para verificação semântica e registro de rastreabilidade. Ela não altera o score do AMDH.

## 3. Agentes

### Agentes especializados

- `Aclim`: precipitação, temperatura, graus-dia e evapotranspiração;
- `Ahid`: umidade, água disponível, irrigação e estresse;
- `Afen`: estágio fenológico, coeficiente de cultura e soma térmica;
- `Ageo`: localização, solo e descritores espaciais;
- `Aprod`: produtividade e sua evolução;
- `Ahist`: tendências e trajetória temporal.

### Agentes centrais

- `AIEC`: integra as seis evidências especializadas e produz `Ehc`;
- `ARG`: aplica regras agronômicas explícitas e produz `Earg`;
- `APS`: executa o classificador supervisionado e produz `Eaps`;
- `AMDH`: integra `Ehc`, `Earg` e `Eaps`, verifica consistência e determina a ação.

## 4. Condições e ações

Condições hídricas canônicas:

```text
adequada
atencao
critica
```

Ações de manejo:

```text
iniciar_irrigacao
manter_irrigacao
aumentar_irrigacao
reduzir_irrigacao
finalizar_irrigacao
```

Campos legados existentes no banco ou em contratos antigos, como `revisao_humana`, são mantidos somente por compatibilidade e migração. Na arquitetura atual eles permanecem desativados e não constituem etapa do fluxo de determinação da ação.

## 5. Modos de execução

### Histórico

Usa o contexto atual e registros anteriores. A janela padrão contém cinco contextos e é configurável.

### sem Histórico

Mantém os mesmos componentes, mas remove o acesso à memória temporal. É usado como controle do Experimento I.

## 6. HydrosEngine

Arquivo principal:

```text
src/services/hydros_engine.py
```

Responsabilidades principais:

1. validar e organizar os contextos;
2. selecionar o modo de execução;
3. executar agentes especializados;
4. executar AIEC, ARG e APS;
5. consultar a HydrosOnto como verificação semântica;
6. executar o AMDH;
7. registrar rastreabilidade e dados de execução.

## 7. HydrosOnto

Ontologia formal:

```text
ontology/hydrosonto.owl
```

Backend de integração:

```text
src/ontology/hydros_onto.py
```

No protótipo, o backend usa `rdflib` para ler os axiomas necessários à verificação semântica. A classificação formal da ontologia foi validada separadamente no Protégé com HermiT.

A integração respeita duas regras:

1. a condição semântica não entra no cálculo do score do AMDH;
2. após uma ação conclusiva, as relações necessárias à rastreabilidade podem ser registradas semanticamente.

## 8. APS

Arquivos principais:

```text
src/agents/aps_agent.py
src/models/train_aps_model.py
src/services/feature_extractor.py
src/models/aps_model_metadata.json
```

O alvo atual é `adequada`, `atencao`, `critica`. A janela de treinamento é registrada no metadata. Se a janela de execução for diferente, o uso científico é marcado como restrito.

O modelo atual é provisório. A base possui uma única trajetória e a classe crítica não aparece em validação e teste. O software registra essa limitação explicitamente em vez de ocultá-la.

## 9. AMDH

Arquivo:

```text
src/agents/amdh_agent.py
```

O AMDH calcula scores por ação a partir das três evidências principais, considera estado da irrigação, conflitos, confiança e completude e seleciona a ação operacionalmente válida de maior score.

Se confiança, completude ou conflito ultrapassarem os critérios de segurança definidos, `status_processamento` é `inconclusivo` e `D(Ui)` permanece `None`. A ação candidata é registrada apenas para diagnóstico e rastreabilidade.

## 10. Persistência

Arquivo:

```text
src/database/database.py
```

A persistência mantém dados da execução, modo, evidências, scores, condição, ação, confiança, conflitos e rastreabilidade. Colunas antigas são preservadas para migração de bancos anteriores, sem reintroduzir o fluxo antigo de aprovação humana.

## 11. DSSAT

Arquivo de integração:

```text
src/integrations/dssat_adapter.py
```

O DSSAT é recurso de avaliação. O adaptador transforma dados de simulação para o formato de contexto esperado pelo Hydros. O núcleo do Hydros não depende do DSSAT para operar.

## 12. Experimento I

Executor:

```text
run_experimento_1.py
```

Compara Histórico e sem Histórico sobre as mesmas observações. Processamentos inconclusivos permanecem como inconclusivos. Os resultados atuais ficam em `results/experimento_1/`.

## 13. Análise de sensibilidade

Executor:

```text
run_sensibilidade.py
```

Avalia variações pré-definidas nos pesos do AMDH, nos pesos do AIEC e nos limiares de inconclusão. A rotina foi construída como análise de robustez e não como busca oportunista pela configuração de maior desempenho.

## 14. Experimento II

Executor:

```text
run_experimento_2.py
```

A política operacional está em:

```text
src/evaluation/irrigation_policy.py
```

Ela converte ações em lâmina de irrigação para permitir a comparação com um manejo de referência. O resultado atual é restrito ao único par DSSAT compatível disponível e não é generalizável.

## 15. Interface

Arquivo:

```text
app.py
```

A interface Streamlit expõe os modos Histórico e sem Histórico, janela temporal, evidências, inferências, scores, ação, status conclusivo/inconclusivo e rastreabilidade.

## 16. Validação e release

Validação integral:

```text
python run_hydros_validation.py
```

Congelamento:

```text
python freeze_hydros_release.py
```

O relatório separa `validação de software` de `prontidão científica`. O primeiro pode estar aprovado enquanto o segundo permanece provisório.


## Checkpoint C: tempo térmico

O contrato interno distingue `graus_dia_periodo` de `soma_termica_acumulada`. A sigla `gd` da formulação da tese mapeia para `soma_termica_acumulada`. A coluna `graus_dia` é mantida somente como alias legado de entrada. A normalização central está em `src/core/thermal_time.py` e é aplicada pelo motor, pelo validador, pelo adaptador DSSAT e pelo treinamento do APS.
