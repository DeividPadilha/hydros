# HYDROS-EXP02B — checkpoint de desenvolvimento V3 → V4

Data: 2026-08-14

## Resultado observado na validação V3

A validação de desenvolvimento foi executada em UFGA7801 e UFGA8401, sem executar o holdout UFGA8501.

### UFGA7801

Tratamento T2 (rainfed):
- 98 períodos de controle (DAP >= 20);
- 44 dias DSSAT com estresse >= 0,25;
- Hydros determinou `iniciar_irrigacao` em 42 desses 44 dias;
- 44 dias com Ehid em atenção/crítica e 44 decisões `iniciar_irrigacao` nesses dias;
- nenhum `iniciar_irrigacao` com Ehid adequada;
- produtividade DSSAT da trajetória fixa: 1088 kg/ha;
- irrigação DSSAT da trajetória fixa: 0 mm.

Tratamento T1 (irrigado):
- 107 períodos de controle;
- 20 dias DSSAT com estresse >= 0,25;
- 12 decisões `iniciar_irrigacao` nesses 20 dias;
- nenhum início com Ehid adequada;
- produtividade: 2806 kg/ha;
- irrigação efetiva: 147 mm.

### UFGA8401

Tratamento T1 (irrigado):
- 112 períodos de controle;
- 0 dias DSSAT com estresse >= 0,25;
- 0 decisões `iniciar_irrigacao`;
- Ehid adequada em 112/112 períodos;
- produtividade: 3381 kg/ha;
- irrigação efetiva: 341 mm.

Tratamento T2:
- 109 períodos de controle;
- 18 dias DSSAT com estresse >= 0,25;
- Hydros determinou `iniciar_irrigacao` em 16 desses 18 dias;
- 16 dias com Ehid em atenção e 16 decisões `iniciar_irrigacao` nesses dias;
- nenhum início com Ehid adequada;
- produtividade: 2286 kg/ha;
- irrigação efetiva: 197 mm.

## Interpretação

O comportamento V3 é promissor como teste de sanidade da decisão: o Hydros reage à maior parte dos períodos de estresse hídrico nos cenários de desenvolvimento e não inicia irrigação quando Ehid está adequada. Em UFGA8401 T1, cenário sem estresse relevante, não houve início indevido.

Esses números ainda NÃO são o Experimento II final, porque as ações foram avaliadas sobre trajetórias DSSAT previamente fixadas. Ainda falta executar a irrigação decidida pelo Hydros no DSSAT e permitir que os estados futuros do solo e da cultura respondam a esse manejo.

## Dois pontos corrigidos antes da V4

1. O teste `same_weather=false` da V3 foi causado pela comparação por número de linhas. As trajetórias podem terminar em datas diferentes devido ao desenvolvimento da cultura. A V4 passa a comparar as variáveis meteorológicas por datas coincidentes, evitando declarar clima diferente apenas porque a duração simulada mudou.

2. A V4 implementa controle causal em desenvolvimento: a decisão após C(t) entra apenas no dia seguinte, o arquivo DSSAT candidato é reexecutado quando a programação muda e o novo estado é lido antes da próxima decisão.

## Segurança experimental

- UFGA8501 permanece bloqueado no código de desenvolvimento.
- UFGA7801 e UFGA8401 continuam sendo usados apenas para desenvolvimento.
- T1 de cada experimento permanece como referência DSSAT sem modificação.
- O candidato utiliza T2, preserva somente o prefixo de irrigação que for comum a T1 e T2 e substitui os eventos futuros pela programação Hydros.
- A cópia oficial do arquivo .SBX não é sobrescrita.
- A política de lâmina é derivada apenas dos eventos T1 já existentes, antes do holdout.
- Nenhum peso do AMDH é alterado na V4.
- Suíte local do pacote V4: 44 testes aprovados.

## Próximo passo

Executar `run_closed_loop_desenvolvimento_exp02b_v4.py` em uma máquina com DSSAT 4.8.5 e avaliar água aplicada, produtividade, estresse e drenagem do manejo efetivamente simulado pelo Hydros em UFGA7801 e UFGA8401. Somente após esse checkpoint o holdout UFGA8501 poderá ser considerado.
