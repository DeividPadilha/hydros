from src.evaluation.dssat_sbx_schedule import (
    extract_treatment_irrigation_events,
    get_treatment_factor_level,
)

UFGA7801_MIN = """*TREATMENTS                        -------------FACTOR LEVELS------------
@N R O C TNAME.................... CU FL SA IC MP MI MF MR MC MT ME MH SM
 1 1 1 0 78 IRRIG, light rate,freq  1  1  0  1  1  1  0  1  0  0  0  0  1
 2 1 1 0 78 RAINFED BRAGG           1  1  0  1  1  0  0  1  0  0  0  0  1
*IRRIGATION AND WATER MANAGEMENT
@I  EFIR  IDEP  ITHR  IEPT  IOFF  IAME  IAMT IRNAME
 1   .75   -99   -99   -99   -99   -99   -99 -99
@I IDATE  IROP IRVAL
 1 78167 IR001     8
 1 78170 IR001     8
*RESIDUES AND ORGANIC FERTILIZER
"""

UFGA8401_MIN = """*TREATMENTS                        -------------FACTOR LEVELS------------
@N R O C TNAME.................... CU FL SA IC MP MI MF MR MC MT ME MH SM
 1 1 1 0 84 IRRIGATED BRAGG         1  1  0  1  1  1  1  1  0  0  0  0  1
 2 1 1 0 84 RAINFED BRAGG, LATE IR  1  1  0  1  1  2  1  1  0  0  0  0  1
*IRRIGATION AND WATER MANAGEMENT
@I  EFIR  IDEP  ITHR  IEPT  IOFF  IAME  IAMT IRNAME
 1  1.00   -99   -99   -99   -99   -99   -99 -99
@I IDATE  IROP IRVAL
 1 84164 IR001    12
 1 84166 IR001    12
@I  EFIR  IDEP  ITHR  IEPT  IOFF  IAME  IAMT IRNAME
 2  1.00   -99   -99   -99   -99   -99   -99 -99
@I IDATE  IROP IRVAL
 2 84164 IR001    12
 2 84166 IR001    12
 2 84262 IR001    48
*FERTILIZERS (INORGANIC)
"""


def test_ufga7801_treatment_number_is_not_irrigation_level():
    assert get_treatment_factor_level(UFGA7801_MIN, 1, "MI") == 1
    assert get_treatment_factor_level(UFGA7801_MIN, 2, "MI") == 0
    assert extract_treatment_irrigation_events(UFGA7801_MIN, 2) == []


def test_ufga8401_t2_references_irrigation_level_2():
    assert get_treatment_factor_level(UFGA8401_MIN, 1, "MI") == 1
    assert get_treatment_factor_level(UFGA8401_MIN, 2, "MI") == 2
    events = extract_treatment_irrigation_events(UFGA8401_MIN, 2)
    assert [(e.date_code, e.amount_mm) for e in events] == [
        (84164, 12.0),
        (84166, 12.0),
        (84262, 48.0),
    ]
