"""Gera tabelas, figuras e síntese do Experimento I do Hydros.

O script utiliza exclusivamente resultados já produzidos por
``run_experimento_1.py``. Não executa o Hydros e não altera parâmetros.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix

ENTRADA_DETALHADA = Path("results/experimento_1/comparacao_detalhada.csv")
ENTRADA_RESUMO = Path("results/experimento_1/metricas_resumo.csv")
ENTRADA_BINARIAS = Path("results/experimento_1/diagnostico/metricas_binarias.csv")
ENTRADA_PAREADA = Path("results/experimento_1/resumo_pareado.csv")
SAIDA = Path("results/experimento_1/artigo")

ACOES_INTENSIFICACAO = {"iniciar_irrigacao", "aumentar_irrigacao"}
MODOS = ("historico", "sem_historico")

COLUNAS_OBRIGATORIAS = {
    "cenario_id",
    "data",
    "dia_safra",
    "acao_referencia",
    "saida_hydros_historico",
    "saida_hydros_sem_historico",
    "processamento_conclusivo_historico",
    "processamento_conclusivo_sem_historico",
    "confianca_historico",
    "confianca_sem_historico",
    "conflito_historico",
    "conflito_sem_historico",
}


def carregar_dados() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    for caminho in (ENTRADA_DETALHADA, ENTRADA_RESUMO, ENTRADA_BINARIAS, ENTRADA_PAREADA):
        if not caminho.exists():
            raise FileNotFoundError(f"Arquivo ausente: {caminho}")

    detalhado = pd.read_csv(ENTRADA_DETALHADA)
    faltantes = sorted(COLUNAS_OBRIGATORIAS - set(detalhado.columns))
    if faltantes:
        raise ValueError("Colunas ausentes: " + ", ".join(faltantes))

    return (
        detalhado,
        pd.read_csv(ENTRADA_RESUMO),
        pd.read_csv(ENTRADA_BINARIAS),
        pd.read_csv(ENTRADA_PAREADA),
    )


def binarizar(serie: pd.Series) -> pd.Series:
    return serie.fillna("inconclusivo").astype(str).isin(ACOES_INTENSIFICACAO).astype(int)


def classificar_divergencias(df: pd.DataFrame) -> pd.DataFrame:
    divergencias = df[
        df["saida_hydros_historico"] != df["saida_hydros_sem_historico"]
    ].copy()

    if divergencias.empty:
        divergencias["classificacao_divergencia"] = pd.Series(dtype="object")
        return divergencias

    h_ok = divergencias["concordancia_referencia_historico"].astype(bool)
    s_ok = divergencias["concordancia_referencia_sem_historico"].astype(bool)
    divergencias["classificacao_divergencia"] = "ambos_nao_concordam"
    divergencias.loc[h_ok & s_ok, "classificacao_divergencia"] = "ambos_concordam"
    divergencias.loc[h_ok & ~s_ok, "classificacao_divergencia"] = "vantagem_historico"
    divergencias.loc[~h_ok & s_ok, "classificacao_divergencia"] = "vantagem_sem_historico"

    preferidas = [
        "cenario_id", "cenario", "dssat_run", "data", "dia_safra",
        "acao_referencia", "saida_hydros_historico", "saida_hydros_sem_historico",
        "classificacao_divergencia", "processamento_conclusivo_historico",
        "processamento_conclusivo_sem_historico", "motivos_inconclusao_historico",
        "motivos_inconclusao_sem_historico", "umidade_solo_pct", "agua_disponivel_mm",
        "irrigacao_referencia_mm", "estresse_dssat_original", "ehc_historico",
        "earg_historico", "eaps_historico", "ehc_sem_historico",
        "earg_sem_historico", "eaps_sem_historico", "confianca_historico",
        "confianca_sem_historico", "conflito_historico", "conflito_sem_historico",
        "compatibilidade_aps_historico", "compatibilidade_aps_sem_historico",
    ]
    return divergencias[[c for c in preferidas if c in divergencias.columns]].sort_values(
        ["cenario_id", "dia_safra"], kind="stable"
    )


def tabela_metricas_principais(resumo: pd.DataFrame, binarias: pd.DataFrame) -> pd.DataFrame:
    r_idx = resumo.set_index("modo")
    b_idx = binarias.set_index("modo")
    linhas: list[dict[str, object]] = []
    for modo in MODOS:
        r = r_idx.loc[modo]
        b = b_idx.loc[modo]
        linhas.append(
            {
                "modo": modo,
                "n_observacoes": int(r["n_observacoes"]),
                "n_conclusivas": int(r["n_conclusivas"]),
                "taxa_conclusiva": float(r["taxa_conclusiva"]),
                "acuracia_multiclasse": float(r["acuracia"]),
                "f1_macro_multiclasse": float(r["f1_macro"]),
                "kappa_cohen": float(r["kappa_cohen"]),
                "precisao_intensificacao": float(b["precisao"]),
                "recall_intensificacao": float(b["sensibilidade_recall"]),
                "f1_intensificacao": float(b["f1"]),
                "acuracia_balanceada_intensificacao": float(b["acuracia_balanceada"]),
                "mcc_intensificacao": float(b["mcc"]),
                "confianca_media": float(r["confianca_media"]),
                "conflito_medio": float(r["conflito_medio"]),
                "compatibilidade_aps_media": float(r.get("compatibilidade_aps_media", np.nan)),
                "peso_efetivo_aps_medio": float(r.get("peso_efetivo_aps_medio", np.nan)),
                "taxa_dependencia_material_aps": float(r.get("taxa_dependencia_material_aps", np.nan)),
                "verdadeiros_positivos": int(b["verdadeiros_positivos"]),
                "falsos_positivos": int(b["falsos_positivos"]),
                "falsos_negativos": int(b["falsos_negativos"]),
                "verdadeiros_negativos": int(b["verdadeiros_negativos"]),
            }
        )
    return pd.DataFrame(linhas)


def eventos_positivos_referencia(df: pd.DataFrame) -> pd.DataFrame:
    eventos = df[binarizar(df["acao_referencia"]).eq(1)].copy()
    eventos["detectado_historico"] = binarizar(eventos["saida_hydros_historico"]).astype(bool)
    eventos["detectado_sem_historico"] = binarizar(eventos["saida_hydros_sem_historico"]).astype(bool)
    colunas = [
        "cenario_id", "data", "dia_safra", "acao_referencia",
        "saida_hydros_historico", "saida_hydros_sem_historico",
        "detectado_historico", "detectado_sem_historico",
        "processamento_conclusivo_historico", "processamento_conclusivo_sem_historico",
        "umidade_solo_pct", "agua_disponivel_mm", "irrigacao_referencia_mm",
        "estresse_dssat_original", "confianca_historico", "confianca_sem_historico",
        "conflito_historico", "conflito_sem_historico",
    ]
    return eventos[[c for c in colunas if c in eventos.columns]].sort_values(
        ["cenario_id", "dia_safra"], kind="stable"
    )


def acoes_sem_suporte_referencia(df: pd.DataFrame) -> pd.DataFrame:
    classes_ref = set(df["acao_referencia"].astype(str).unique())
    partes: list[pd.DataFrame] = []
    for modo in MODOS:
        coluna = f"saida_hydros_{modo}"
        mascara = ~df[coluna].astype(str).isin(classes_ref | {"inconclusivo"})
        if mascara.any():
            parte = df.loc[mascara].copy()
            parte.insert(0, "modo", modo)
            partes.append(parte)
    if not partes:
        return pd.DataFrame(columns=["modo", "cenario_id", "data", "dia_safra", "acao_referencia"])
    resultado = pd.concat(partes, ignore_index=True)
    colunas = [
        "modo", "cenario_id", "data", "dia_safra", "acao_referencia",
        "saida_hydros_historico", "saida_hydros_sem_historico",
        "umidade_solo_pct", "agua_disponivel_mm", "irrigacao_referencia_mm",
        "estresse_dssat_original",
    ]
    return resultado[[c for c in colunas if c in resultado.columns]]


def salvar_figura_metricas(metricas: pd.DataFrame) -> None:
    dados = metricas.set_index("modo")[[
        "precisao_intensificacao", "recall_intensificacao", "f1_intensificacao",
        "acuracia_balanceada_intensificacao", "mcc_intensificacao",
    ]].T
    dados.columns = ["Historical", "Without history"]
    ax = dados.plot(kind="bar", figsize=(10, 5.5))
    ax.set_xlabel("Metric")
    ax.set_ylabel("Value")
    ax.set_ylim(-0.1, 1.0)
    ax.set_title("Experiment I: irrigation intensification metrics")
    ax.legend(title="Hydros mode")
    ax.tick_params(axis="x", rotation=25)
    ax.grid(axis="y", alpha=0.25)
    plt.tight_layout()
    plt.savefig(SAIDA / "figure_metrics_comparison.png", dpi=300, bbox_inches="tight")
    plt.close()


def salvar_matriz_binaria(df: pd.DataFrame, modo: str) -> None:
    y_true = binarizar(df["acao_referencia"])
    y_pred = binarizar(df[f"saida_hydros_{modo}"])
    matriz = confusion_matrix(y_true, y_pred, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(5.2, 4.5))
    imagem = ax.imshow(matriz)
    for (i, j), valor in np.ndenumerate(matriz):
        ax.text(j, i, str(int(valor)), ha="center", va="center")
    ax.set_xticks([0, 1], labels=["No intensification", "Intensification"])
    ax.set_yticks([0, 1], labels=["No intensification", "Intensification"])
    ax.set_xlabel("Hydros")
    ax.set_ylabel("Reference")
    titulo = "Historical" if modo == "historico" else "Without history"
    ax.set_title(f"Binary confusion matrix: {titulo}")
    fig.colorbar(imagem, ax=ax)
    plt.tight_layout()
    plt.savefig(SAIDA / f"figure_binary_confusion_matrix_{modo}.png", dpi=300, bbox_inches="tight")
    plt.close()


def salvar_figura_eventos(df: pd.DataFrame) -> None:
    eventos = eventos_positivos_referencia(df).reset_index(drop=True)
    if eventos.empty:
        # Mantém artefato determinístico mesmo sem evento positivo.
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.text(0.5, 0.5, "No positive reference event", ha="center", va="center")
        ax.axis("off")
    else:
        x = np.arange(1, len(eventos) + 1)
        fig, ax = plt.subplots(figsize=(9, 4.8))
        ax.scatter(x, np.full(len(eventos), 2), marker="o", label="Reference")
        mask_h = eventos["detectado_historico"].to_numpy()
        mask_s = eventos["detectado_sem_historico"].to_numpy()
        ax.scatter(x[mask_h], np.full(int(mask_h.sum()), 1), marker="o", label="Historical Hydros")
        ax.scatter(x[mask_s], np.full(int(mask_s.sum()), 0), marker="o", label="Hydros without history")
        ax.set_yticks([0, 1, 2], labels=["Without history", "Historical", "Reference"])
        ax.set_xticks(x)
        ax.set_xlabel("Reference irrigation event")
        ax.set_ylabel("Detection")
        ax.set_title("Detection of reference irrigation intensification events")
        ax.grid(axis="x", alpha=0.2)
        ax.legend()
    plt.tight_layout()
    plt.savefig(SAIDA / "figure_reference_event_detection.png", dpi=300, bbox_inches="tight")
    plt.close()


def salvar_figura_processamento(resumo: pd.DataFrame) -> None:
    dados = resumo.set_index("modo")[[
        "taxa_conclusiva", "confianca_media", "conflito_medio",
        "compatibilidade_aps_media", "peso_efetivo_aps_medio",
        "taxa_dependencia_material_aps",
    ]].T
    dados.index = [
        "Conclusive rate", "Confidence", "Conflict", "APS compatibility",
        "Effective APS weight", "Material APS dependence",
    ]
    dados.columns = ["Historical", "Without history"]
    ax = dados.plot(kind="bar", figsize=(10, 5.5))
    ax.set_xlabel("Processing indicator")
    ax.set_ylabel("Mean or rate")
    ax.set_ylim(0, 1)
    ax.set_title("Experiment I processing indicators")
    ax.legend(title="Hydros mode")
    ax.tick_params(axis="x", rotation=25)
    ax.grid(axis="y", alpha=0.25)
    plt.tight_layout()
    plt.savefig(SAIDA / "figure_processing_indicators.png", dpi=300, bbox_inches="tight")
    plt.close()


def gerar_resumo_markdown(
    df: pd.DataFrame,
    metricas: pd.DataFrame,
    divergencias: pd.DataFrame,
    sem_suporte: pd.DataFrame,
    pareada: pd.DataFrame,
) -> str:
    m = metricas.set_index("modo")
    hist = m.loc["historico"]
    sem = m.loc["sem_historico"]
    p = pareada.iloc[0]

    contagem_ref = df["acao_referencia"].value_counts()
    classes_ref = ", ".join(f"{k}={int(v)}" for k, v in contagem_ref.items())
    n_div = int(p["n_saidas_diferentes"])
    vantagem_hist = int(p["n_vantagem_historico"])
    vantagem_sem = int(p["n_vantagem_sem_historico"])
    classes_sem_suporte = 0 if sem_suporte.empty else len(sem_suporte)

    return f"""# Síntese do Experimento I do Hydros

## Configuração

Foram analisadas **{len(df)} observações pareadas** provenientes de **{df['cenario_id'].nunique()} execuções DSSAT**. Em cada observação, os dois modos receberam o mesmo contexto atual; apenas o Hydros Histórico teve acesso ao histórico de contextos. A referência operacional apresentou: {classes_ref}.

## Histórico versus sem Histórico

| Métrica | Hydros Histórico | Hydros sem Histórico |
|---|---:|---:|
| Taxa conclusiva | {hist['taxa_conclusiva']:.4f} | {sem['taxa_conclusiva']:.4f} |
| Acurácia multiclasse | {hist['acuracia_multiclasse']:.4f} | {sem['acuracia_multiclasse']:.4f} |
| F1 macro multiclasse | {hist['f1_macro_multiclasse']:.4f} | {sem['f1_macro_multiclasse']:.4f} |
| Precisão de intensificação | {hist['precisao_intensificacao']:.4f} | {sem['precisao_intensificacao']:.4f} |
| Recall de intensificação | {hist['recall_intensificacao']:.4f} | {sem['recall_intensificacao']:.4f} |
| F1 de intensificação | {hist['f1_intensificacao']:.4f} | {sem['f1_intensificacao']:.4f} |
| MCC de intensificação | {hist['mcc_intensificacao']:.4f} | {sem['mcc_intensificacao']:.4f} |

Foram observadas **{n_div} saídas diferentes** entre os modos. Em {vantagem_hist} observações somente o modo Histórico concordou com a referência e em {vantagem_sem} somente o modo sem Histórico concordou. Processamentos inconclusivos foram preservados como inconclusivos e não convertidos artificialmente em uma ação de manejo.

## Interpretação

A comparação isola a disponibilidade da memória temporal mantendo o restante da arquitetura. Assim, diferenças entre as saídas fornecem evidência experimental sobre o efeito do histórico no protótipo. A interpretação deve permanecer descritiva nesta etapa, principalmente porque há apenas duas trajetórias simuladas e o APS atual ainda é legado.

## Limitações

1. O DSSAT é utilizado para construir cenários controlados; a ação de referência não é tratada como verdade agronômica absoluta.
2. O conjunto atual possui apenas duas execuções e cobertura limitada das cinco ações possíveis.
3. Foram registradas {classes_sem_suporte} saídas de ações que não ocorrem na referência; elas são exploratórias.
4. O APS atual requer retreinamento com separação por trajetórias independentes e com as três classes finais.
5. O Experimento I avalia a contribuição do histórico para as saídas do Hydros. Ele não demonstra, por si só, economia de água, redução de estresse ou ganho de produtividade; esses efeitos pertencem ao Experimento II.
"""


def main() -> None:
    detalhado, resumo, binarias, pareada = carregar_dados()
    SAIDA.mkdir(parents=True, exist_ok=True)

    metricas = tabela_metricas_principais(resumo, binarias)
    divergencias = classificar_divergencias(detalhado)
    positivos = eventos_positivos_referencia(detalhado)
    sem_suporte = acoes_sem_suporte_referencia(detalhado)

    metricas.to_csv(SAIDA / "table_main_metrics.csv", index=False)
    divergencias.to_csv(SAIDA / "table_divergent_cases.csv", index=False)
    positivos.to_csv(SAIDA / "table_reference_positive_events.csv", index=False)
    sem_suporte.to_csv(SAIDA / "table_actions_without_reference_support.csv", index=False)

    salvar_figura_metricas(metricas)
    salvar_matriz_binaria(detalhado, "historico")
    salvar_matriz_binaria(detalhado, "sem_historico")
    salvar_figura_eventos(detalhado)
    salvar_figura_processamento(resumo)

    (SAIDA / "experimental_results_summary.md").write_text(
        gerar_resumo_markdown(detalhado, metricas, divergencias, sem_suporte, pareada),
        encoding="utf-8",
    )

    p = pareada.iloc[0]
    print("\n=== ARTEFATOS DO EXPERIMENTO I ===")
    print(f"Observações: {len(detalhado)}")
    print(f"Divergências entre os modos: {int(p['n_saidas_diferentes'])}")
    print(f"Casos favoráveis ao Histórico: {int(p['n_vantagem_historico'])}")
    print(f"Casos favoráveis ao sem Histórico: {int(p['n_vantagem_sem_historico'])}")
    print(f"Eventos positivos de referência: {len(positivos)}")
    print(f"Arquivos gerados em: {SAIDA.resolve()}")
    print("ARTEFATOS DO EXPERIMENTO I: OK")


if __name__ == "__main__":
    main()
