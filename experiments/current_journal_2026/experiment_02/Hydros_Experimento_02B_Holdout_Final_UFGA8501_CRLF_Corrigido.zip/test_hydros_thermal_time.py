"""Valida o contrato de soma térmica acumulada do checkpoint C."""

from __future__ import annotations

import pandas as pd

from src.config.hydros_terms import MAPEAMENTO_CSV_MODELO, VERSAO_ARQUITETURA
from src.core.thermal_time import normalizar_tempo_termico
from src.services.feature_extractor import FeatureExtractor


def main() -> None:
    legacy = pd.DataFrame(
        {
            "data": ["2026/01/01", "2026/01/02", "2026/01/01", "2026/01/02"],
            "talhao": ["U1", "U1", "U2", "U2"],
            "cultura": ["soja"] * 4,
            "graus_dia": [10.0, 12.0, 7.0, 8.0],
        }
    )
    normalized = normalizar_tempo_termico(legacy)
    u1 = normalized[normalized["talhao"] == "U1"]
    u2 = normalized[normalized["talhao"] == "U2"]
    assert u1["graus_dia_periodo"].tolist() == [10.0, 12.0]
    assert u1["soma_termica_acumulada"].tolist() == [10.0, 22.0]
    assert u2["soma_termica_acumulada"].tolist() == [7.0, 15.0]

    context = pd.DataFrame(
        {
            "cultura": ["soja"] * 5,
            "loc": ["MT"] * 5,
            "solo": ["argiloso"] * 5,
            "estagio_fenologico": ["V3"] * 5,
            "precipitacao": [0, 1, 0, 0, 0],
            "temperatura": [25, 26, 27, 28, 29],
            "graus_dia": [10, 11, 12, 13, 14],
            "evapotranspiracao": [4, 4, 5, 5, 6],
            "coeficiente_cultura": [0.8] * 5,
            "umidade_solo": [70, 68, 66, 64, 62],
            "agua_disponivel": [100, 98, 96, 94, 92],
            "irrigacao_aplicada": [0] * 5,
            "produtividade": [3500] * 5,
            "data": pd.date_range("2026-01-01", periods=5).strftime("%Y/%m/%d"),
            "talhao": ["U1"] * 5,
        }
    )
    context = normalizar_tempo_termico(context)
    xt = FeatureExtractor().extrair(context)
    assert "soma_termica_acumulada" in xt.columns
    assert "graus_dia_periodo" in xt.columns
    assert "incremento_termico_janela" in xt.columns
    assert "graus_dia_medio" not in xt.columns
    assert MAPEAMENTO_CSV_MODELO["gd"] == "soma_termica_acumulada"
    assert VERSAO_ARQUITETURA == "0.4.1-qualificacao-final"

    print("CONTRATO DE TEMPO TÉRMICO: OK")


if __name__ == "__main__":
    main()
