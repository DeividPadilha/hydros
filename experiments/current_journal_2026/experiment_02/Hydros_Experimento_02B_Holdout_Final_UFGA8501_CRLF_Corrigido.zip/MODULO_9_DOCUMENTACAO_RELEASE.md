# Módulo 9: documentação e release

Data: 13/08/2026

## Versão

A versão do protótipo foi atualizada para:

```text
0.4.0-qualificacao
```

O incremento identifica a versão consolidada após o alinhamento do software com a tese e a implementação dos Módulos 1 a 8.

## Documentação atualizada

Foram revisados:

- `README.md`;
- `DOCUMENTACAO_CODIGO_HYDROS.md`;
- `STATUS_HYDROS.md`;
- `REPRODUCIBILITY.md`;
- `CHANGELOG.md`.

A documentação atual remove descrições antigas do Hydros como sistema de recomendação com aceite/rejeição do usuário e registra o fluxo atual de ação determinada pelo AMDH, processamento inconclusivo, HydrosOnto fora do score, APS provisório e experimentos atuais.

## Release

`freeze_hydros_release.py` foi atualizado para incluir a versão atual do código, ontologia, dados experimentais, modelos, testes, documentação e resultados dos módulos atuais.

O pacote de release inclui:

- núcleo `src/`;
- `ontology/hydrosonto.owl`;
- dados necessários aos experimentos;
- resultados atuais do Experimento I;
- resultados do APS do Módulo 5;
- análise de sensibilidade;
- resultados do Experimento II;
- relatório de validação;
- testes;
- documentação;
- manifesto com SHA-256 de cada arquivo.

Snapshots `legacy` não são incluídos na release enxuta, mas permanecem preservados no projeto completo da entrega.

## Interpretação da release

A release representa um protótipo funcional, rastreável e reproduzível para continuidade da tese. O campo de prontidão científica permanece provisório porque ainda são necessárias novas trajetórias para APS e experimentos.
