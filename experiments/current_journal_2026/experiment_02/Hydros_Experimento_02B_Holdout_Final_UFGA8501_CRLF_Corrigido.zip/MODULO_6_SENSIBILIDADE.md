# Módulo 6 — Análise de sensibilidade

Data: 12/08/2026

## Ponto de retorno

A Entrega 5 permanece preservada externamente como `hydros_entrega_5_aps_tres_classes.zip`.
Nenhum arquivo existente do núcleo `src/` foi alterado para executar este módulo.

## Objetivo

Medir a estabilidade do Hydros Histórico diante de variações controladas nos pesos do AMDH, nos pesos do AIEC e nos limiares de inconclusão. A análise não procura a configuração com melhor resultado e não altera os parâmetros-base em função das métricas observadas.

## Desenho da sensibilidade

Foram avaliadas 25 configurações:

- 1 configuração-base;
- 6 perturbações dos pesos do AMDH, com variação relativa de -25% e +25% em cada um de `whc`, `warg` e `waps`, seguida de renormalização;
- 12 perturbações dos pesos do AIEC, com variação relativa de -25% e +25% em cada uma das seis evidências, seguida de renormalização;
- 6 variações pré-definidas dos limiares do AMDH: confiança crítica 0,30/0,40, conflito crítico 0,70/0,90 e completude mínima 0,60/0,80.

As evidências especializadas, Earg e Eaps foram calculadas uma única vez para cada uma das 256 observações. Em seguida apenas AIEC e/ou AMDH foram recalculados conforme o fator avaliado. Isso mantém constantes dados e modelos enquanto isola o fator de sensibilidade.

## Resultado principal

A configuração-base reproduziu o estado da Entrega 5: 167 processamentos conclusivos em 256 observações, taxa conclusiva 0,652344 e ausência de detecção dos 11 eventos de intensificação da referência.

A sensibilidade aos pesos foi baixa:

- pesos AMDH: estabilidade das saídas entre 0,984375 e 0,996094 em relação à base;
- pesos AIEC: estabilidade entre 0,988281 e 1,000000;
- nenhuma perturbação de peso passou a detectar os eventos de intensificação.

A maior sensibilidade ocorreu no limiar de confiança global:

- confiança crítica 0,30: taxa conclusiva 1,000000 e 89 saídas diferentes da base;
- confiança crítica 0,40: taxa conclusiva 0,417969 e 60 saídas diferentes da base.

Os limiares de conflito e completude avaliados não alteraram as saídas nesta base.

## Interpretação

O problema atual de não detectar eventos de `iniciar_irrigacao` não é resolvido por pequenas variações dos pesos do AIEC ou AMDH. O comportamento é muito mais sensível ao critério de confiança usado para declarar o processamento conclusivo. Como o APS permanece provisório e classifica os cenários atuais de forma pouco discriminante, não foi realizada calibração oportunista dos pesos ou limiares.

## Artefatos

- `run_sensibilidade.py`
- `test_hydros_sensitivity.py`
- `results/modulo_6_sensibilidade/resumo_sensibilidade.csv`
- `results/modulo_6_sensibilidade/detalhes_sensibilidade.csv`
- `results/modulo_6_sensibilidade/sintese_por_grupo.csv`

## Decisão

Os pesos-base permanecem inalterados. Este módulo fornece análise de robustez e não uma seleção de hiperparâmetros.
