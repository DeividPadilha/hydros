# HYDROS-EXP02B V4.2 - Correção do formato de irrigação DSSAT

Data: 2026-08-14

## Problema confirmado
O diagnóstico isolado mostrou que eventos solicitados como 10 ou 11 mm eram registrados pelo DSSAT como apenas 1 mm.

A causa estava no escritor de eventos `.SBX`: a linha gerada deslocava os campos de nível, data e operação em uma coluna em relação ao formato de largura fixa usado pelo DSSAT.

Formato incorreto anterior:

```text
 1 78240 IR001     11
```

Formato corrigido:

```text
  1 78240 IR001    11
```

## Alteração realizada
Arquivo:

`src/evaluation/dssat_sbx_schedule.py`

A geração dos eventos passou a usar:

```python
f"{int(level):3d} {event.date_code:05d} {event.operation:<5s}{_format_amount(event.amount_mm):>6s}"
```

Nenhum peso, limiar, regra, APS ou agente do Hydros foi alterado.

## Testes adicionados
Foram adicionados testes de regressão que verificam:

1. posições exatas dos campos na linha DSSAT;
2. preservação de valores de dois dígitos, como 10 e 11 mm;
3. round-trip pelo parser do Hydros.

## Resultado da suíte

`48 passed`

## Próxima execução
Executar o ciclo fechado de desenvolvimento com UFGA7801 e UFGA8401:

```powershell
python run_closed_loop_desenvolvimento_exp02b_v4.py --dssat-root "C:\DSSAT48"
```

O holdout UFGA8501 permanece bloqueado nesta etapa.
