# HYDROS-EXP02B V4.3 - Correção do layout de eventos DSSAT

## Causa confirmada
A V4.1 gerava 21 caracteres porque havia um espaço extra entre `IROP` e `IRVAL`. O DSSAT executava, mas 10/11 mm eram interpretados como 1 mm.

A V4.2 tentou deslocar o nível para três colunas e continuou com 21 caracteres. Isso tornou o arquivo candidato inválido e o DSSAT retornou código 99.

O layout observado no arquivo oficial é de 20 caracteres, por exemplo:

```text
 1 85172 IR001    13
```

A V4.3 passa a gerar exatamente esse contrato posicional:

* nível: colunas 1-2;
* IDATE: colunas 4-8;
* IROP: colunas 10-14;
* IRVAL: colunas 15-20.

Nenhum peso, limiar, regra, APS ou agente Hydros foi alterado.
