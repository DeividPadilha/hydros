# Protocolo de reprodutibilidade do Hydros

## 1. Ambiente

```powershell
python -m venv .venv-1
.\.venv-1\Scripts\Activate.ps1
pip install -r requirements.txt
```

As versões testadas dos pacotes são registradas automaticamente no relatório de validação.

## 2. Validação integral recomendada

```powershell
python run_hydros_validation.py
```

Por padrão, o script executa os 24 testes atuais, valida os artefatos já produzidos e registra ambiente e hashes SHA-256. Essa modalidade evita sobrescrever resultados apenas para verificar uma release.

Para regenerar os experimentos antes da validação, use:

```powershell
python run_hydros_validation.py --reproduce-experiments
```

A reprodução completa executa novamente Experimento I, diagnóstico, sensibilidade e Experimento II antes dos testes. Ela é significativamente mais demorada.

Saídas:

```text
results/validation/hydros_validation_report.json
results/validation/hydros_validation_report.md
```

## 3. Execuções individuais

### Experimento I

```powershell
python run_experimento_1.py
python diagnostico_resultados.py
python test_hydros_article_outputs.py
```

### Sensibilidade

```powershell
python run_sensibilidade.py
python test_hydros_sensitivity.py
```

### Experimento II

```powershell
python run_experimento_2.py
python test_hydros_experiment2.py
```

## 4. Regra de preservação

Resultados de versões diferentes não devem ser combinados. Antes de uma nova rodada experimental, preserve o ZIP da entrega anterior e o diretório de resultados correspondente.

Os diretórios `results/legacy/` mantêm snapshots de etapas anteriores. O arquivo `PRESERVACAO_BASE_MODULO_8_9.json` registra hashes do ponto de partida usado para a validação final desta entrega.

## 5. Interpretação

`overall_status=ok` no relatório significa que o software, os testes e os artefatos reproduzíveis foram validados. Isso não significa validação agronômica definitiva.

O campo `scientific_summary.status` permanece `provisorio` enquanto APS e experimentos não tiverem cobertura científica suficiente.

## 6. Congelamento

Após a validação:

```powershell
python freeze_hydros_release.py
```

O script gera em `releases/`:

```text
hydros_<versao>_<timestamp>.zip
hydros_<versao>_<timestamp>.sha256
```

O ZIP contém manifesto com hashes dos arquivos incluídos.


## 7. Contrato de tempo térmico

A variável `gd` do modelo corresponde a `soma_termica_acumulada`. Para compatibilidade, arquivos antigos com `graus_dia` são tratados como incremento do período, materializado em `graus_dia_periodo`, e a soma acumulada é calculada cronologicamente por trajetória. O teste `test_hydros_thermal_time.py` verifica esse contrato.
