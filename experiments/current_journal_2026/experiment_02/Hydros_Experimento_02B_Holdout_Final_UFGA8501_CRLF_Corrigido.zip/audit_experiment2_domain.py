"""Auditoria independente de compatibilidade de domínio do Experimento II.

Este script NÃO altera agentes, pesos, limiares, modelo APS ou dados de entrada.
Ele compara o domínio do CSV DSSAT com o domínio registrado no APS e produz
artefatos para decidir quais conversões precisam ser explicitadas antes de uma
nova simulação contrafactual.
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from src.evaluation.dssat_hydros_mapping import (
    IBSB910015,
    add_experiment2b_water_audit_columns,
    phenology_mapping_status,
    productivity_semantics_status,
    required_dssat_outputs_for_closed_loop,
)

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "hydros_soja_dssat_real_v2.csv"
META = ROOT / "src" / "models" / "aps_model_metadata.json"
OUT = ROOT / "results" / "experimento_2b"

CATEGORICAL = ["cultura", "loc", "solo", "estagio_fenologico"]
NUMERIC_RAW_TO_APS = [
    "precipitacao", "temperatura", "evapotranspiracao",
    "coeficiente_cultura", "umidade_solo", "agua_disponivel",
    "irrigacao_aplicada", "produtividade",
]

# O perfil hidráulico oficial IBSB910015 e as transformações auxiliares
# ficam centralizados em src/evaluation/dssat_hydros_mapping.py.
# O script de auditoria apenas consome esse contrato e nunca altera o CSV.


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(DATA)
    meta = json.loads(META.read_text(encoding="utf-8"))

    soil_summary = IBSB910015.hydraulic_summary()
    soil_rows = []
    previous_cm = 0.0
    for layer in IBSB910015.layers:
        thickness_mm = (layer.bottom_cm - previous_cm) * 10.0
        soil_rows.append({
            "limite_inferior_cm": layer.bottom_cm,
            "espessura_mm": thickness_mm,
            "SLLL": layer.ll_vwc,
            "SDUL": layer.dul_vwc,
            "SSAT": layer.sat_vwc,
            "agua_LL_mm": thickness_mm * layer.ll_vwc,
            "agua_DUL_mm": thickness_mm * layer.dul_vwc,
            "agua_SAT_mm": thickness_mm * layer.sat_vwc,
            "PAWC_camada_mm": thickness_mm * (layer.dul_vwc - layer.ll_vwc),
        })
        previous_cm = layer.bottom_cm
    pd.DataFrame(soil_rows).to_csv(OUT / "perfil_solo_IBSB910015.csv", index=False)
    pawc_total = float(soil_summary["PAWC_LL_to_DUL_mm"])

    categorical_rows = []
    aps_cat = meta.get("categorical_domains", {})
    for col in CATEGORICAL:
        dssat_values = sorted(df[col].dropna().astype(str).unique().tolist())
        aps_values = sorted(map(str, aps_cat.get(col, [])))
        overlap = sorted(set(dssat_values) & set(aps_values))
        categorical_rows.append({
            "variavel": col,
            "valores_dssat": "|".join(dssat_values),
            "valores_aps": "|".join(aps_values),
            "intersecao": "|".join(overlap),
            "compativel_direto": bool(overlap) and set(dssat_values).issubset(set(aps_values)),
        })
    cat_df = pd.DataFrame(categorical_rows)
    cat_df.to_csv(OUT / "dominio_categorico.csv", index=False)

    aps_ranges = meta.get("numeric_ranges", {})
    numeric_rows = []
    for col in NUMERIC_RAW_TO_APS:
        if col not in df:
            continue
        raw_min = float(df[col].min())
        raw_max = float(df[col].max())
        # Reproduz a conversão atual do adaptador apenas para umidade volumétrica.
        hydros_min, hydros_max = raw_min, raw_max
        if col == "umidade_solo" and raw_max <= 1.5:
            hydros_min, hydros_max = raw_min * 100.0, raw_max * 100.0
        target = aps_ranges.get(col, {})
        aps_min = target.get("min")
        aps_max = target.get("max")
        outside = None
        if aps_min is not None and aps_max is not None:
            outside = hydros_min < float(aps_min) or hydros_max > float(aps_max)
        numeric_rows.append({
            "variavel": col,
            "dssat_min_bruto": raw_min,
            "dssat_max_bruto": raw_max,
            "faixa_pos_adaptador_min": hydros_min,
            "faixa_pos_adaptador_max": hydros_max,
            "aps_min": aps_min,
            "aps_max": aps_max,
            "possui_valores_fora_da_faixa_aps": outside,
        })
    num_df = pd.DataFrame(numeric_rows)
    num_df.to_csv(OUT / "dominio_numerico.csv", index=False)

    # Diagnósticos exploratórios, deliberadamente NÃO aplicados ao núcleo do Hydros.
    rainfed = df.loc[df["cenario"].astype(str) == "sem_irrigacao"].copy()
    stages = (
        rainfed.groupby("estagio_fenologico", sort=False)
        .agg(inicio=("data", "first"), fim=("data", "last"), n=("data", "size"))
        .reset_index()
    )
    stages.to_csv(OUT / "sequencia_fenologica_csv_atual.csv", index=False)

    bridge = add_experiment2b_water_audit_columns(rainfed)
    bridge_cols = [
        "data", "agua_disponivel", "umidade_solo",
        "dssat_agua_extraivel_mm_auditoria",
        "fracao_agua_extraivel_perfil_sem_corte",
        "fracao_agua_extraivel_perfil",
        "indice_umidade_compativel_exp1",
        "indice_umidade_compativel_exp1_semantica",
        "perfil_solo_hidraulico",
    ]
    bridge[bridge_cols].to_csv(OUT / "ponte_semantica_agua_auditoria.csv", index=False)

    # Evidência de consistência com SWXD, sem transformar inferência em certeza.
    # UFGA7901 inicia com o perfil configurado em DUL. Logo PAWC = 158.4 mm.
    # No primeiro registro não há precipitação nem irrigação, ET = 3.538 mm e
    # agua_disponivel = 155 mm: 158.4 - 3.538 = 154.862 mm, arredondando para 155.
    first = rainfed.iloc[0]
    swxd_expected_after_first_et = pawc_total - float(first["evapotranspiracao"])
    swxd_first_error_mm = float(first["agua_disponivel"]) - swxd_expected_after_first_et

    phenology_status = phenology_mapping_status(rainfed["estagio_fenologico"])
    productivity_status = productivity_semantics_status(rainfed["produtividade"])

    audit = {
        "input": str(DATA.relative_to(ROOT)),
        "aps_metadata": str(META.relative_to(ROOT)),
        "n_rows": int(len(df)),
        "n_scenarios": int(df[["cenario", "dssat_run"]].drop_duplicates().shape[0]),
        "aps_scientific_readiness": meta.get("scientific_readiness", {}),
        "categorical_mismatches": int((~cat_df["compativel_direto"]).sum()),
        "numeric_variables_with_out_of_range_values": int(
            num_df["possui_valores_fora_da_faixa_aps"].fillna(False).sum()
        ),
        "current_csv_ranges": {
            "umidade_solo_raw": [float(df.umidade_solo.min()), float(df.umidade_solo.max())],
            "umidade_solo_after_current_adapter_pct": [
                float(df.umidade_solo.min() * 100.0), float(df.umidade_solo.max() * 100.0)
            ],
            "agua_disponivel_mm": [float(df.agua_disponivel.min()), float(df.agua_disponivel.max())],
            "produtividade_kg_ha": [float(df.produtividade.min()), float(df.produtividade.max())],
        },
        "official_soil_profile_IBSB910015": {
            **soil_summary,
            "source": "DSSAT/dssat-csm-data Soil/SOIL.SOL",
        },
        "dssat_cde_semantics": {
            "SWTD": "Total soil water in profile (mm)",
            "SWXD": "Extractable water (mm)",
            "source": "DSSAT/dssat-csm-os Data/DATA.CDE",
            "current_csv_agua_disponivel_source_cde_recorded": False,
            "high_confidence_candidate": "SWXD",
            "confidence": "alta_por_consistencia_fisica_mas_ainda_sem_cabecalho_de_origem",
            "first_day_check": {
                "PAWC_initial_at_DUL_mm": pawc_total,
                "ET_first_day_mm": float(first["evapotranspiracao"]),
                "expected_extractable_after_ET_mm": round(swxd_expected_after_first_et, 6),
                "csv_agua_disponivel_mm": float(first["agua_disponivel"]),
                "difference_due_to_rounding_or_other_fluxes_mm": round(swxd_first_error_mm, 6),
            },
            "interpretation": (
                "A coluna é altamente consistente com SWXD. Valores acima de PAWC não são, por si só, inválidos, "
                "pois o perfil pode conter água transitoriamente acima de DUL. A proveniência exata deve ser "
                "confirmada pelo cabeçalho/arquivo de saída da nova execução."
            ),
        },
        "phenology_mapping": phenology_status,
        "productivity_semantics": productivity_status,
        "required_closed_loop_outputs": list(required_dssat_outputs_for_closed_loop()),
        "blocking_findings": [
            "A origem CDE da coluna agua_disponivel não está registrada no CSV atual, embora a série seja altamente consistente com SWXD.",
            "SWXD de perfil inteiro não deve ser confundido com disponibilidade efetivamente acessível na zona radicular sem RDPD e água por camada.",
            "Converter umidade volumétrica diretamente para porcentagem não a torna semanticamente equivalente ao índice de umidade usado no treinamento sintético do APS.",
            "O solo DSSAT IBSB910015 não pertence ao domínio categórico do APS atual (argiloso).",
            "Os estágios fenológicos do CSV atual não pertencem ao domínio V/R usado pelo APS, Afen e ARG.",
            "A sequência fenológica textual do CSV precisa ter sua origem rastreada antes de qualquer mapeamento para V/R.",
            "Produtividade diária no CSV atual é quase sempre zero e não é semanticamente equivalente à produtividade estimada contínua usada no APS sintético.",
        ],
        "safe_next_step": (
            "Não recalibrar pesos/limiares. Preservar dados brutos, exigir proveniência de cada variável DSSAT, "
            "usar a camada de tradução auditável por solo/variável, recuperar água por camada e profundidade radicular, "
            "e só então gerar a programação candidata antes da nova execução DSSAT."
        ),
    }
    (OUT / "auditoria_dominio.json").write_text(
        json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print("Auditoria de domínio concluída.")
    print(f"Linhas: {audit['n_rows']}")
    print(f"Incompatibilidades categóricas: {audit['categorical_mismatches']}")
    print(
        "Variáveis numéricas com faixa fora do APS: "
        f"{audit['numeric_variables_with_out_of_range_values']}"
    )
    print(f"PAWC LL-DUL do perfil oficial: {pawc_total:.1f} mm")
    print("Origem CDE de agua_disponivel: não registrada; candidato SWXD com alta consistência física")


if __name__ == "__main__":
    main()
