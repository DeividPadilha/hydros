# Módulo 8: validação final de software

Data: 13/08/2026

## Ponto de partida

O módulo foi iniciado a partir da Entrega 6/7. Antes de qualquer execução foi criado um snapshot dos resultados atuais em:

```text
results/legacy/modulo7_pre_validacao_final_20260813/
```

Também foi criado `PRESERVACAO_BASE_MODULO_8_9.json` com hashes dos principais resultados, do modelo APS e da HydrosOnto.

## Ajuste realizado no teste de cenários

O cenário de baixa criticidade já produzia `status_processamento=inconclusivo` por confiança global insuficiente. O teste antigo apenas imprimia `VERIFICAR` e ainda encerrava com código 0, o que permitia registrar um teste como aprovado sem validar o resultado.

O teste foi tornado estrito. O cenário agora verifica explicitamente:

- processamento `inconclusivo`;
- ausência de ação final;
- ação candidata `finalizar_irrigacao`;
- preservação do motivo `confianca_global_insuficiente`.

Nenhum peso, limiar ou regra do núcleo foi alterado para fazer o cenário passar. Os outros três cenários permanecem conclusivos e verificam `manter`, `iniciar` e `aumentar` conforme suas condições.

Resultado: **4/4 cenários funcionais aprovados**.

## Validação integral

`run_hydros_validation.py` foi ampliado para distinguir validação de software e prontidão científica.

A validação padrão não regenera os experimentos. Ela executa todos os testes e confere os artefatos atuais. Isso evita sobrescrever resultados apenas para validar uma release.

Resultado da rodada final:

- **21/21 testes aprovados**;
- artefatos obrigatórios: OK;
- HydrosOnto: OK;
- APS e metadata: OK;
- Experimento I: artefatos presentes e validados;
- análise de sensibilidade: artefatos presentes e validados;
- Experimento II: artefatos presentes e validados;
- prontidão de release: OK;
- **validação de software: OK**;
- **prontidão científica: PROVISÓRIA**.

A reprodução completa permanece disponível com:

```text
python run_hydros_validation.py --reproduce-experiments
```

Essa modalidade é mais demorada porque reexecuta o Hydros em todas as observações dos experimentos.

## Preservação dos resultados

Após a validação, os hashes dos seguintes artefatos continuaram idênticos ao ponto de partida:

- `results/experimento_1/metricas_resumo.csv`;
- `results/aps_modulo5/prontidao_cientifica.json`;
- `results/modulo_6_sensibilidade/resumo_sensibilidade.csv`;
- `results/experimento_2/metricas_experimento_2.csv`;
- `results/experimento_2/status_experimento_2.json`;
- `src/models/aps_random_forest_model.pkl`;
- `ontology/hydrosonto.owl`.

Portanto, a validação final não substituiu os resultados científicos preservados dos módulos anteriores.
