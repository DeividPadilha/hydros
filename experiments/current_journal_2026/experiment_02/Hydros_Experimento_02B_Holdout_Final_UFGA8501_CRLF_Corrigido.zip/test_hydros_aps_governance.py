"""Valida governança do APS fora do domínio no AMDH."""

from src.agents.amdh_agent import AMDHAgent
from src.core.irrigation_state import IrrigationState


def evidencia(nome: str, valor: str, confianca: float = 1.0) -> dict:
    return {
        nome: valor,
        "confianca": confianca,
        "completude": 1.0,
        "indice_conflito": 0.0,
    }


def main() -> None:
    amdh = AMDHAgent()
    estado_inativo = IrrigationState(
        active=False,
        state="inativa",
        source="teste_explicito",
        confidence=1.0,
        applied_mm=0.0,
        explicit=True,
    )

    # Caso 1: o APS está fora do domínio, mas sua retirada não altera a ação.
    resultado_estavel = amdh.decidir(
        evidencia("Earg", "critica"),
        evidencia("Ehc", "critica"),
        {
            **evidencia("Eaps", "adequada", confianca=0.05),
            "status_dominio": "fora_dominio",
            "fora_dominio": True,
            "avisos": ["categoria desconhecida"],
        },
        contexto_atual={"irrigacao_ativa": False},
        estado_irrigacao=estado_inativo,
    )

    dependencia_estavel = resultado_estavel["dependencia_aps"]
    assert resultado_estavel["D(Ui)"] == "iniciar_irrigacao"
    assert dependencia_estavel["decisao_sem_aps"] == "iniciar_irrigacao"
    assert dependencia_estavel["influencia_material"] is False
    assert resultado_estavel["status_processamento"] == "conclusivo"
    assert "aps_fora_ou_parcialmente_fora_do_dominio" in resultado_estavel[
        "avisos_governanca"
    ]

    # Caso 2: APS fora do domínio altera a ação no contrafactual.
    # O Hydros não transfere a escolha ao usuário. Ele encerra o processamento
    # como inconclusivo e não emite ação conclusiva.
    resultado_dependente = amdh.decidir(
        evidencia("Earg", "atencao", confianca=0.5),
        evidencia("Ehc", "atencao", confianca=0.5),
        {
            **evidencia("Eaps", "critica", confianca=1.0),
            "status_dominio": "fora_dominio",
            "fora_dominio": True,
            "avisos": ["categoria desconhecida"],
        },
        contexto_atual={"irrigacao_ativa": False},
        estado_irrigacao=estado_inativo,
    )

    dependencia_material = resultado_dependente["dependencia_aps"]
    assert dependencia_material["influencia_material"] is True
    assert resultado_dependente["status_processamento"] == "inconclusivo"
    assert resultado_dependente["D(Ui)"] is None
    assert "acao_dependente_de_aps_fora_do_dominio" in resultado_dependente[
        "motivos_inconclusao"
    ]
    assert resultado_dependente["revisao_humana_requerida"] is False

    # Caso 3: APS fora do domínio sem influência material gera apenas aviso.
    resultado_conservador = amdh.decidir(
        evidencia("Earg", "atencao", confianca=0.55),
        evidencia("Ehc", "atencao", confianca=0.55),
        {
            **evidencia("Eaps", "atencao", confianca=0.2),
            "status_dominio": "fora_dominio",
            "fora_dominio": True,
            "avisos": ["categoria desconhecida"],
        },
        contexto_atual={"irrigacao_ativa": False},
        estado_irrigacao=estado_inativo,
    )

    assert resultado_conservador["D(Ui)"] == "manter_irrigacao"
    assert resultado_conservador["status_processamento"] == "conclusivo"
    assert "aps_fora_ou_parcialmente_fora_do_dominio" in resultado_conservador[
        "avisos_governanca"
    ]

    print("\n=== GOVERNANÇA DO APS ===")
    print("Caso estável:", dependencia_estavel)
    print("Caso dependente:", dependencia_material)
    print("Caso conservador:", resultado_conservador["D(Ui)"])
    print("GOVERNANÇA DO APS: OK")


if __name__ == "__main__":
    main()
