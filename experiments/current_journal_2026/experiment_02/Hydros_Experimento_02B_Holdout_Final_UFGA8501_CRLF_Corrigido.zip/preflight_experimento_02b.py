"""Pré-validação do ambiente DSSAT para o Experimento II-B.

O script não executa o holdout e não altera parâmetros do Hydros. Ele apenas
confere se a instalação local tem os componentes mínimos para iniciar a etapa
de simulação controlada.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path

from src.evaluation.dssat_cli import DSSATCommandConfig, preflight_dssat_command
from src.evaluation.dssat_sbx_schedule import extract_irrigation_events


BASE_DIR = Path(__file__).resolve().parent
RESULT_DIR = BASE_DIR / "results" / "experimento_2b"
OFFICIAL_HOLDOUT = RESULT_DIR / "official_UFGA8501.SBX"
PREREG_V2 = RESULT_DIR / "pre_registro_experimento_02b_v2.json"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _find_executable(root: Path | None, explicit: Path | None) -> Path | None:
    if explicit:
        return explicit
    if root:
        candidates = [
            root / "dscsm048",
            root / "dscsm048.exe",
            root / "DSCSM048.EXE",
            root / "DSCSM048.exe",
            root / "bin" / "dscsm048",
            root / "bin" / "dscsm048.exe",
        ]
        for candidate in candidates:
            if candidate.is_file():
                return candidate
    return None


def audit_holdout_fixture() -> dict[str, object]:
    if not OFFICIAL_HOLDOUT.is_file():
        return {"ready": False, "problem": f"fixture ausente: {OFFICIAL_HOLDOUT}"}
    text = OFFICIAL_HOLDOUT.read_text(encoding="utf-8")
    ref = extract_irrigation_events(text, 1)
    base = extract_irrigation_events(text, 2)
    return {
        "ready": True,
        "sha256": sha256(OFFICIAL_HOLDOUT),
        "irrigation_level_1_events": len(ref),
        "irrigation_level_1_total_mm": round(sum(e.amount_mm for e in ref), 6),
        "irrigation_level_2_events": len(base),
        "irrigation_level_2_total_mm": round(sum(e.amount_mm for e in base), 6),
        "common_establishment_prefix": [
            {"date_code": e.date_code, "amount_mm": e.amount_mm}
            for e in base
            if any(
                r.date_code == e.date_code and abs(r.amount_mm - e.amount_mm) <= 1e-9
                for r in ref
            )
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dssat-root", type=Path, default=os.environ.get("DSSAT_HOME"))
    parser.add_argument("--exe", type=Path, default=os.environ.get("DSSAT_EXECUTABLE"))
    parser.add_argument("--experiment", type=Path, default=None)
    parser.add_argument("--treatment", type=int, default=2)
    args = parser.parse_args()

    root = Path(args.dssat_root).resolve() if args.dssat_root else None
    explicit_exe = Path(args.exe).resolve() if args.exe else None
    executable = _find_executable(root, explicit_exe)

    problems: list[str] = []
    checks: dict[str, object] = {
        "holdout_fixture": audit_holdout_fixture(),
        "preregistration_v2_present": PREREG_V2.is_file(),
    }

    if not checks["holdout_fixture"]["ready"]:
        problems.append(checks["holdout_fixture"]["problem"])
    if not PREREG_V2.is_file():
        problems.append(f"pré-registro v2 ausente: {PREREG_V2}")

    if root is None:
        problems.append("DSSAT_HOME não informado")
    elif not root.is_dir():
        problems.append(f"DSSAT_HOME inexistente: {root}")
    else:
        checks["dssat_root"] = str(root)
        checks["data_cde"] = (root / "Data.CDE").is_file()
        checks["dssatpro_v48"] = (root / "DSSATPRO.v48").is_file() or (root / "DSSATPRO.L48").is_file()
        if not checks["data_cde"]:
            problems.append("Data.CDE não encontrado na raiz DSSAT")
        if not checks["dssatpro_v48"]:
            problems.append("DSSATPRO.v48/DSSATPRO.L48 não encontrado na raiz DSSAT")

    if executable is None:
        problems.append("executável dscsm048/DSCSM048 não encontrado")
    else:
        checks["executable"] = str(executable)

    experiment = Path(args.experiment).resolve() if args.experiment else None
    if experiment is not None and executable is not None:
        command_check = preflight_dssat_command(
            DSSATCommandConfig(
                executable=executable,
                experiment_file=experiment,
                treatment=args.treatment,
            )
        )
        checks["command_mode_c"] = command_check
        if not command_check["ready"]:
            problems.extend(command_check["problems"])
    else:
        checks["command_mode_c"] = {
            "ready": False,
            "reason": "informe --experiment para validar a chamada exata do tratamento",
        }

    result = {
        "experiment": "HYDROS-EXP02B",
        "ready_for_real_dssat_execution": not problems,
        "problems": problems,
        "checks": checks,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ready_for_real_dssat_execution"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
