"""Valida o contrato canônico de treinamento do APS após o Módulo 5."""

from pathlib import Path
import json

from src.agents.aps_agent import APSAgent


ROOT = Path(__file__).resolve().parent


def main() -> None:
    metadata_path = ROOT / "src" / "models" / "aps_model_metadata.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))

    assert metadata["target_schema"] == ["adequada", "atencao", "critica"]
    assert set(metadata["target_distribution"]) == {"adequada", "atencao", "critica"}
    assert metadata["training_split"] == "divisao_cronologica_por_trajetoria_60_20_20"
    assert metadata["scientific_readiness"]["ready"] is False
    assert "menos_de_tres_trajetorias_independentes" in metadata["scientific_readiness"]["reasons"]
    assert metadata["scientific_status"] == "modelo_tres_classes_provisorio_requer_cenarios_independentes"

    aps = APSAgent(algoritmo="random_forest")
    assert list(aps.label_encoder.classes_) == ["adequada", "atencao", "critica"]
    assert aps.target_schema == ["adequada", "atencao", "critica"]
    assert aps.modelo_cientificamente_apto is False

    print("APS 3 CLASSES + GOVERNANCA CIENTIFICA: OK")


if __name__ == "__main__":
    main()
