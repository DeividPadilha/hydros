# Hydros 0.4.1 - Fechamento técnico para qualificação

Data: 13/08/2026
Versão: `0.4.1-qualificacao-final`
Base preservada: `hydros_0_4_1_checkpointC.zip`
SHA-256 da base: `d851912d12dbd77089e5d30986a0c8143a5df82edee5baff715bf818dea7ff55`

## Critério de fechamento

Esta versão foi fechada com um único objetivo: implementar e verificar o que está previsto no modelo e no Capítulo 6 da tese, sem adicionar novas funcionalidades científicas e sem ajustar pesos, regras ou limiares para melhorar resultados experimentais.

## Ajustes finais realizados

1. A execução passou a registrar explicitamente `property_id`, mantendo também a unidade de manejo.
2. O motor aceita `propriedade_id` como parâmetro opcional ou recupera a identificação de uma coluna de entrada quando ela existir.
3. O motor rejeita uma única execução que misture contextos de unidades de manejo diferentes.
4. O registro de rastreabilidade passou a armazenar `processing_time_ms`.
5. Propriedade e tempo de processamento também são persistidos no SQLite e expostos pelo adaptador da interface.
6. Foi criado `test_hydros_thesis_contract.py` para verificar de forma integrada os 13 itens funcionais previstos para o protótipo no Capítulo 6.
7. A versão de arquitetura foi congelada como `0.4.1-qualificacao-final`.

Nenhum peso, regra agronômica, limiar, modelo APS, ontologia, dataset ou política experimental foi alterado nesta etapa.

## Checklist tese x implementação

| # | Requisito funcional | Implementação principal | Verificação |
|---|---|---|---|
| 1 | Importação e validação dos dados | `src/services/data_loader.py`, `src/services/validator.py` | testes de interface/fluxo e validações existentes |
| 2 | Associação a propriedade e unidade de manejo | `src/services/hydros_engine.py`, `src/core/contracts.py` | `test_hydros_thesis_contract.py` |
| 3 | Contextos e históricos | `src/services/hydros_engine.py` | `test_hydros_history_window.py`, `test_hydros_modes.py` |
| 4 | Atributos atuais e históricos | `src/services/feature_extractor.py`, `src/core/thermal_time.py` | `test_hydros_thermal_time.py`, testes APS |
| 5 | Aclim, Ahid, Afen, Ageo, Aprod, Ahist | `src/agents/` | `test_hydros_model_flow.py`, cenários |
| 6 | Integração pelo AIEC | `src/agents/aiec_agent.py` | testes de fluxo, evidência e confiança |
| 7 | Regras pelo ARG | `src/agents/arg_agent.py` | cenários e testes de escores |
| 8 | Modelo supervisionado pelo APS | `src/agents/aps_agent.py`, `src/models/` | testes APS e governança |
| 9 | Consulta à HydrosOnto | `src/ontology/hydros_onto.py`, `ontology/hydrosonto.owl` | `test_hydros_ontology.py` |
| 10 | Integração pelo AMDH | `src/agents/amdh_agent.py` | `test_hydros_model_flow.py`, `test_hydros_action_scores.py` |
| 11 | Consistência e conflitos | `src/agents/amdh_agent.py`, contratos | testes de cenários, confiança e rastreabilidade |
| 12 | Ação de manejo | AMDH | 4 cenários funcionais e testes de fluxo |
| 13 | Explicação e registro completo | `src/core/contracts.py`, `src/database/database.py` | `test_hydros_traceability.py`, persistência e teste da tese |

## Verificação funcional final

A compilação Python foi executada sem erro.

Na validação integral executada após os ajustes, os testes 1 a 19 passaram. O teste de prontidão inicialmente falhou apenas porque ainda esperava o nome da versão anterior. Esse contrato de versão foi atualizado para `0.4.1-qualificacao-final` e o teste passou em nova execução. Os testes finais de sensibilidade, tempo térmico, contrato da tese e rastreabilidade também passaram. Os testes essenciais do fluxo foram executados novamente após a correção da versão e passaram.

Verificações finais repetidas:

- fluxo completo: OK;
- Histórico e sem Histórico: OK;
- HydrosOnto: OK e fora do score do AMDH;
- persistência: OK;
- interface desacoplada: OK;
- quatro cenários funcionais: 4/4;
- prontidão de release de software: OK;
- contrato dos 13 itens da tese: OK;
- rastreabilidade: OK.

A interface Streamlit não foi aberta visualmente neste ambiente porque o pacote `streamlit` não está instalado. O arquivo `app.py` compila e os testes do adaptador/interface passam.

## Experimento I reexecutado

Foram processadas 256 observações pareadas em duas execuções DSSAT.

| Métrica | Hydros Histórico | Hydros sem Histórico |
|---|---:|---:|
| Conclusivas | 254/256 | 255/256 |
| Taxa conclusiva | 0,9922 | 0,9961 |
| Acurácia | 0,9492 | 0,9531 |
| F1 macro | 0,1948 | 0,1952 |
| Confiança média | 0,6816 | 0,5841 |

Houve somente 1 saída diferente entre os modos em 256 observações. Nenhum dos dois modos identificou os 11 eventos de referência de `iniciar_irrigacao`. Esse resultado foi preservado, sem ajuste de parâmetros para favorecimento do Hydros.

## Experimento II reexecutado

| Métrica | Hydros Histórico | Manejo de referência |
|---|---:|---:|
| Água de irrigação | 0 mm | 85 mm |
| Produtividade final | 3061 kg/ha | 3114 kg/ha |
| Períodos com estresse | 17 | 2 |
| Intensidade acumulada de estresse | 4,285 | 0,204 |

O resultado permanece não favorável ao Hydros segundo o critério já implementado. O experimento continua identificado no próprio software como resultado controlado de uma única trajetória pareada e não generalizável.

## Preservação dos resultados

Foi calculado um manifesto SHA-256 para todos os arquivos existentes em `data/`, `src/models/`, `ontology/` e `results/` antes dos ajustes finais. Após as alterações, a reexecução do Experimento I, o diagnóstico e o Experimento II, a comparação retornou:

`BASELINE_SCIENTIFIC_CHANGED = 0`

Portanto, os ajustes finais de propriedade, unidade e tempo de processamento não alteraram os datasets, modelos, ontologia ou resultados científicos do Checkpoint C.

## Estado final

O protótipo está tecnicamente fechado para o estágio de qualificação. As limitações científicas já registradas continuam válidas, especialmente a base ainda provisória do APS, o número reduzido de trajetórias DSSAT e o caráter preliminar do Experimento II. Essas limitações não são tratadas como bugs de software e não foram usadas como justificativa para novas alterações no núcleo.
