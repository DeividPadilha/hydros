import pandas as pd

from src.evaluation.dssat_hydros_mapping import (
    IBSB910015,
    add_experiment2b_water_audit_columns,
    derive_water_status_bridge,
    map_soil_to_broad_texture,
    phenology_mapping_status,
    productivity_semantics_status,
)


def test_ibsb910015_hydraulic_summary():
    s = IBSB910015.hydraulic_summary()
    assert s["profile_depth_mm"] == 1800.0
    assert abs(s["LL_total_mm"] - 55.2) < 1e-9
    assert abs(s["DUL_total_mm"] - 213.6) < 1e-9
    assert abs(s["PAWC_LL_to_DUL_mm"] - 158.4) < 1e-9


def test_water_bridge_preserves_physical_value_and_names_index_separately():
    b = derive_water_status_bridge(155.0)
    assert b.extractable_water_mm == 155.0
    assert 0.97 < b.relative_extractable_water_unbounded < 0.99
    assert 89.0 < b.synthetic_moisture_compatibility_index < 92.0

    wet = derive_water_status_bridge(193.0)
    assert wet.relative_extractable_water_unbounded > 1.0
    assert wet.relative_extractable_water_clipped == 1.0
    assert wet.synthetic_moisture_compatibility_index == 92.0


def test_add_columns_does_not_overwrite_original_water_or_moisture():
    df = pd.DataFrame({"agua_disponivel": [155.0, 193.0], "umidade_solo": [0.10, 0.141]})
    out = add_experiment2b_water_audit_columns(df)
    assert out["agua_disponivel"].tolist() == [155.0, 193.0]
    assert out["umidade_solo"].tolist() == [0.10, 0.141]
    assert "indice_umidade_compativel_exp1" in out.columns


def test_explicit_soil_mapping_only():
    texture, source = map_soil_to_broad_texture("IBSB910015")
    assert texture == "arenoso"
    assert "IBSB910015" in source
    texture2, _ = map_soil_to_broad_texture("UNKNOWN")
    assert texture2 is None


def test_unverified_phenology_is_blocked():
    status = phenology_mapping_status(["germinacao", "vegetativo", "emergencia"])
    assert status["safe_to_map_current_csv"] is False
    assert "vegetativo" in status["unverified_categories"]


def test_terminal_yield_is_not_daily_aprod_signal():
    status = productivity_semantics_status(pd.Series([0, 0, 0, 0, 3114]))
    assert status["safe_for_daily_aprod"] is False
    assert status["terminal_only_pattern"] is True
