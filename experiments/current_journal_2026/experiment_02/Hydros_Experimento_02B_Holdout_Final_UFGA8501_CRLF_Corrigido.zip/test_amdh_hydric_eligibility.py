from src.agents.amdh_agent import AMDHAgent
from src.core.irrigation_state import IrrigationState


def state(active: bool):
    return IrrigationState(
        active=active,
        state="ativa" if active else "inativa",
        source="teste",
        confidence=1.0,
        applied_mm=10.0 if active else 0.0,
        explicit=True,
    )


def calculate(ehc="atencao", earg="atencao", eaps="atencao", ehid=None):
    agent = AMDHAgent()
    result = agent.calcular_escores_acoes(
        ehc=ehc,
        earg=earg,
        eaps=eaps,
        ehid=ehid,
        indice_conflito=0.0,
        estado=state(False),
        pesos_efetivos={"Ehc": 0.4, "Earg": 0.3, "Eaps": 0.3},
    )
    return agent, result


def test_inativa_ehid_adequada_bloqueia_inicio_mesmo_com_atencao_generica():
    agent, result = calculate(ehid="adequada")
    assert "iniciar_irrigacao" not in result["escores_validos"]
    assert agent.selecionar_acao(result["escores_validos"]) == "manter_irrigacao"


def test_inativa_ehid_atencao_permite_comparar_manter_e_iniciar():
    _, result = calculate(ehid="atencao")
    assert {"manter_irrigacao", "iniciar_irrigacao"}.issubset(result["escores_validos"])


def test_inativa_ehid_critica_nao_permite_permanecer_desligada():
    agent, result = calculate(ehc="critica", earg="critica", eaps="critica", ehid="critica")
    assert "manter_irrigacao" not in result["escores_validos"]
    assert agent.selecionar_acao(result["escores_validos"]) == "iniciar_irrigacao"


def test_sem_ehid_preserva_compatibilidade_legada():
    _, result = calculate(ehid=None)
    assert "manter_irrigacao" in result["escores_validos"]
    assert "iniciar_irrigacao" in result["escores_validos"]
