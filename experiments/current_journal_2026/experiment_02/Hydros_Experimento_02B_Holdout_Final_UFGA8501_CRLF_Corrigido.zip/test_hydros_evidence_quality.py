"""Teste de completude, confiança e exclusão de evidências desativadas."""

from __future__ import annotations

import pandas as pd
from src.services.hydros_engine import HydrosEngine


def main() -> None:
    df = pd.read_csv("data/historico_contexto_exemplo.csv")
    engine = HydrosEngine()

    historical = engine.processar(df, modo_execucao="historico")
    without_history = engine.processar(df, modo_execucao="sem_historico")

    assert historical["aclim"]["completude"] == 1.0
    assert historical["aclim"]["confianca_dados"] > 0.0
    assert historical["aclim"]["confianca"] == historical["aclim"]["confianca_dados"]
    assert "confianca_criticidade_legada" in historical["aclim"]
    assert historical["aclim"]["qualidade_dados"] > 0.0
    assert "Ehist" in historical["aiec"]["evidencias_ativas"]

    assert without_history["ahist"]["desativado"] is True
    assert without_history["ahist"]["qualidade"] == 0.0
    assert "Ehist" not in without_history["aiec"]["evidencias_ativas"]
    assert "Ehist" in without_history["aiec"]["evidencias_desativadas"]

    incomplete_df = df.copy()
    incomplete_df.loc[incomplete_df.index[-1], "loc"] = ""
    incomplete = engine.processar(incomplete_df, modo_execucao="historico")

    assert incomplete["ageo"]["completude"] == 0.5
    assert "loc" in incomplete["ageo"]["variaveis_ausentes"]
    assert incomplete["aiec"]["completude"] < 1.0

    print("\n=== QUALIDADE DAS EVIDÊNCIAS ===")
    print("Ageo completo:", historical["ageo"]["completude"])
    print("Ageo incompleto:", incomplete["ageo"]["completude"])
    print("Confiança dos dados histórica Aclim:", historical["aclim"]["confianca_dados"])
    print("Confiança dos dados sem histórico Aclim:", without_history["aclim"]["confianca_dados"])
    print("Evidências ativas no sem histórico:", without_history["aiec"]["evidencias_ativas"])
    print("Evidências desativadas:", without_history["aiec"]["evidencias_desativadas"])
    print("QUALIDADE DAS EVIDÊNCIAS: OK")


if __name__ == "__main__":
    main()
