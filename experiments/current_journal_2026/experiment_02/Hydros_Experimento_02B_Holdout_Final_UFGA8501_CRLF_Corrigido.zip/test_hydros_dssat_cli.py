from pathlib import Path

import pytest

from src.evaluation.dssat_cli import (
    DSSATCommandConfig,
    DSSATPreflightError,
    build_dssat_command,
    preflight_dssat_command,
)


def test_command_mode_c_matches_official_argument_contract(tmp_path: Path):
    exe = tmp_path / "DSCSM048"
    exe.write_text("", encoding="utf-8")
    exp = tmp_path / "UFGA8501.SBX"
    exp.write_text("*EXP.DETAILS", encoding="utf-8")
    cfg = DSSATCommandConfig(executable=exe, experiment_file=exp, treatment=2)
    command = build_dssat_command(cfg)
    assert command[1:] == ["C", "UFGA8501.SBX", "2"]
    assert preflight_dssat_command(cfg)["ready"] is True


def test_preflight_blocks_missing_executable(tmp_path: Path):
    exp = tmp_path / "UFGA8501.SBX"
    exp.write_text("*EXP.DETAILS", encoding="utf-8")
    cfg = DSSATCommandConfig(
        executable=tmp_path / "missing_csm",
        experiment_file=exp,
        treatment=2,
    )
    result = preflight_dssat_command(cfg)
    assert result["ready"] is False
    assert any("executável ausente" in p for p in result["problems"])


def test_reject_nonstandard_long_experiment_filename(tmp_path: Path):
    cfg = DSSATCommandConfig(
        executable=tmp_path / "DSCSM048",
        experiment_file=tmp_path / "nome_experimental_muito_longo.SBX",
        treatment=1,
    )
    with pytest.raises(DSSATPreflightError):
        build_dssat_command(cfg)
