from pathlib import Path

import pytest

from src.evaluation.dssat_sbx_schedule import (
    IrrigationEvent,
    extract_irrigation_events,
    replace_irrigation_events,
)


FIXTURE = Path("results/experimento_2b/official_UFGA8501.SBX")


def test_extract_official_holdout_irrigation_levels():
    text = FIXTURE.read_text(encoding="utf-8")
    irrigated = extract_irrigation_events(text, 1)
    non_irrigated = extract_irrigation_events(text, 2)
    assert len(irrigated) == 16
    assert sum(e.amount_mm for e in irrigated) == pytest.approx(217.0)
    assert [(e.date_code, e.amount_mm) for e in non_irrigated] == [
        (85172, 13.0),
        (85175, 10.0),
    ]


def test_replace_only_target_level_and_preserve_reference():
    text = FIXTURE.read_text(encoding="utf-8")
    reference_before = extract_irrigation_events(text, 1)
    updated = replace_irrigation_events(
        text,
        level=2,
        events=[
            IrrigationEvent(85172, 13.0),
            IrrigationEvent(85175, 10.0),
            IrrigationEvent(85220, 7.5),
        ],
    )
    assert extract_irrigation_events(updated, 1) == reference_before
    assert [(e.date_code, e.amount_mm) for e in extract_irrigation_events(updated, 2)] == [
        (85172, 13.0),
        (85175, 10.0),
        (85220, 7.5),
    ]


def test_reject_duplicate_date():
    text = FIXTURE.read_text(encoding="utf-8")
    with pytest.raises(ValueError):
        replace_irrigation_events(
            text,
            level=2,
            events=[(85172, 10.0), (85172, 5.0)],
        )


def test_replace_uses_dssat_fixed_width_event_columns():
    """Evita regressão em que 10/11 mm eram interpretados pelo DSSAT como 1 mm."""
    text = FIXTURE.read_text(encoding="utf-8")
    updated = replace_irrigation_events(
        text,
        level=1,
        events=[IrrigationEvent(85240, 11.0)],
    )
    event_line = next(line for line in updated.splitlines() if "85240" in line)
    assert event_line == " 1 85240 IR001    11"
    # Contrato posicional do formato DSSAT: nível em 1-3, data em 5-9,
    # operação em 11-15 e valor em 16-21 (índices humanos, 1-based).
    assert len(event_line) == 20
    assert event_line[0:2] == " 1"
    assert event_line[3:8] == "85240"
    assert event_line[9:14] == "IR001"
    assert event_line[14:20] == "    11"


def test_replace_fixed_width_roundtrip_preserves_two_digit_amount():
    text = FIXTURE.read_text(encoding="utf-8")
    updated = replace_irrigation_events(
        text,
        level=1,
        events=[IrrigationEvent(85240, 11.0), IrrigationEvent(85241, 10.0)],
    )
    recovered = extract_irrigation_events(updated, 1)
    assert [(e.date_code, e.amount_mm) for e in recovered] == [
        (85240, 11.0),
        (85241, 10.0),
    ]


def test_replace_matches_official_dssat_event_layout_exactly():
    text = FIXTURE.read_text(encoding="utf-8")
    updated = replace_irrigation_events(
        text, level=1, events=[IrrigationEvent(85172, 13.0)]
    )
    line = next(line for line in updated.splitlines() if "85172" in line and "IR001" in line)
    assert line == " 1 85172 IR001    13"
    assert len(line) == 20


def test_extract_ignores_commented_irrigation_rows():
    """Linhas DSSAT iniciadas por ! são comentários, não eventos ativos."""
    text = FIXTURE.read_text(encoding="utf-8")
    active_line = next(
        line for line in text.splitlines()
        if line.strip().startswith("1 ") and "IR001" in line
    )
    commented = "!" + active_line
    # Insere uma cópia comentada no mesmo bloco; a contagem ativa não muda.
    updated = text.replace(active_line, active_line + "\n" + commented, 1)
    before = extract_irrigation_events(text, 1)
    after = extract_irrigation_events(updated, 1)
    assert after == before
