from pathlib import Path

import pandas as pd

from src.agents.aclim_agent import AclimAgent
from src.agents.ahid_agent import AhidAgent
from src.agents.afen_agent import AfenAgent
from src.agents.aiec_agent import AIECAgent
from src.agents.aprod_agent import AprodAgent
from src.agents.ahist_agent import AhistAgent
from src.agents.arg_agent import ARGAgent
from src.config.hydros_terms import LIMIARES_AGENTES, PESOS_REGRAS_ARG


def main() -> None:
    # Todos os módulos que ainda usam limiares operacionais devem apontar para
    # a configuração centralizada, sem redefinir os valores em construtores.
    assert set(LIMIARES_AGENTES) == {
        "Aclim", "Ahid", "Afen", "Aprod", "Ahist", "AIEC", "ARG"
    }

    assert AclimAgent().limiares == LIMIARES_AGENTES["Aclim"]
    assert AhidAgent().limiares == LIMIARES_AGENTES["Ahid"]
    assert AfenAgent().limiares == LIMIARES_AGENTES["Afen"]
    assert AprodAgent().limiares == LIMIARES_AGENTES["Aprod"]
    assert AhistAgent().limiares == LIMIARES_AGENTES["Ahist"]
    assert AIECAgent().limiares == LIMIARES_AGENTES["AIEC"]
    assert ARGAgent().limiares == LIMIARES_AGENTES["ARG"]
    assert ARGAgent().pesos_regras == {
        key.removeprefix("w"): value for key, value in PESOS_REGRAS_ARG.items()
    }

    # Sanidade funcional com o mesmo exemplo usado na release anterior.
    dataframe = pd.read_csv("data/historico_contexto_exemplo.csv")
    assert AclimAgent().analisar(dataframe)["Eclim"] in {"adequada", "atencao", "critica"}
    assert AhidAgent().analisar(dataframe)["Ehid"] in {"adequada", "atencao", "critica"}
    assert AfenAgent().analisar(dataframe)["Efen"] in {"adequada", "atencao", "critica"}
    assert AprodAgent().analisar(dataframe)["Eprod"] in {"adequada", "atencao", "critica"}
    assert AhistAgent().analisar(dataframe)["Ehist"] in {"adequada", "atencao", "critica"}
    assert ARGAgent().avaliar(dataframe)["Earg"] in {"adequada", "atencao", "critica"}

    app_text = Path("app.py").read_text(encoding="utf-8")
    history_section = app_text.split('"Execuções persistidas no banco"', 1)[1]
    assert '"Ação determinada"' in history_section
    assert '"Status"' in history_section
    assert '"Decisão original"' not in history_section
    assert '"Decisão final"' not in history_section
    assert '"Avaliação humana"' not in history_section

    print("CHECKPOINT A: OK")


if __name__ == "__main__":
    main()
