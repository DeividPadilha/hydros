"""Teste da persistência completa da ação e da rastreabilidade do Hydros."""

from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory

import pandas as pd

from src.database.database import Database
from src.services.hydros_engine import HydrosEngine


def main() -> None:
    data_path = Path("data/historico_contexto_exemplo.csv")
    if not data_path.exists():
        raise FileNotFoundError(data_path)

    dataframe = pd.read_csv(data_path)
    result = HydrosEngine(modo_execucao="historico").processar(dataframe)
    trace = result["registro_execucao"]

    with TemporaryDirectory() as temp_dir:
        database_path = Path(temp_dir) / "hydros_test.db"
        database = Database(str(database_path))

        execution_id = database.salvar_registro_execucao(trace)
        stored = database.buscar_execucao(execution_id)

        assert database.quantidade_execucoes() == 1
        assert stored["execution_id"] == trace["execution_id"]
        assert stored["modo_execucao"] == "historico"
        assert stored["unit_id"] == trace["unit_id"]
        assert stored["decisao_original"] == trace["decision"]["action"]
        assert stored["decisao_final"] == trace["decision"]["action"]
        assert stored["status_usuario"] == "nao_aplicavel"
        assert stored["status_processamento"] == trace["decision"]["processing_status"]
        assert stored["registro_execucao"]["agents_executed"][-1] == "AMDH"
        assert len(stored["registro_execucao"]["evidences"]) == 9
        assert stored["algoritmo_aps"] == trace["predictive_result"]["algorithm"]
        assert stored["verificacao_semantica"]["affects_amdh_score"] is False
        assert stored["rastreabilidade_semantica"]["ontology"] == "HydrosOnto"

        detailed = database.listar_execucoes_detalhadas(limite=10)
        legacy = database.listar_execucoes()
        assert len(detailed) == 1
        assert len(legacy) == 1
        assert len(legacy[0]) == 6

        print("\n=== PERSISTÊNCIA RASTREÁVEL ===")
        print(f"Execução: {execution_id}")
        print(f"Modo: {stored['modo_execucao']}")
        print(f"Ação: {stored['decisao_final']}")
        print(f"Status: {stored['status_processamento']}")
        print("HydrosOnto no score:", stored["verificacao_semantica"]["affects_amdh_score"])
        print("Evidências persistidas:", len(stored["registro_execucao"]["evidences"]))
        print("PERSISTÊNCIA: OK")


if __name__ == "__main__":
    main()
