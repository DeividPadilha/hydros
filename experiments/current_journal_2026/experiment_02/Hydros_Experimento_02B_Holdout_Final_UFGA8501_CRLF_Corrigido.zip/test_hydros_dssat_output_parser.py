from pathlib import Path

import pytest

from src.evaluation.dssat_output_parser import (
    DSSATOutputParseError,
    find_tables_with_columns,
    inventory_dssat_output_file,
    parse_dssat_output_tables,
)


def test_parse_single_table(tmp_path: Path):
    p = tmp_path / "SoilWat.OUT"
    p.write_text(
        "*RUN 1\n"
        "@YEAR DOY SWTD SWXD\n"
        " 1985 172 250.0 150.0\n"
        " 1985 173 248.5 148.5\n",
        encoding="utf-8",
    )
    tables = parse_dssat_output_tables(p)
    assert len(tables) == 1
    assert tables[0].columns == ("YEAR", "DOY", "SWTD", "SWXD")
    assert len(tables[0].dataframe) == 2
    assert float(tables[0].dataframe.iloc[1]["SWXD"]) == 148.5


def test_parse_multiple_run_blocks(tmp_path: Path):
    p = tmp_path / "PlantGro.OUT"
    p.write_text(
        "*RUN 1\n"
        "@YEAR DOY DAS RDPD WSPD\n"
        " 1985 172 1 2.0 0.0\n"
        "*RUN 2\n"
        "@YEAR DOY DAS RDPD WSPD\n"
        " 1985 172 1 2.0 0.1\n",
        encoding="utf-8",
    )
    tables = parse_dssat_output_tables(p)
    assert len(tables) == 2
    assert float(tables[1].dataframe.iloc[0]["WSPD"]) == 0.1


def test_find_table_by_published_columns(tmp_path: Path):
    p = tmp_path / "SoilWat.OUT"
    p.write_text("@YEAR DOY SWTD SWXD\n1985 172 250 150\n", encoding="utf-8")
    tables = parse_dssat_output_tables(p)
    assert len(find_tables_with_columns(tables, ["doy", "swxd"])) == 1
    assert find_tables_with_columns(tables, ["RDPD"]) == []


def test_reject_shifted_or_truncated_row(tmp_path: Path):
    p = tmp_path / "Broken.OUT"
    p.write_text("@YEAR DOY SWTD SWXD\n1985 172 250\n", encoding="utf-8")
    with pytest.raises(DSSATOutputParseError):
        parse_dssat_output_tables(p)


def test_inventory_preserves_headers(tmp_path: Path):
    p = tmp_path / "Summary.OUT"
    p.write_text("*SUMMARY\n@RUN TRTNO HWAM\n1 2 3210\n", encoding="utf-8")
    inv = inventory_dssat_output_file(p)
    assert inv["tables"][0]["columns"] == ["RUN", "TRTNO", "HWAM"]
    assert inv["tables"][0]["n_rows"] == 1
