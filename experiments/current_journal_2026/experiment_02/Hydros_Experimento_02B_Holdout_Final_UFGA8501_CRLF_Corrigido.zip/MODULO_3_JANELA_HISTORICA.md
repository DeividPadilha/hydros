# Hydros, Módulo 3, janela histórica configurável

Data: 12/08/2026

## Ponto de partida preservado

Este módulo foi criado a partir do arquivo `hydros_entrega_1_2_alinhado_tese.zip`.
O ZIP da Entrega 1 e 2 não foi sobrescrito e permanece como ponto de retorno.

SHA-256 do ponto de partida: `cdd806d362f1985b25f0ee730680e789b4acf8fcfaf050399c9c7dd6d9c25064`.

## Objetivo

Remover o valor fixo de cinco contextos espalhado pelo código e transformar a
janela temporal recente em uma configuração central do Hydros, sem alterar o
comportamento padrão nem os resultados já obtidos com janela cinco.

## Implementação

- `TAMANHO_JANELA_HISTORICA_PADRAO = 5` definido em `src/config/hydros_terms.py`;
- função central de validação da janela criada;
- `HydrosEngine` recebe `tamanho_janela_historica`;
- configuração propagada para Aclim, Ahid, Afen, Aprod, Ahist e ARG;
- `FeatureExtractor` passa a usar a mesma janela;
- `APSAgent` registra janela de execução e janela usada no treinamento;
- alteração da janela para valor diferente do treinamento gera aviso explícito e
  restringe o uso científico do APS até novo treinamento;
- qualidade/cobertura histórica passa a considerar a janela configurada;
- interface Streamlit expõe a configuração da janela;
- chave de análise da interface inclui o tamanho da janela para evitar reutilizar
  resultados de uma configuração diferente;
- registro de execução inclui janela configurada, janela do treinamento do APS e
  indicador de compatibilidade.

## Regra científica preservada

A configuração padrão continua sendo cinco contextos. Assim, nenhuma execução
anterior é modificada silenciosamente. Alterar a janela muda a definição dos
atributos históricos do APS; por isso, uma janela diferente de cinco não será
tratada como cientificamente equivalente enquanto o APS não for retreinado.

## Validação

- `pytest`: 8 testes aprovados;
- 18 arquivos `test_*.py`: 18 aprovados;
- novos testes específicos da janela: 6 aprovados;
- regressão com a Entrega 1 e 2 no padrão de cinco contextos: resultados centrais
  idênticos, incluindo evidências, ação, score, confiança, conflito e status.
- diretório `results/` restaurado após os testes e confirmado como idêntico byte a byte em relação à Entrega 1 e 2.

## Próximo módulo

Atualizar o pipeline do Experimento I para a comparação oficial `Hydros Histórico`
versus `Hydros sem Histórico`, sem ainda retreinar o APS ou iniciar o Experimento II.
