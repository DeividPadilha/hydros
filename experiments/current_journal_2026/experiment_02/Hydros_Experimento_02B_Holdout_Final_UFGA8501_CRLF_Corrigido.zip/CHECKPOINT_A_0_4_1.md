# Hydros 0.4.1-audit-checkpointA

## Objetivo

Checkpoint de baixo risco criado a partir da release 0.4.0-qualificacao. A versão anterior permanece preservada e não foi sobrescrita.

## Alterações

1. Terminologia da tabela de execuções persistidas da interface alinhada à tese: passa a exibir `Ação determinada` e `Status`, removendo da visualização os rótulos legados `Decisão original`, `Decisão final` e `Avaliação humana`.
2. Limiares operacionais já existentes em Aclim, Ahid, Afen, Aprod, Ahist, AIEC e ARG foram centralizados em `src/config/hydros_terms.py` no dicionário `LIMIARES_AGENTES`.
3. Os pesos r1-r8 do ARG passaram a consumir `PESOS_REGRAS_ARG`, que já existia na configuração, eliminando duplicação.
4. Nenhum valor de limiar, peso, regra, ação, score ou modelo foi recalibrado neste checkpoint.
5. Foi criado `test_hydros_checkpoint_a.py` para verificar a centralização e a terminologia da interface.

## Regra de preservação

Os resultados experimentais existentes e os artefatos de modelos/ontologia devem permanecer byte a byte iguais aos registrados antes deste checkpoint. Alterações científicas de confiança e soma térmica ficam para checkpoints posteriores.

## Validação executada

- compilação Python: OK;
- teste específico do Checkpoint A: OK;
- 22 scripts de teste do projeto reportaram OK no ciclo de validação;
- quatro cenários funcionais: 4/4 coerentes;
- teste de sensibilidade: OK;
- teste de rastreabilidade: OK;
- snapshot dos agentes Aclim, Ahid, Afen, Ageo, Aprod, Ahist, ARG e AIEC comparado com a release 0.4.0: idêntico;
- hashes dos resultados científicos existentes, excluindo apenas os relatórios de validação que carregam a versão, permaneceram idênticos;
- artefatos APS e `hydrosonto.owl` permaneceram idênticos.

A tentativa de regenerar o Experimento I completo não foi usada como critério deste checkpoint porque a execução integral ultrapassa a janela de execução disponível. O checkpoint não altera lógica, pesos ou limiares e o comportamento dos agentes foi comparado diretamente com a release 0.4.0.
