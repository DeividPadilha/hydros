from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

import pandas as pd

from src.evaluation.dssat_hydros_mapping import build_hydros_context_from_dssat_outputs
from src.services.hydros_engine import HydrosEngine

ROOT = Path(__file__).resolve().parent
PROBE = ROOT / "results" / "experimento_2b" / "dssat_probe"
OUT = ROOT / "results" / "experimento_2b" / "bridge_v2_ufga7901"
OUT.mkdir(parents=True, exist_ok=True)


def latest(treatment: str) -> Path:
    matches = sorted(PROBE.glob(f"ufga7901_UFGA7901_{treatment}_*"))
    if not matches:
        raise FileNotFoundError(treatment)
    return matches[-1]


def run_scenario(treatment: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    scenario = f"UFGA7901_{treatment}"
    contexts = build_hydros_context_from_dssat_outputs(latest(treatment), scenario_id=scenario)
    contexts.to_csv(OUT / f"contextos_corrigidos_{scenario}.csv", index=False)

    engine = HydrosEngine(modo_execucao="historico")
    rows = []
    for idx in range(len(contexts)):
        prefix = contexts.iloc[: idx + 1].copy()
        result = engine.processar(prefix, modo_execucao="historico", propriedade_id="UF_Gainesville")
        row = contexts.iloc[idx]
        rows.append({
            "scenario": scenario,
            "index": idx,
            "data": row["data"],
            "DAS": int(row["dia_safra"]),
            "DAP": int(row["dap"]),
            "estagio": row["estagio_fenologico"],
            "kc": float(row["coeficiente_cultura"]),
            "umidade_solo": float(row["umidade_solo"]),
            "agua_disponivel": float(row["agua_disponivel"]),
            "stress_dssat": float(row["dssat_estresse_max"]),
            "estresse_hidrico": row["estresse_hidrico"],
            "irrigacao_aplicada": float(row["irrigacao_aplicada"]),
            "Ehid": result["ahid"].get("Ehid"),
            "Ehist": result["ahist"].get("Ehist"),
            "Efen": result["afen"].get("Efen"),
            "Eprod": result["aprod"].get("Eprod"),
            "Ehc": result["aiec"].get("Ehc"),
            "Earg": result["arg"].get("Earg"),
            "Eaps": result["aps"].get("Eaps"),
            "aps_status_dominio": result["aps"].get("status_dominio"),
            "acao": result["amdh"].get("D(Ui)"),
            "acao_candidata": result["amdh"].get("acao_candidata"),
            "status_processamento": result["amdh"].get("status_processamento"),
            "score_manter": result["amdh"].get("escores_acoes_validos", {}).get("manter_irrigacao"),
            "score_iniciar": result["amdh"].get("escores_acoes_validos", {}).get("iniciar_irrigacao"),
            "confianca": result["amdh"].get("confianca"),
            "indice_conflito": result["amdh"].get("indice_conflito"),
        })
    diag = pd.DataFrame(rows)
    diag.to_csv(OUT / f"diagnostico_hydros_{scenario}.csv", index=False)
    return contexts, diag


def counts(series: pd.Series) -> dict[str, int]:
    return {str(k): int(v) for k, v in Counter(series.fillna("<null>")).items()}


summary = {"experiment": "UFGA7901 bridge-v2 diagnostic", "holdout": False, "scenarios": {}}
for treatment in ("T1", "T2"):
    contexts, diag = run_scenario(treatment)
    controlled = diag[diag["DAP"] >= 20]
    stress = controlled[controlled["stress_dssat"] >= 0.25]
    summary["scenarios"][treatment] = {
        "n": int(len(diag)),
        "n_control_dap_ge_20": int(len(controlled)),
        "effective_irrigation_mm": round(float(contexts["irrigacao_aplicada"].sum()), 6),
        "yield_GWAD_final_kg_ha": round(float(contexts["dssat_GWAD_kg_ha"].iloc[-1]), 6),
        "dssat_stress_days_ge_0_25_control": int(len(stress)),
        "dssat_stress_sum_control": round(float(controlled["stress_dssat"].sum()), 6),
        "actions_control": counts(controlled["acao"]),
        "Ehid_control": counts(controlled["Ehid"]),
        "Ehist_control": counts(controlled["Ehist"]),
        "Ehc_control": counts(controlled["Ehc"]),
        "Earg_control": counts(controlled["Earg"]),
        "Eaps_control": counts(controlled["Eaps"]),
        "aps_domain_control": counts(controlled["aps_status_dominio"]),
        "actions_on_dssat_stress_days": counts(stress["acao"]),
        "mean_score_iniciar_on_stress": None if stress.empty else round(float(stress["score_iniciar"].mean()), 6),
        "mean_score_manter_on_stress": None if stress.empty else round(float(stress["score_manter"].mean()), 6),
    }

(OUT / "resumo_diagnostico_bridge_v2.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
)
print(json.dumps(summary, ensure_ascii=False, indent=2))
print(f"\nArquivos em: {OUT}")
