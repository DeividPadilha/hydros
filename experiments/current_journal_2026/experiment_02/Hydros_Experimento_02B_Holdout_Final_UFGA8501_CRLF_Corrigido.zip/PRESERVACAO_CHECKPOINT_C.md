# Preservação do Checkpoint C

O Checkpoint C foi criado a partir de `0.4.1-audit-checkpointB` sem sobrescrever a entrega anterior.

Foram preservados dentro desta árvore:

- `audit/checkpointC/pre_change_sha256.json`;
- `src/models/legacy/checkpointB_pre_termico/`;
- `data/legacy/checkpointB_pre_termico/`;
- `ontology/legacy/checkpointB_pre_termico/hydrosonto.owl`;
- `results/legacy/checkpointB_pre_termico/`.

Os resultados atuais pertencem ao checkpoint C e não devem ser misturados com resultados experimentais das versões anteriores.
