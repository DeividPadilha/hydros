"""Testes do protocolo causal do Experimento II."""

from src.evaluation.experiment2_protocol import (
    actions_for_next_interval,
    schedule_from_causal_actions,
    verify_planned_against_simulated,
)
from src.evaluation.irrigation_policy import IrrigationPolicyConfig


def main():
    cfg = IrrigationPolicyConfig(base_mm=10, step_mm=2, min_mm=6, max_mm=14)
    decisions = [
        "iniciar_irrigacao",
        "manter_irrigacao",
        "aumentar_irrigacao",
        "finalizar_irrigacao",
    ]

    shifted = actions_for_next_interval(decisions)
    assert shifted == [None, "iniciar_irrigacao", "manter_irrigacao", "aumentar_irrigacao"]

    applied, planned = schedule_from_causal_actions(decisions, cfg)
    assert applied == shifted
    assert planned == [0.0, 10.0, 10.0, 12.0], planned

    ok = verify_planned_against_simulated(
        planned,
        [0.0, 10.0, 10.0, 12.0],
        dates=["d1", "d2", "d3", "d4"],
    )
    assert ok.exact_match is True
    assert ok.effect_metrics_allowed is True
    assert ok.first_divergence_index is None

    bad = verify_planned_against_simulated(
        planned,
        [0.0, 10.0, 0.0, 12.0],
        dates=["d1", "d2", "d3", "d4"],
    )
    assert bad.exact_match is False
    assert bad.effect_metrics_allowed is False
    assert bad.first_divergence_index == 2
    assert bad.first_divergence_date == "d3"

    try:
        verify_planned_against_simulated([0.0], [0.0, 1.0])
    except ValueError:
        pass
    else:
        raise AssertionError("Comprimentos incompatíveis deveriam falhar.")

    print("TEST EXPERIMENT 2 PROTOCOL: OK")


if __name__ == "__main__":
    main()
