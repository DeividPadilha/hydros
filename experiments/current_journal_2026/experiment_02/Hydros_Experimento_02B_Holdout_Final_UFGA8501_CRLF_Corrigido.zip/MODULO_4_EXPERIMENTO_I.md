# Módulo 4 — Experimento I: Histórico versus sem Histórico

Data: 12/08/2026

## Ponto de retorno

A Entrega 3 foi mantida intacta fora deste projeto.

SHA-256 da entrada usada neste módulo:

`dba55337dbee6cde5a61c092a2b1e1aed5398aa8ec0cfa6a7e2f3406703d2bff  hydros_entrega_3_janela_historica.zip`

Os resultados anteriores do diretório `results/` também foram preservados em:

`results/legacy/modulo3_pre_experimento1_20260812/`

## O que foi implementado

- criado `run_experimento_1.py` como executor canônico do Experimento I;
- mantido `run_dssat_comparison.py` como wrapper legado para não quebrar comandos antigos;
- substituída a nomenclatura Instantâneo por `sem_historico` nos artefatos atuais;
- comparação pareada sobre as mesmas 256 observações;
- processamentos inconclusivos são preservados como inconclusivos e não convertidos em ação;
- adicionadas taxa conclusiva e acurácia condicional entre execuções conclusivas;
- adicionados `comparacao_pareada.csv`, `resumo_pareado.csv` e `metricas_por_cenario.csv`;
- atualizadas matrizes de confusão para incluir a saída inconclusiva;
- atualizados diagnóstico, figuras, tabelas e síntese experimental;
- removidos indicadores de revisão humana do pipeline do Experimento I;
- atualizada a validação para esperar Histórico e sem Histórico.

## Resultado da execução atual

Base: 256 observações em duas execuções DSSAT.

| Indicador | Histórico | sem Histórico |
|---|---:|---:|
| Processamentos conclusivos | 166 | 51 |
| Taxa conclusiva | 0,6484 | 0,1992 |
| Acurácia global | 0,6133 | 0,1836 |
| Acurácia nas conclusivas | 0,9458 | 0,9216 |
| F1 macro | 0,1528 | 0,0635 |
| Confiança média | 0,3734 | 0,3360 |

Comparação pareada:

- 139 saídas diferentes;
- 122 casos em que somente o Histórico concordou com a referência;
- 12 casos em que somente o sem Histórico concordou;
- 35 casos em que ambos concordaram;
- 87 casos em que nenhum concordou.

## Achado importante

A referência possui 11 eventos de `iniciar_irrigacao`, mas a versão atual do
Hydros não determinou ação de intensificação em nenhum desses eventos. Isso não
foi ocultado nem corrigido por ajuste oportunista de pesos ou limiares.

O modo Histórico apresentou maior taxa conclusiva e maior concordância global,
mas esse ganho ocorre principalmente na classe dominante `manter_irrigacao`.
Portanto, o Experimento I está implementado e reproduzível, mas sua interpretação
científica ainda depende dos próximos módulos, principalmente retreinamento do
APS e análise de sensibilidade.

## Validação

Foram executados com sucesso, de forma independente:

- 15 testes funcionais atuais;
- `run_experimento_1.py`;
- `diagnostico_resultados.py`;
- `test_hydros_article_outputs.py`.

No ambiente de execução desta revisão, a chamada monolítica de
`run_hydros_validation.py` apresentou lentidão progressiva ao encadear muitos
subprocessos. Os mesmos testes e os três estágios do pipeline foram executados
separadamente com sucesso. O script foi mantido com limitação de threads BLAS e
captura por arquivos temporários para maior robustez entre plataformas.

## Próximo módulo

Módulo 5: adequação e retreinamento científico do APS, sem alterar os resultados
preservados deste módulo.
