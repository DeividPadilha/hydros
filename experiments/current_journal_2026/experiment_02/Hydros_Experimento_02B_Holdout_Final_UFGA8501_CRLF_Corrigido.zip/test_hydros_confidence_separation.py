"""Regressão do checkpoint B: confiança não pode ser sinônimo de criticidade."""

from __future__ import annotations

import pandas as pd

from src.services.hydros_engine import HydrosEngine


def main() -> None:
    engine = HydrosEngine()

    adequada = pd.read_csv("data/cenarios_teste/cenario_01_baixa_criticidade.csv")
    critica = pd.read_csv("data/cenarios_teste/cenario_04_critico_com_irrigacao_ativa.csv")

    r_adequada = engine.processar(adequada, modo_execucao="historico")
    r_critica = engine.processar(critica, modo_execucao="historico")

    # Os dois cenários possuem dados completos. A classificação pode mudar,
    # mas a confiança dos dados não deve aumentar apenas porque a condição
    # passou de adequada para crítica.
    for agente in ("aclim", "ahid", "afen", "ageo", "aprod", "ahist", "arg"):
        a = r_adequada[agente]
        c = r_critica[agente]
        assert a["confianca"] == a["confianca_dados"]
        assert c["confianca"] == c["confianca_dados"]
        assert a["completude"] == 1.0
        assert c["completude"] == 1.0
        assert a["confianca"] == c["confianca"] == 1.0

    assert r_adequada["aiec"]["Ehc"] == "adequada"
    assert r_critica["aiec"]["Ehc"] == "critica"
    assert r_adequada["aiec"]["confianca"] == r_critica["aiec"]["confianca"] == 1.0

    # O valor legado continua disponível somente para auditoria.
    assert r_adequada["ahid"]["confianca_criticidade_legada"] != r_critica["ahid"]["confianca_criticidade_legada"]

    # O ARG também foi migrado para confiança sustentada pelos dados.
    assert r_adequada["arg"]["confianca"] == r_adequada["arg"]["confianca_dados"]
    assert r_critica["arg"]["confianca"] == r_critica["arg"]["confianca_dados"]

    print("SEPARAÇÃO CONFIANÇA x CRITICIDADE: OK")


if __name__ == "__main__":
    main()
