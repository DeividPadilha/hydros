# Correção técnica do holdout UFGA8501

## Problema identificado
A instalação Windows do DSSAT contém `UFGA8501.SBX` com finais de linha CRLF, enquanto o fixture congelado e o arquivo oficial do repositório DSSAT usam LF. O conteúdo é semanticamente idêntico, mas o SHA-256 bruto muda.

- SHA-256 oficial/LF: `9262220adef9d76061f0f8ae6f8394466e13537485382d5aef76fba0d897bda0`
- SHA-256 Windows/CRLF observado: `5884d1490e03c2b1e95506a14433f5a5800ec8ac916fc774678056265c8c98af`

## Correção
O runner final agora normaliza **somente os finais de linha** antes da verificação do hash. Espaços internos, colunas de largura fixa, datas, tratamentos, irrigações e demais valores permanecem intocados. O contrato do holdout também continua verificando MI=2, prefixo comum e 217 mm da programação de referência.

Nenhum peso, limiar, regra, agente, APS ou parâmetro experimental foi alterado.
