# Próxima execução local do Experimento 02B

O núcleo do Hydros permanece congelado. Antes de executar o holdout UFGA8501, a próxima etapa é validar o DSSAT local com um cenário já conhecido, preferencialmente UFGA7901, e capturar os cabeçalhos reais dos arquivos `.OUT`.

## 1. Pré-validação da instalação

No PowerShell, dentro da pasta deste projeto:

```powershell
python preflight_experimento_02b.py --dssat-root "C:\DSSAT48"
```

Se o DSSAT estiver em outro diretório, substitua `C:\DSSAT48` pelo caminho correto.

## 2. Localizar o experimento diagnóstico UFGA7901

Use a cópia instalada com o DSSAT. O arquivo deve se chamar `UFGA7901.SBX`.

## 3. Executar apenas o diagnóstico de saída

Exemplo, ajustando os caminhos reais:

```powershell
python probe_dssat_outputs.py --exe "C:\DSSAT48\DSCSM048.EXE" --experiment "C:\DSSAT48\Soybean\UFGA7901.SBX" --treatment 2 --label ufga7901
```

O script executa o DSSAT em modo C, copia os `.OUT` gerados e cria `inventario_outputs_dssat.json` em `results\experimento_2b\dssat_probe\...`.

## 4. O que enviar de volta

Envie a pasta criada em `results\experimento_2b\dssat_probe\...` ou, no mínimo, o arquivo `inventario_outputs_dssat.json` e os arquivos `PlantGro.OUT`, `SoilWat.OUT`/`SoilWater.OUT` e `Summary.OUT` capturados.

Essa execução é apenas diagnóstica. O holdout UFGA8501 continuará fechado até a ponte de saída DSSAT -> Hydros estar validada.
