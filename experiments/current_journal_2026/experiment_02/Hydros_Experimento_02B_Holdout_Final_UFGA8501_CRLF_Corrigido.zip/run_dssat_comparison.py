"""Compatibilidade para o antigo comando de comparação DSSAT.

O Experimento I canônico está implementado em ``run_experimento_1.py`` e
compara Hydros Histórico com Hydros sem Histórico. Este arquivo é preservado
para que comandos e atalhos antigos não sejam perdidos.
"""

from run_experimento_1 import main


if __name__ == "__main__":
    main()
