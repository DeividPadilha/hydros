from src.agents.amdh_agent import AMDHAgent
from src.core.irrigation_state import IrrigationState


def state(active: bool):
    return IrrigationState(
        active=active,
        state="ativa" if active else "inativa",
        source="teste",
        confidence=1.0,
        applied_mm=10.0 if active else 0.0,
        explicit=True,
    )


def scores(agent, evidence, active):
    return agent.calcular_escores_acoes(
        ehc=evidence,
        earg=evidence,
        eaps=evidence,
        indice_conflito=0.0,
        estado=state(active),
        pesos_efetivos={"Ehc": 0.4, "Earg": 0.3, "Eaps": 0.3},
    )["escores_validos"]


def test_inativa_condicao_adequada_mantem_sem_irrigar():
    agent = AMDHAgent()
    result = scores(agent, "adequada", False)
    assert agent.selecionar_acao(result) == "manter_irrigacao"


def test_inativa_condicao_atencao_inicia_irrigacao():
    agent = AMDHAgent()
    result = scores(agent, "atencao", False)
    assert agent.selecionar_acao(result) == "iniciar_irrigacao"


def test_inativa_condicao_critica_inicia_irrigacao():
    agent = AMDHAgent()
    result = scores(agent, "critica", False)
    assert agent.selecionar_acao(result) == "iniciar_irrigacao"


def test_ativa_condicao_atencao_preserva_alvo_legado_de_manter():
    agent = AMDHAgent()
    result = scores(agent, "atencao", True)
    assert agent.selecionar_acao(result) == "manter_irrigacao"


def test_ativa_condicao_critica_aumenta():
    agent = AMDHAgent()
    result = scores(agent, "critica", True)
    assert agent.selecionar_acao(result) == "aumentar_irrigacao"
