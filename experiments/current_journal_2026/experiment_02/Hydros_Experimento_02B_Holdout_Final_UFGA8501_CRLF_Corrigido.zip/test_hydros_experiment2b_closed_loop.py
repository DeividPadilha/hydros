import pandas as pd

from src.evaluation.experiment2b_closed_loop import run_closed_loop
from src.evaluation.irrigation_policy import IrrigationActionPolicy, IrrigationPolicyConfig


class FakeWaterBackend:
    """Backend determinístico simples usado apenas para testar causalidade."""

    def __init__(self, n=6):
        self.n = n
        self.rain = [0, 0, 0, 0, 0, 0]
        self.demand = [20, 20, 20, 20, 20, 20]

    def simulate(self, irrigation_schedule_mm):
        water = 90.0
        rows = []
        for i in range(self.n):
            irrigation = float(irrigation_schedule_mm[i])
            water = max(0.0, min(100.0, water + self.rain[i] + irrigation - self.demand[i]))
            rows.append({
                "data": f"d{i+1}",
                "dia_safra": i + 1,
                "precipitacao": self.rain[i],
                "temperatura": 30.0,
                "irrigacao_aplicada": irrigation,
                "agua_disponivel": water,
            })
        return pd.DataFrame(rows)


def test_closed_loop_feedback_changes_future_states_and_is_causal():
    backend = FakeWaterBackend()
    policy = IrrigationActionPolicy(IrrigationPolicyConfig(
        base_mm=30.0,
        step_mm=10.0,
        min_mm=10.0,
        max_mm=40.0,
    ))

    def decide(history):
        water = float(history.iloc[-1]["agua_disponivel"])
        if water < 50:
            return "iniciar_irrigacao"
        if water >= 80:
            return "finalizar_irrigacao"
        return "manter_irrigacao"

    result = run_closed_loop(
        backend=backend,
        decision_fn=decide,
        policy=policy,
        n_periods=6,
        exogenous_columns=["precipitacao", "temperatura"],
    )

    assert result.n_simulations == 6
    assert len(result.trace) == 5
    assert result.trajectory["irrigacao_aplicada"].tolist() == list(result.irrigation_schedule_mm)
    # Sem feedback, a água cairia a zero. Com a ação tomada após o terceiro
    # contexto, a irrigação entra apenas no intervalo seguinte.
    assert result.irrigation_schedule_mm[0:3] == (0.0, 0.0, 0.0)
    assert result.irrigation_schedule_mm[3] == 30.0
    assert result.trajectory.iloc[3]["agua_disponivel"] > 10.0


def test_fixed_prefix_is_preserved_before_hydros_control():
    backend = FakeWaterBackend()
    policy = IrrigationActionPolicy(IrrigationPolicyConfig(
        base_mm=20.0, step_mm=5.0, min_mm=5.0, max_mm=30.0
    ))

    result = run_closed_loop(
        backend=backend,
        decision_fn=lambda history: "finalizar_irrigacao",
        policy=policy,
        n_periods=6,
        fixed_prefix_mm=[10.0, 10.0],
        control_start_index=1,
    )

    assert result.irrigation_schedule_mm[:2] == (10.0, 10.0)
    assert result.irrigation_schedule_mm[2] == 0.0
