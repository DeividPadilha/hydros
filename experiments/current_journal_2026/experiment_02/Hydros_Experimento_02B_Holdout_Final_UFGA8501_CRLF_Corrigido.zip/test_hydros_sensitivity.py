from pathlib import Path

import pandas as pd

from run_sensibilidade import gerar_configuracoes


configs = gerar_configuracoes()
assert len(configs) == 25, len(configs)
assert configs[0].id == "base"
for cfg in configs:
    assert abs(sum(cfg.pesos_amdh.values()) - 1.0) < 1e-9
    assert abs(sum(cfg.pesos_aiec.values()) - 1.0) < 1e-9
    assert all(v >= 0.0 for v in cfg.pesos_amdh.values())
    assert all(v >= 0.0 for v in cfg.pesos_aiec.values())
assert len({c.id for c in configs}) == len(configs)

# A configuração-base da análise de sensibilidade deve reproduzir exatamente
# as saídas do Hydros Histórico no Experimento I. Isso evita que o cache da
# sensibilidade use um contrato de evidência diferente do motor principal.
exp_path = Path("results/experimento_1/comparacao_detalhada.csv")
sens_path = Path("results/modulo_6_sensibilidade/detalhes_sensibilidade.csv")
if exp_path.exists() and sens_path.exists():
    exp = pd.read_csv(exp_path)
    sens = pd.read_csv(sens_path)
    base = sens[sens["config_id"] == "base"].copy()
    merged = exp.merge(
        base[["cenario_id", "data", "saida_hydros", "conclusivo"]],
        on=["cenario_id", "data"],
        validate="one_to_one",
    )
    expected = exp["saida_hydros_historico"].fillna("inconclusivo").astype(str)
    actual = merged["saida_hydros"].fillna("inconclusivo").astype(str)
    assert expected.tolist() == actual.tolist()
    assert (
        exp["processamento_conclusivo_historico"].astype(bool).tolist()
        == merged["conclusivo"].astype(bool).tolist()
    )

print("TEST SENSITIVITY: OK")
