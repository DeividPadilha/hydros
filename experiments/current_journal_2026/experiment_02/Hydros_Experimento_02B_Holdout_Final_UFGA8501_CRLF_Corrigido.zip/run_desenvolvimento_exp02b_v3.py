"""Executa somente cenários de DESENVOLVIMENTO do Experimento II-B.

Este script deliberadamente bloqueia UFGA8501, reservado como holdout final.
Ele executa UFGA7801 e UFGA8401 (tratamentos 1 e 2), captura os .OUT,
traduz os estados DSSAT com a ponte v2 e avalia o comportamento do Hydros V3.

Uso no Windows:
    python run_desenvolvimento_exp02b_v3.py --dssat-root "C:\\DSSAT48"
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime
import json
from pathlib import Path
import shutil

import pandas as pd

from src.evaluation.dssat_cli import DSSATCommandConfig, run_dssat_command
from src.evaluation.dssat_hydros_mapping import build_hydros_context_from_dssat_outputs
from src.evaluation.dssat_output_parser import parse_dssat_output_tables
from src.services.hydros_engine import HydrosEngine

ROOT = Path(__file__).resolve().parent
RESULT_ROOT = ROOT / "results" / "experimento_2b" / "desenvolvimento_v3"
DEVELOPMENT_EXPERIMENTS = ("UFGA7801", "UFGA8401")
HOLDOUT_FORBIDDEN = "UFGA8501"
TREATMENTS = (1, 2)


def _copy_outputs(source_dir: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=False)
    copied = 0
    for source in sorted(source_dir.glob("*.OUT")):
        shutil.copy2(source, destination / source.name)
        copied += 1
    if copied == 0:
        raise RuntimeError(f"Nenhum .OUT encontrado após executar DSSAT em {source_dir}")


def execute_and_capture(exe: Path, experiment: Path, treatment: int) -> Path:
    if HOLDOUT_FORBIDDEN in experiment.stem.upper():
        raise RuntimeError("UFGA8501 é holdout e está bloqueado neste script de desenvolvimento.")

    config = DSSATCommandConfig(
        executable=exe,
        experiment_file=experiment,
        treatment=int(treatment),
        working_directory=experiment.parent,
        timeout_seconds=240,
    )
    completed = run_dssat_command(config)
    if completed.returncode != 0:
        raise RuntimeError(
            f"DSSAT falhou em {experiment.name} T{treatment}: "
            f"returncode={completed.returncode}\n{completed.stderr or ''}"
        )

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    destination = RESULT_ROOT / "dssat_runs" / f"{experiment.stem}_T{treatment}_{stamp}"
    _copy_outputs(experiment.parent, destination)
    (destination / "stdout.txt").write_text(completed.stdout or "", encoding="utf-8")
    (destination / "stderr.txt").write_text(completed.stderr or "", encoding="utf-8")
    return destination


def load_table(output_dir: Path, filename: str) -> pd.DataFrame:
    tables = parse_dssat_output_tables(output_dir / filename)
    if len(tables) != 1:
        raise ValueError(f"{filename}: esperado 1 bloco, encontrados {len(tables)}")
    return tables[0].dataframe.copy()


def same_weather(t1: Path, t2: Path) -> dict[str, object]:
    a = load_table(t1, "Weather.OUT")
    b = load_table(t2, "Weather.OUT")
    cols = ["PRED", "TMXD", "TMND", "SRAD"]
    if len(a) != len(b):
        return {"same_weather": False, "reason": "row_count", "n_t1": len(a), "n_t2": len(b)}
    max_diff = {}
    for col in cols:
        av = pd.to_numeric(a[col], errors="coerce")
        bv = pd.to_numeric(b[col], errors="coerce")
        max_diff[col] = float((av - bv).abs().max())
    return {
        "same_weather": all(v == 0.0 for v in max_diff.values()),
        "n_rows": int(len(a)),
        "max_abs_diff": max_diff,
    }


def counts(series: pd.Series) -> dict[str, int]:
    return {str(k): int(v) for k, v in Counter(series.fillna("<null>")).items()}


def diagnose(output_dir: Path, scenario_id: str) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, object]]:
    contexts = build_hydros_context_from_dssat_outputs(output_dir, scenario_id=scenario_id)
    engine = HydrosEngine(modo_execucao="historico")
    rows: list[dict[str, object]] = []

    for idx in range(len(contexts)):
        prefix = contexts.iloc[: idx + 1].copy()
        result = engine.processar(prefix, modo_execucao="historico", propriedade_id="UF_Gainesville")
        row = contexts.iloc[idx]
        amdh = result["amdh"]
        rows.append({
            "scenario": scenario_id,
            "index": idx,
            "data": row["data"],
            "DAS": int(row["dia_safra"]),
            "DAP": int(row["dap"]),
            "estagio": row["estagio_fenologico"],
            "umidade_solo": float(row["umidade_solo"]),
            "agua_disponivel": float(row["agua_disponivel"]),
            "stress_dssat": float(row["dssat_estresse_max"]),
            "irrigacao_aplicada": float(row["irrigacao_aplicada"]),
            "Ehid": result["ahid"].get("Ehid"),
            "Ehc": result["aiec"].get("Ehc"),
            "Earg": result["arg"].get("Earg"),
            "Eaps": result["aps"].get("Eaps"),
            "acao": amdh.get("D(Ui)"),
            "acao_candidata": amdh.get("acao_candidata"),
            "status_processamento": amdh.get("status_processamento"),
            "score_manter": amdh.get("escores_acoes_validos", {}).get("manter_irrigacao"),
            "score_iniciar": amdh.get("escores_acoes_validos", {}).get("iniciar_irrigacao"),
            "restricoes_hidricas": " | ".join(amdh.get("restricoes_hidricas_operacionais", [])),
            "aps_status_dominio": result["aps"].get("status_dominio"),
        })

    diag = pd.DataFrame(rows)
    controlled = diag[diag["DAP"] >= 20].copy()
    stress = controlled[controlled["stress_dssat"] >= 0.25]
    hydric_alert = controlled[controlled["Ehid"].isin(["atencao", "critica"])]
    starts = controlled[controlled["acao"] == "iniciar_irrigacao"]
    false_start_proxy = starts[starts["Ehid"] == "adequada"]

    summary = {
        "n": int(len(diag)),
        "n_control_dap_ge_20": int(len(controlled)),
        "effective_irrigation_mm": round(float(contexts["irrigacao_aplicada"].sum()), 6),
        "yield_GWAD_final_kg_ha": round(float(contexts["dssat_GWAD_kg_ha"].iloc[-1]), 6),
        "dssat_stress_days_ge_0_25_control": int(len(stress)),
        "dssat_stress_sum_control": round(float(controlled["stress_dssat"].sum()), 6),
        "actions_control": counts(controlled["acao"]),
        "Ehid_control": counts(controlled["Ehid"]),
        "Ehc_control": counts(controlled["Ehc"]),
        "Earg_control": counts(controlled["Earg"]),
        "Eaps_control": counts(controlled["Eaps"]),
        "actions_on_dssat_stress_days": counts(stress["acao"]),
        "actions_on_hydric_alert_days": counts(hydric_alert["acao"]),
        "starts_with_Ehid_adequada_proxy": int(len(false_start_proxy)),
        "aps_domain_control": counts(controlled["aps_status_dominio"]),
    }
    return contexts, diag, summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dssat-root", type=Path, required=True)
    args = parser.parse_args()

    root = args.dssat_root.resolve()
    exe = root / "DSCSM048.EXE"
    soybean = root / "Soybean"
    if not exe.exists():
        raise FileNotFoundError(exe)

    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    final: dict[str, object] = {
        "experiment": "HYDROS-EXP02B development validation V3",
        "holdout_executed": False,
        "holdout_forbidden": HOLDOUT_FORBIDDEN,
        "scenarios": {},
    }

    for exp_code in DEVELOPMENT_EXPERIMENTS:
        experiment = soybean / f"{exp_code}.SBX"
        if not experiment.exists():
            raise FileNotFoundError(experiment)
        if HOLDOUT_FORBIDDEN in experiment.name.upper():
            raise RuntimeError("Tentativa de executar holdout bloqueada.")

        captures: dict[int, Path] = {}
        final["scenarios"][exp_code] = {"treatments": {}}
        for treatment in TREATMENTS:
            capture = execute_and_capture(exe, experiment, treatment)
            captures[treatment] = capture
            scenario_id = f"{exp_code}_T{treatment}"
            contexts, diag, summary = diagnose(capture, scenario_id)
            out_dir = RESULT_ROOT / "diagnostics" / scenario_id
            out_dir.mkdir(parents=True, exist_ok=True)
            contexts.to_csv(out_dir / "contextos_corrigidos.csv", index=False)
            diag.to_csv(out_dir / "diagnostico_hydros.csv", index=False)
            final["scenarios"][exp_code]["treatments"][f"T{treatment}"] = {
                "capture_dir": str(capture),
                **summary,
            }

        final["scenarios"][exp_code]["weather_control_T1_T2"] = same_weather(
            captures[1], captures[2]
        )

    summary_path = RESULT_ROOT / "RESUMO_DESENVOLVIMENTO_V3.json"
    summary_path.write_text(json.dumps(final, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(final, ensure_ascii=False, indent=2))
    print(f"\nResultados gravados em: {RESULT_ROOT}")
    print("UFGA8501 NÃO foi executado.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
