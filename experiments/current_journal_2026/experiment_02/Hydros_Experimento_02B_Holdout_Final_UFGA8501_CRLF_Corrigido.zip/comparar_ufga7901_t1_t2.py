from __future__ import annotations

import json
from pathlib import Path
import pandas as pd

from src.evaluation.dssat_output_parser import parse_dssat_output_tables

BASE = Path(__file__).resolve().parent
PROBE_ROOT = BASE / "results" / "experimento_2b" / "dssat_probe"
OUT_ROOT = BASE / "results" / "experimento_2b" / "comparacao_diagnostica_ufga7901"


def latest_dir(pattern: str) -> Path:
    matches = sorted([p for p in PROBE_ROOT.glob(pattern) if p.is_dir()])
    if not matches:
        raise SystemExit(f"Nenhuma pasta encontrada para o padrão: {pattern}")
    return matches[-1]


def load_first_table(folder: Path, filename: str) -> pd.DataFrame:
    path = folder / filename
    if not path.is_file():
        raise SystemExit(f"Arquivo ausente: {path}")
    tables = parse_dssat_output_tables(path)
    if not tables:
        raise SystemExit(f"Nenhuma tabela DSSAT encontrada em {path}")
    return tables[0].dataframe.copy()


def as_num(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        raise SystemExit(f"Coluna ausente: {col}")
    return pd.to_numeric(df[col], errors="coerce")


def last_num(df: pd.DataFrame, col: str) -> float:
    s = as_num(df, col).dropna()
    if s.empty:
        return float("nan")
    return float(s.iloc[-1])


def mean_num(df: pd.DataFrame, col: str) -> float:
    return float(as_num(df, col).mean())


def min_num(df: pd.DataFrame, col: str) -> float:
    return float(as_num(df, col).min())


def max_num(df: pd.DataFrame, col: str) -> float:
    return float(as_num(df, col).max())


def metric_rows(folder: Path) -> dict[str, float]:
    soil = load_first_table(folder, "SoilWat.OUT")
    plant = load_first_table(folder, "PlantGro.OUT")
    et = load_first_table(folder, "ET.OUT")
    ev = load_first_table(folder, "Evaluate.OUT")

    metrics = {
        # SoilWat.OUT. Cumulative outputs are captured from the final row.
        "IRRC_final": last_num(soil, "IRRC"),
        "PREC_final": last_num(soil, "PREC"),
        "DRNC_final": last_num(soil, "DRNC"),
        "ROFC_final": last_num(soil, "ROFC"),
        "SWXD_mean": mean_num(soil, "SWXD"),
        "SWXD_min": min_num(soil, "SWXD"),
        "SWXD_final": last_num(soil, "SWXD"),
        "SWTD_mean": mean_num(soil, "SWTD"),
        "SWTD_min": min_num(soil, "SWTD"),
        "SWTD_final": last_num(soil, "SWTD"),
        # PlantGro.OUT. Preserve DSSAT variable names; no agronomic threshold is imposed here.
        "WSPD_mean": mean_num(plant, "WSPD"),
        "WSPD_min": min_num(plant, "WSPD"),
        "WSGD_mean": mean_num(plant, "WSGD"),
        "WSGD_min": min_num(plant, "WSGD"),
        "LAID_max": max_num(plant, "LAID"),
        "GWAD_final": last_num(plant, "GWAD"),
        # ET.OUT cumulative values.
        "ETAC_final": last_num(et, "ETAC"),
        "EPAC_final": last_num(et, "EPAC"),
        "ESAC_final": last_num(et, "ESAC"),
        # Evaluate.OUT raw DSSAT simulated harvest variable.
        "HWAMS": last_num(ev, "HWAMS"),
        "HWAMM": last_num(ev, "HWAMM"),
    }
    return metrics


def weather_check(t1: Path, t2: Path) -> dict[str, object]:
    w1 = load_first_table(t1, "Weather.OUT")
    w2 = load_first_table(t2, "Weather.OUT")
    keys = ["YEAR", "DOY", "DAS"]
    cols = ["PRED", "TMXD", "TMND", "SRAD"]
    for c in keys + cols:
        if c not in w1.columns or c not in w2.columns:
            return {"comparable": False, "reason": f"coluna ausente: {c}"}

    a = w1[keys + cols].copy()
    b = w2[keys + cols].copy()
    merged = a.merge(b, on=keys, suffixes=("_T1", "_T2"), how="outer", indicator=True)
    if not (merged["_merge"] == "both").all():
        return {
            "comparable": False,
            "reason": "calendario_meteorologico_nao_identico",
            "n_t1": int(len(a)),
            "n_t2": int(len(b)),
        }

    diffs = {}
    identical = True
    for c in cols:
        x = pd.to_numeric(merged[f"{c}_T1"], errors="coerce")
        y = pd.to_numeric(merged[f"{c}_T2"], errors="coerce")
        d = (x - y).abs()
        max_abs = float(d.max()) if not d.empty else 0.0
        diffs[c] = max_abs
        if pd.notna(max_abs) and max_abs > 1e-12:
            identical = False
    return {
        "comparable": True,
        "same_weather": bool(identical),
        "n_rows": int(len(merged)),
        "max_abs_diff": diffs,
    }


def main() -> int:
    t1 = latest_dir("ufga7901_UFGA7901_T1_*")
    t2 = latest_dir("ufga7901_UFGA7901_T2_*")
    m1 = metric_rows(t1)
    m2 = metric_rows(t2)
    weather = weather_check(t1, t2)

    OUT_ROOT.mkdir(parents=True, exist_ok=True)

    rows = []
    for name in m1:
        v1 = m1[name]
        v2 = m2[name]
        rows.append({
            "metric": name,
            "T1_irrigado": v1,
            "T2_rainfed": v2,
            "delta_T1_minus_T2": v1 - v2,
        })
    frame = pd.DataFrame(rows)
    frame.to_csv(OUT_ROOT / "comparacao_ufga7901_t1_t2.csv", index=False)

    payload = {
        "experiment": "UFGA7901 diagnostic comparison",
        "t1_directory": str(t1),
        "t2_directory": str(t2),
        "weather_control": weather,
        "metrics": rows,
        "notes": [
            "Diagnostico de desenvolvimento; nao e o holdout final HYDROS-EXP02B.",
            "Metricas mantem os nomes das variaveis DSSAT sempre que possivel.",
            "OVERVIEW.OUT e Summary.OUT nao sao necessarios para esta comparacao.",
            "Nenhum peso, limiar ou parametro do nucleo Hydros e alterado por este script.",
        ],
    }
    (OUT_ROOT / "comparacao_ufga7901_t1_t2.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    md = [
        "# Comparacao diagnostica UFGA7901 T1 vs T2",
        "",
        f"- T1: `{t1}`",
        f"- T2: `{t2}`",
        f"- Mesmo clima: **{weather.get('same_weather', False)}**",
        f"- Linhas meteorologicas comparadas: **{weather.get('n_rows', 0)}**",
        "",
        "| Metrica DSSAT | T1 irrigado | T2 rainfed | Delta T1-T2 |",
        "|---|---:|---:|---:|",
    ]
    for r in rows:
        md.append(
            f"| {r['metric']} | {r['T1_irrigado']:.6g} | {r['T2_rainfed']:.6g} | {r['delta_T1_minus_T2']:.6g} |"
        )
    md.extend([
        "",
        "Este arquivo e diagnostico. O UFGA8501 permanece reservado como holdout final.",
        "Os erros de parsing de `OVERVIEW.OUT` e `Summary.OUT` nao afetam esta comparacao, pois estes arquivos nao sao usados aqui.",
    ])
    (OUT_ROOT / "RELATORIO_COMPARACAO_UFGA7901_T1_T2.md").write_text(
        "\n".join(md) + "\n", encoding="utf-8"
    )

    print(json.dumps(payload, indent=2, ensure_ascii=False))
    print(f"\nArquivos gravados em: {OUT_ROOT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
