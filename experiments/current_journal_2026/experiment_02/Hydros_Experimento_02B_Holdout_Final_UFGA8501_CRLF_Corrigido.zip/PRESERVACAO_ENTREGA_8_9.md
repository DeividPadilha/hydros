# Preservação da Entrega 8/9

Ponto de partida: `hydros_entrega_6_7_sensibilidade_experimento2.zip`.

SHA-256 informado para o ponto de partida:

```text
ace5cef73157f0b4d8572b1dd856d3aa4bd8f1a99d9bc35cbda88a11e89cc3b6
```

Antes da validação final foi criado:

```text
results/legacy/modulo7_pre_validacao_final_20260813/
PRESERVACAO_BASE_MODULO_8_9.json
```

Os principais resultados de Experimento I, APS, sensibilidade e Experimento II permaneceram com os mesmos hashes após a validação. O modelo APS e a HydrosOnto também permaneceram inalterados.

As alterações desta entrega concentram-se em validação, teste de cenário, documentação, identificação da versão e mecanismo de release. O núcleo de decisão, os pesos, os limiares, o modelo APS e os resultados experimentais anteriores não foram recalibrados para produzir métricas melhores.
