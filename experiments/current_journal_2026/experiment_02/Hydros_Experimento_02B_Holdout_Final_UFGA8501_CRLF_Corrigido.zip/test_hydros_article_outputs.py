"""Valida os artefatos derivados do Experimento I."""

from __future__ import annotations

import pandas as pd

from gerar_resultados_artigo import SAIDA, main

ARQUIVOS_ESPERADOS = [
    "table_main_metrics.csv",
    "table_divergent_cases.csv",
    "table_reference_positive_events.csv",
    "table_actions_without_reference_support.csv",
    "figure_metrics_comparison.png",
    "figure_binary_confusion_matrix_historico.png",
    "figure_binary_confusion_matrix_sem_historico.png",
    "figure_reference_event_detection.png",
    "figure_processing_indicators.png",
    "experimental_results_summary.md",
]


def testar_arquivos() -> None:
    ausentes = [nome for nome in ARQUIVOS_ESPERADOS if not (SAIDA / nome).exists()]
    if ausentes:
        raise AssertionError("Artefatos ausentes: " + ", ".join(ausentes))
    vazios = [nome for nome in ARQUIVOS_ESPERADOS if (SAIDA / nome).stat().st_size == 0]
    if vazios:
        raise AssertionError("Artefatos vazios: " + ", ".join(vazios))


def validar_conteudo() -> tuple[int, int, int]:
    metricas = pd.read_csv(SAIDA / "table_main_metrics.csv")
    divergencias = pd.read_csv(SAIDA / "table_divergent_cases.csv")
    positivos = pd.read_csv(SAIDA / "table_reference_positive_events.csv")

    if set(metricas["modo"]) != {"historico", "sem_historico"}:
        raise AssertionError("A tabela de métricas não contém os dois modos canônicos.")
    if (metricas["taxa_conclusiva"] < 0).any() or (metricas["taxa_conclusiva"] > 1).any():
        raise AssertionError("Taxa conclusiva fora do intervalo [0, 1].")

    if not divergencias.empty:
        categorias_validas = {
            "vantagem_historico",
            "vantagem_sem_historico",
            "ambos_concordam",
            "ambos_nao_concordam",
        }
        observadas = set(divergencias["classificacao_divergencia"].dropna().astype(str))
        if not observadas.issubset(categorias_validas):
            raise AssertionError(f"Categorias pareadas inesperadas: {sorted(observadas)}")

    vantagem_hist = int(
        divergencias.get("classificacao_divergencia", pd.Series(dtype=str))
        .eq("vantagem_historico")
        .sum()
    )
    vantagem_sem = int(
        divergencias.get("classificacao_divergencia", pd.Series(dtype=str))
        .eq("vantagem_sem_historico")
        .sum()
    )

    # A quantidade de eventos é derivada do resultado corrente, não fixada em
    # números históricos de uma versão anterior do protótipo.
    if len(positivos) < 0:
        raise AssertionError("Contagem inválida de eventos positivos.")

    return len(divergencias), vantagem_hist, vantagem_sem


def testar_conteudo() -> None:
    """Valida o conteúdo dos artefatos sem retornar valor ao pytest."""
    validar_conteudo()


def main_test() -> None:
    main()
    testar_arquivos()
    n_div, vantagem_hist, vantagem_sem = validar_conteudo()

    print("\n=== VALIDAÇÃO DOS ARTEFATOS DO EXPERIMENTO I ===")
    print(f"Arquivos validados: {len(ARQUIVOS_ESPERADOS)}")
    print(f"Divergências validadas: {n_div}")
    print(f"Favoráveis ao Histórico: {vantagem_hist}")
    print(f"Favoráveis ao sem Histórico: {vantagem_sem}")
    print("VALIDAÇÃO DOS ARTEFATOS: OK")


if __name__ == "__main__":
    main_test()
