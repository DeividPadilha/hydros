# Módulo 5 — APS em três classes e governança científica

Data: 12/08/2026

## Ponto de retorno

A Entrega 4 foi preservada intacta fora deste projeto.

SHA-256 da entrada usada neste módulo:

`fe93af84ab44c9caed2afe6cf805d91a8b59fe1b5e5512620ff11be4fa801f0e  hydros_entrega_4_experimento_1.zip`

Os artefatos APS anteriores foram preservados em:

`src/models/legacy/modulo4_pre_aps_v2/`

O Random Forest anterior possui SHA-256:

`3f08d8caa90fe19a79c0359fa87a0f12643310461dba343988a984f5ce70f9c3`

Os resultados do Experimento I anteriores ao APS v2 foram preservados em:

`results/legacy/modulo4_pre_aps_v2_experimento1/`

## O que foi implementado

- o alvo do APS passou a usar diretamente as classes canônicas `adequada`, `atencao` e `critica`;
- rótulos legados da base são normalizados na preparação do treinamento, sem alterar o CSV original;
- a divisão continua sem embaralhamento aleatório de linhas consecutivas;
- quando existem grupos independentes suficientes, o pipeline usa separação por grupos;
- quando a base possui uma única trajetória, a divisão é cronológica 60/20/20;
- foi adicionada auditoria de prontidão científica da base;
- o modelo recebe status provisório quando não existem trajetórias independentes suficientes ou quando uma das três classes não está representada nos subconjuntos de avaliação;
- métricas macro são calculadas considerando explicitamente as três classes, inclusive quando uma classe está ausente no conjunto avaliado;
- foram criados `results/aps_modulo5/metricas_modelos.csv`, `distribuicao_classes.csv` e `prontidao_cientifica.json`;
- o `APSAgent` registra esquema alvo, prontidão científica, classe produzida pelo modelo e restrição de uso científico;
- o AMDH registra aviso de governança quando o APS ativo possui uso científico restrito, sem retirar o APS do score apenas por esse motivo;
- criado `test_hydros_aps_training_contract.py`.

## Diagnóstico da base atual

Base original: 500 contextos sintéticos, uma única trajetória.

Após a formação das janelas de tamanho 5, foram geradas 496 amostras:

- `atencao`: 417;
- `adequada`: 78;
- `critica`: 1.

Divisão cronológica:

- treino: 297 amostras, com 252 `atencao`, 44 `adequada` e 1 `critica`;
- validação: 99 amostras, sem classe `critica`;
- teste: 100 amostras, sem classe `critica`.

Por isso, `scientific_readiness.ready=false` e o status do modelo ativo é:

`modelo_tres_classes_provisorio_requer_cenarios_independentes`

O modelo foi treinado para permitir evolução e testes do protótipo, mas não deve ser apresentado como modelo final da avaliação científica da tese.

## Random Forest atual

SHA-256:

`8e1880a103a0beb93ead06bd82a901dc456a5e47c3b5ded4841250262b8012b2`

No teste cronológico atual:

- acurácia: 0,9600;
- F1 macro considerando as três classes: 0,6113;
- MCC: 0,8461.

Esses números não devem ser interpretados isoladamente, pois a classe `critica` não ocorre no conjunto de teste.

## Reexecução do Experimento I

O Experimento I foi novamente executado com o APS v2, preservando os resultados do Módulo 4.

| Indicador | Histórico | sem Histórico |
|---|---:|---:|
| Processamentos conclusivos | 167 | 36 |
| Taxa conclusiva | 0,6523 | 0,1406 |
| Acurácia global | 0,6172 | 0,1250 |
| Acurácia nas conclusivas | 0,9461 | 0,8889 |
| F1 macro | 0,1534 | 0,0456 |
| Confiança média | 0,3740 | 0,3350 |

Comparação pareada:

- 139 saídas diferentes;
- 130 casos em que somente o Histórico concordou com a referência;
- 4 casos em que somente o sem Histórico concordou;
- 28 casos em que ambos concordaram;
- 94 casos em que nenhum concordou.

Nos 11 eventos de referência `iniciar_irrigacao`, nenhum dos modos determinou `iniciar_irrigacao`.

Além disso, o APS classificou as 256 observações DSSAT como `atencao`. Esse comportamento reforça que o gargalo atual é a base de treinamento e seu domínio, e não deve ser corrigido por ajuste oportunista de pesos ou limiares.

## Validação

Foram executados com sucesso os 19 scripts `test_*.py`, incluindo o novo teste de contrato de treinamento do APS. O Experimento I, o diagnóstico e a geração/validação dos artefatos também foram executados após o retreinamento.

## O que permanece pendente no APS

Para retirar o status provisório será necessário ampliar a base com trajetórias independentes e representação real das três classes em treino, validação e teste. A geração desses dados não será simulada artificialmente neste módulo apenas para melhorar métricas.

## Próximo módulo

Módulo 6: análise de sensibilidade dos pesos e parâmetros do Hydros. O objetivo será medir estabilidade do modelo sem selecionar configurações apenas porque produzem resultados mais favoráveis.
