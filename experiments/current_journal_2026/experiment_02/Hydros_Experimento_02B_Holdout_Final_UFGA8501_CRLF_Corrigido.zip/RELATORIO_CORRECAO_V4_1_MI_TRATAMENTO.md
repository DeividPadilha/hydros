# HYDROS-EXP02B V4.1 - correção do mapeamento tratamento -> nível de irrigação

Data: 2026-08-14

## Erro encontrado na V4

A V4 assumia que o número do tratamento DSSAT era também o número do nível de irrigação (`MI`). Essa hipótese não vale para todos os arquivos `.SBX`.

No UFGA7801, o tratamento 2 é rainfed e referencia `MI=0`. Portanto, não existe um bloco explícito de irrigação de nível 2. O runner tentava executar `extract_irrigation_events(text, 2)` e encerrava com `DSSATExperimentFormatError` antes de qualquer ciclo fechado.

## Correção aplicada

1. O parser agora lê a tabela `*TREATMENTS` e recupera o nível efetivo do fator `MI` de cada tratamento.
2. `MI=0` é interpretado corretamente como ausência de programação explícita de irrigação, retornando lista vazia.
3. O candidato Hydros passa a ser uma cópia do próprio tratamento T1 de referência, alterando somente a programação de irrigação do nível realmente usado por T1.
4. O tratamento candidato é executado como T1 dentro da cópia temporária. Isso mantém cultivar, solo, plantio, clima, fertilização e demais fatores idênticos à referência; somente a programação de irrigação é alterada.
5. O tratamento T2 continua sendo usado apenas para definir o prefixo de manejo pré-controle quando existe. Em UFGA7801, como `MI=0`, esse prefixo é vazio. Em UFGA8401, T2 referencia `MI=2` e seus eventos podem ser lidos normalmente.

## O que não mudou

- Núcleo do Hydros.
- Pesos do AMDH.
- Limiares dos agentes.
- APS.
- Política de conversão ação -> lâmina.
- Holdout UFGA8501, que permanece bloqueado.

## Testes

Após a correção:

`46 passed`

Foram adicionados testes específicos para:

- UFGA7801 T2 -> `MI=0`, sem bloco nível 2;
- UFGA8401 T2 -> `MI=2`, com programação explícita nível 2.

## Próximo passo

Executar novamente:

`python run_closed_loop_desenvolvimento_exp02b_v4.py --dssat-root "C:\\DSSAT48"`

O objetivo continua sendo obter, nos cenários de desenvolvimento, as métricas reais do ciclo fechado: água aplicada, produtividade, estresse, drenagem e ações Hydros antes de abrir o holdout UFGA8501.
