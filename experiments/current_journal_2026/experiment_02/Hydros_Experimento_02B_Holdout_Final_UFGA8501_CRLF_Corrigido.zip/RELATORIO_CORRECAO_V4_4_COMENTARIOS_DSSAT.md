# Correção V4.4

## Motivo
O UFGA8401 contém linhas de eventos de irrigação comentadas com `!`, por exemplo `! 1 84153 IR001    25`. O parser V4.3 tentava convertê-las em eventos ativos e interrompia a execução.

## Correção
`extract_irrigation_events()` agora ignora linhas iniciadas por `!`, conforme a semântica de comentário dos arquivos DSSAT.

Também foi adicionada a opção `--scenario` ao runner para permitir executar apenas UFGA8401, preservando o resultado já obtido para UFGA7801.

## Integridade
Nenhum peso, limiar, agente, APS, política de elegibilidade ou regra de decisão do Hydros foi modificado.

## Testes
50 testes automatizados aprovados.
