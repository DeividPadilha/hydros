# Hydros, alinhamento com a tese, Entregas 1 e 2

Data: 12/08/2026

## Escopo concluído

Esta entrega alinha o núcleo do protótipo à versão da tese enviada para nova revisão.

### 1. Terminologia e fluxo

- modos canônicos: `historico` e `sem_historico`;
- `instantaneo` permanece apenas como alias legado de entrada;
- saídas dos agentes usam a escala `adequada`, `atencao`, `critica`;
- o AMDH determina uma ação de manejo hídrico;
- a interface não possui fluxo de aceitar, modificar ou rejeitar a ação;
- o protótipo não aciona fisicamente equipamentos de irrigação;
- quando dados, confiança ou conflito impedem uma ação segura, o processamento pode ser `inconclusivo` e `D(Ui)` fica sem ação conclusiva.

### 2. HydrosOnto

- a ontologia oficial passou a ser `ontology/hydrosonto.owl`;
- a antiga ontologia foi preservada em `ontology/hydros_onto_legacy.ttl` apenas para histórico;
- o adaptador Python não cria novos limiares agronômicos;
- a HydrosOnto é consultada para verificação semântica da condição hídrica;
- a verificação semântica não altera `Ehc`, `Earg`, `Eaps`, pesos ou o escore do AMDH;
- após uma ação conclusiva, o protótipo constrói a rastreabilidade semântica associando ação, AMDH, unidade, período, condição, evidências e regras;
- a persistência de novas instâncias diretamente no arquivo OWL não é realizada nesta entrega.

### 3. AMDH e rastreabilidade

- cálculo continua baseado em `Ehc`, `Earg` e `Eaps`;
- HydrosOnto não participa do score;
- conflitos críticos, baixa completude, baixa confiança e dependência material de APS fora de domínio podem tornar o processamento inconclusivo;
- o estado operacional da irrigação continua restringindo ações operacionalmente válidas;
- banco e contratos receberam campos para status do processamento, motivos de inconclusão, verificação semântica e rastreabilidade semântica.

## Validação executada

Os 17 testes `test_*.py` existentes no projeto foram executados após o alinhamento e passaram individualmente.

O script `run_hydros_validation.py` confirmou os 14 testes do núcleo como `OK`. A etapa seguinte do script, que executa o pipeline experimental DSSAT, não foi usada para fechar esta entrega porque pertence ao próximo bloco de atualização experimental e excedeu o limite de execução utilizado nesta rodada.

## Próximos módulos

1. tornar a janela histórica configurável em um ponto central;
2. atualizar integralmente o pipeline do Experimento I para `Histórico` versus `sem Histórico`;
3. adequar e retreinar o APS com separação temporal ou por trajetórias independentes e três classes finais;
4. implementar análise de sensibilidade dos pesos e parâmetros;
5. implementar o pipeline do Experimento II, Hydros Histórico versus manejo de referência, com água, estresse hídrico, produtividade e eficiência do uso da água;
6. atualizar os artefatos experimentais, documentação e release final.
