# Changelog

## 0.4.1-qualificacao-final - 2026-08-13

- Fechamento técnico do protótipo para a qualificação, sem alteração de pesos, regras agronômicas ou política experimental.
- Registro explícito da propriedade agrícola e da unidade de manejo em cada execução.
- Rejeição de uma execução que misture contextos de unidades de manejo diferentes.
- Registro do tempo de processamento em milissegundos na rastreabilidade e no banco.
- Teste integrado simples para os 13 itens funcionais previstos no Capítulo 6 da tese.

## 0.4.1-audit-checkpointC — 2026-08-13

- corrigida a ambiguidade entre graus-dia do período e soma térmica acumulada;
- `gd` passa a mapear para `soma_termica_acumulada`, conforme a tese;
- criado `graus_dia_periodo` para preservar o incremento térmico por período;
- arquivos legados com `graus_dia` continuam aceitos por normalização automática;
- Aclim, Afen, Ahist, FeatureExtractor, validador e adaptador DSSAT alinhados ao novo contrato;
- APS retreinado com as novas features térmicas, mantendo status científico provisório;
- corrigido o cache da análise de sensibilidade para aplicar ao ARG a mesma separação entre confiança e criticidade usada pelo motor principal;
- configuração-base da sensibilidade agora reproduz 100% das saídas do Hydros Histórico do Experimento I;
- Experimentos I, sensibilidade e II regenerados sem ajuste oportunista de pesos ou regras;
- resultados anteriores do checkpoint B preservados em diretórios `legacy`.


## 0.4.1-audit-checkpointA — 2026-08-13

- alinhada a terminologia da interface para ação determinada e status de processamento;
- centralizados limiares operacionais dos agentes sem alterar valores;
- removida duplicação dos pesos r1-r8 do ARG;
- adicionada validação específica do Checkpoint A;
- resultados científicos e modelos preservados sem recalibração.

## 0.4.0-qualificacao — 2026-08-13

- concluída a validação de software dos Módulos 1 a 7;
- teste de cenários atualizado para validar explicitamente processamento inconclusivo sem converter a ação candidata em ação final;
- validação integral ampliada para Experimento I, sensibilidade e Experimento II;
- documentação técnica, README, protocolo de reprodutibilidade e status atualizados;
- release passa a incluir os resultados atuais dos Experimentos I e II, análise de sensibilidade, APS e relatórios de validação;
- prontidão científica separada da validação de software e mantida como provisória;
- resultados e artefatos anteriores preservados antes da rodada final.


## 12/08/2026 — Módulos 6 e 7

- adicionada análise de sensibilidade com 25 configurações pré-definidas;
- preservados os pesos-base após a análise;
- implementada política operacional I_t = pi(D, I_{t-1}, R_t);
- implementado e executado o Experimento II no par DSSAT compatível atual;
- registrado resultado não favorável do Hydros na trajetória disponível, sem ajuste oportunista de parâmetros;
- adicionados testes de sensibilidade e do Experimento II.
## 12/08/2026 — Módulo 5: APS em três classes

- alvo do APS padronizado em `adequada`, `atencao` e `critica`;
- treinamento cronológico/por grupos sem divisão aleatória de linhas consecutivas;
- auditoria de prontidão científica da base;
- modelo atual marcado como provisório por ausência de trajetórias independentes e da classe crítica em validação/teste;
- artefatos APS anteriores preservados para rollback;
- Experimento I reexecutado e versão anterior preservada;
- novo teste de contrato do treinamento APS.

# Changelog

## Em desenvolvimento — alinhamento da tese — 2026-08-12

- modos canônicos alterados para Histórico e sem Histórico;
- escala das evidências alinhada a adequada, atenção e crítica;
- remoção do fluxo operacional de aceite, modificação e rejeição pelo usuário;
- AMDH pode registrar processamento inconclusivo sem emitir ação conclusiva;
- HydrosOnto oficial incorporada em OWL para verificação semântica e rastreabilidade;
- HydrosOnto removida de qualquer influência sobre o score do AMDH;
- janela histórica centralizada e configurável, mantendo padrão de cinco contextos;
- janela propagada para agentes temporais, ARG e extrator do APS;
- interface Streamlit permite configurar o tamanho da janela;
- APS registra incompatibilidade quando a janela de execução difere da janela de treinamento;
- testes específicos de regressão e configuração da janela adicionados.

## 0.3.0-agentic — 2026-07-23

- contratos padronizados de evidência, decisão e execução;
- rastreabilidade integral;
- completude e qualidade calculadas a partir dos dados;
- exclusão de evidências desativadas no modo Instantâneo;
- AMDH com escores por ação e seleção por `argmax`;
- estado explícito da irrigação;
- HydrosOnto em Turtle e backend semântico leve;
- integração semântica ao ARG;
- segurança de domínio do APS;
- versionamento e hash do modelo preditivo;
- análise contrafactual da influência do APS;
- revisão humana baseada em risco;
- persistência integral e fechamento seguro do SQLite;
- interface para Histórico, Instantâneo e comparação;
- aceite, modificação e rejeição pelo usuário;
- comparação DSSAT atualizada;
- diagnóstico de classes não existentes na referência;
- geração de tabelas, figuras e síntese para o artigo;
- auditoria e congelamento reproduzível da versão.

## 0.2.0

- múltiplos algoritmos supervisionados no APS;
- primeiros testes funcionais e interface inicial.

## 0.1.0

- fluxo inicial de agentes e decisão híbrida.

## 0.4.1-audit-checkpointB
- Separada a confiança dos dados da criticidade das evidências.
- AIEC passa a consumir explicitamente confiança/qualidade dos dados.
- ARG recebe avaliação de completude e confiança independente da severidade.
- Confiança legada preservada apenas para rastreabilidade.
- Inferência Random Forest estabilizada com um worker por chamada, sem alteração do modelo.
- Adicionado teste específico de regressão confiança x criticidade.
- Experimento I e seus diagnósticos regenerados após a correção.
