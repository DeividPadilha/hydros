# Checkpoint C: tempo térmico e retreinamento do APS

Versão: `0.4.1-audit-checkpointC`
Data: 13/08/2026

## Objetivo

Corrigir a ambiguidade da versão anterior em que `graus_dia` continha o incremento térmico do período, enquanto a tese define `gd` como soma térmica acumulada.

## Contrato adotado

- `gd` da tese -> `soma_termica_acumulada`;
- `graus_dia_periodo` -> incremento térmico do período;
- `graus_dia` -> alias legado aceito apenas para compatibilidade de entrada.

Nenhum limiar foi criado para a soma térmica acumulada. O limiar operacional legado de 27 foi mantido associado explicitamente ao incremento térmico do período.

## Alterações realizadas

- normalização central em `src/core/thermal_time.py`;
- motor, validador, interface e adaptador DSSAT passam a normalizar o contrato térmico;
- Aclim e Afen distinguem incremento do período e soma acumulada;
- Afen não transforma o crescimento monotônico da soma acumulada em criticidade automática;
- Ahist preserva a soma acumulada na rastreabilidade sem usá-la de forma não escalada na distância dos vizinhos;
- FeatureExtractor usa `graus_dia_periodo`, `soma_termica_acumulada` e `incremento_termico_janela`;
- base APS e cenários locais ganharam as duas variáveis explícitas;
- APS foi retreinado;
- instâncias da HydrosOnto do estudo de caso foram atualizadas para soma acumulada: P1=18, P2=40, P3=65 e P4=92;
- análise de sensibilidade corrigida para enriquecer Earg com a mesma confiança de dados usada pelo HydrosEngine.

## APS após retreinamento

O Random Forest permanece o algoritmo padrão.

- validação: acurácia 0,9394, F1 macro de três classes 0,5881, MCC 0,7878;
- teste: acurácia 0,9900, F1 macro de três classes 0,6539, MCC 0,9625.

Essas métricas continuam provisórias. A validação e o teste não contêm a classe crítica e a base possui somente uma trajetória independente.

## Experimento I após o checkpoint C

| Modo | Conclusivos | Taxa conclusiva | Acurácia | F1 macro |
|---|---:|---:|---:|---:|
| Histórico | 254/256 | 0,9922 | 0,9492 | 0,1948 |
| sem Histórico | 255/256 | 0,9961 | 0,9531 | 0,1952 |

Houve apenas uma saída diferente entre os modos. Nenhum deles identificou os 11 eventos de referência `iniciar_irrigacao`.

## Sensibilidade

A configuração-base agora reproduz 100% das saídas do Hydros Histórico do Experimento I. Antes da correção, o cache da sensibilidade deixava de aplicar ao ARG o enriquecimento de confiança de dados do checkpoint B.

- estabilidade mínima nas perturbações dos pesos AMDH: 0,992188;
- pesos AIEC: 1,000000 das ações preservadas;
- nenhuma configuração detectou os eventos de intensificação da referência.

## Experimento II

Permanece não favorável ao Hydros na única trajetória pareada atual:

- Hydros Histórico: 0 mm, 3061 kg/ha, 17 períodos com estresse;
- referência: 85 mm, 3114 kg/ha, 2 períodos com estresse.

Nesta versão não ocorreram processamentos inconclusivos na trajetória utilizada pelo Experimento II.

## Validação

Os 24 scripts `test_*.py` foram aprovados no ciclo final. O executor integral chegou a 22 testes antes de atingir o limite global do ambiente de execução desta auditoria; `test_hydros_thermal_time.py` e `test_hydros_traceability.py` foram então executados separadamente e aprovados. Esse limite é externo ao Hydros; cada teste permanece abaixo do timeout individual definido pelo próprio validador.

A prontidão científica continua **provisória**.
