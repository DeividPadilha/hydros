"""Teste funcional de cenários representativos do Hydros.

Os cenários verificam ações representativas após a separação entre criticidade
e confiança. O mecanismo de inconclusão permanece coberto pelos testes específicos
de governança e não depende mais de uma confiança artificialmente baixa em
condições hídricas adequadas.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from src.services.hydros_engine import HydrosEngine

ROOT = Path(__file__).resolve().parent

CENARIOS = {
    "cenario_01_baixa_criticidade.csv": {
        "descricao": (
            "Condição hídrica adequada com dados completos e irrigação ativa"
        ),
        "status_esperado": "conclusivo",
        "acoes_esperadas": ["finalizar_irrigacao"],
    },
    "cenario_02_moderado_manutencao.csv": {
        "descricao": "Condição de atenção com irrigação ativa",
        "status_esperado": "conclusivo",
        "acoes_esperadas": ["manter_irrigacao", "reduzir_irrigacao"],
    },
    "cenario_03_alta_sem_irrigacao.csv": {
        "descricao": "Condição crítica sem irrigação ativa",
        "status_esperado": "conclusivo",
        "acoes_esperadas": ["iniciar_irrigacao"],
    },
    "cenario_04_critico_com_irrigacao_ativa.csv": {
        "descricao": "Condição crítica com irrigação ativa",
        "status_esperado": "conclusivo",
        "acoes_esperadas": ["aumentar_irrigacao"],
    },
}


def executar_cenario(nome_arquivo: str, configuracao: dict) -> bool:
    caminho = ROOT / "data" / "cenarios_teste" / nome_arquivo
    df = pd.read_csv(caminho)
    resultados = HydrosEngine().executar(df)

    amdh = resultados["amdh"]
    acao = amdh["D(Ui)"]
    status = amdh["status_processamento"]
    acao_candidata = amdh.get("acao_candidata")

    passou_status = status == configuracao["status_esperado"]
    if status == "inconclusivo":
        passou_acao = acao is configuracao.get("acao_esperada")
        passou_candidata = (
            acao_candidata == configuracao.get("acao_candidata_esperada")
        )
        passou = passou_status and passou_acao and passou_candidata
    else:
        passou = passou_status and acao in configuracao["acoes_esperadas"]

    print("\n----------------------------------------")
    print(f"Cenário: {nome_arquivo}")
    print(f"Descrição: {configuracao['descricao']}")
    print(f"Status esperado: {configuracao['status_esperado']}")
    print(f"Status obtido: {status}")
    print(f"Ação obtida: {acao}")
    if status == "inconclusivo":
        print(f"Ação candidata: {acao_candidata}")
        print(f"Motivos: {amdh.get('motivos_inconclusao', [])}")
    print(f"Ehc: {resultados['aiec']['Ehc']}")
    print(f"Earg: {resultados['arg']['Earg']}")
    print(f"Eaps: {resultados['aps']['Eaps']}")
    print(f"Score: {amdh['score_hibrido']}")
    print("Status do teste: OK" if passou else "Status do teste: FALHOU")
    return passou


def main() -> None:
    print("\n=== TESTE DE CENÁRIOS DO HYDROS ===")
    resultados = [
        executar_cenario(nome, configuracao)
        for nome, configuracao in CENARIOS.items()
    ]
    aprovados = sum(resultados)
    total = len(resultados)

    print("\n========================================")
    print(f"Cenários aprovados: {aprovados}/{total}")
    if aprovados != total:
        raise AssertionError(
            f"Validação de cenários falhou: {aprovados}/{total} aprovados."
        )
    print("Resultado geral: TODOS OS CENÁRIOS FUNCIONAIS ESTÃO COERENTES")


if __name__ == "__main__":
    main()
