"""Verifica se a versão atual está pronta para auditoria e congelamento."""

from __future__ import annotations

import json
from pathlib import Path

from src.config.hydros_terms import VERSAO_ARQUITETURA

ROOT = Path(__file__).resolve().parent
EXPECTED_VERSION = "0.4.1-qualificacao-final"

REQUIRED = [
    "README.md",
    "STATUS_HYDROS.md",
    "DOCUMENTACAO_CODIGO_HYDROS.md",
    "REPRODUCIBILITY.md",
    "CHANGELOG.md",
    "requirements.txt",
    "ontology/hydrosonto.owl",
    "src/ontology/hydros_onto.py",
    "src/core/contracts.py",
    "src/core/evidence_quality.py",
    "src/core/irrigation_state.py",
    "src/core/thermal_time.py",
    "src/services/hydros_engine.py",
    "src/services/interface_adapter.py",
    "src/integrations/dssat_adapter.py",
    "src/evaluation/irrigation_policy.py",
    "src/models/aps_model_metadata.json",
    "run_experimento_1.py",
    "run_sensibilidade.py",
    "run_experimento_2.py",
    "diagnostico_resultados.py",
    "run_hydros_validation.py",
    "freeze_hydros_release.py",
    "results/experimento_1/metricas_resumo.csv",
    "results/modulo_6_sensibilidade/resumo_sensibilidade.csv",
    "results/experimento_2/metricas_experimento_2.csv",
    "results/aps_modulo5/prontidao_cientifica.json",
]


def main() -> None:
    missing = [relative for relative in REQUIRED if not (ROOT / relative).exists()]
    if missing:
        raise AssertionError("Arquivos ausentes: " + ", ".join(missing))

    if VERSAO_ARQUITETURA != EXPECTED_VERSION:
        raise AssertionError(
            f"Versão inesperada: {VERSAO_ARQUITETURA}; esperado {EXPECTED_VERSION}."
        )

    metadata = json.loads(
        (ROOT / "src/models/aps_model_metadata.json").read_text(encoding="utf-8")
    )
    if metadata.get("scientific_status") not in {
        "modelo_tres_classes_apto_avaliacao",
        "modelo_tres_classes_provisorio_requer_cenarios_independentes",
    }:
        raise AssertionError("O status científico do APS não está governado.")
    if metadata.get("target_schema") != ["adequada", "atencao", "critica"]:
        raise AssertionError("O APS não utiliza o esquema canônico de três classes.")
    thermal_contract = metadata.get("thermal_time_contract", {})
    if thermal_contract.get("canonical") != "soma_termica_acumulada":
        raise AssertionError("O APS não registra a soma térmica acumulada como campo canônico.")

    exp2 = json.loads(
        (ROOT / "results/experimento_2/status_experimento_2.json").read_text(
            encoding="utf-8"
        )
    )
    if "result_favorable" not in exp2 or "scientific_scope" not in exp2:
        raise AssertionError("O escopo científico do Experimento II não foi registrado.")

    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    required_phrases = [
        "Hydros Histórico",
        "Hydros sem Histórico",
        "benchmark de simulação",
        "não aciona fisicamente",
        "prova de conceito",
        "prontidão científica",
        "não favorável ao Hydros",
    ]
    absent = [phrase for phrase in required_phrases if phrase not in readme]
    if absent:
        raise AssertionError("Conceitos ausentes no README: " + ", ".join(absent))

    print("\n=== PRONTIDÃO PARA RELEASE ===")
    print(f"Versão: {VERSAO_ARQUITETURA}")
    print(f"Arquivos obrigatórios: {len(REQUIRED)}")
    print("APS: status científico registrado")
    print("Experimento II: escopo e resultado registrados")
    print("Limitações: documentadas")
    print("PRONTIDÃO PARA RELEASE DE SOFTWARE: OK")


if __name__ == "__main__":
    main()
