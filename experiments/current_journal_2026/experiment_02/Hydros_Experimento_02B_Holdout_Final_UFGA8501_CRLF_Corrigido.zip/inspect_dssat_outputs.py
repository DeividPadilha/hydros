"""Inventaria cabeçalhos e blocos dos .OUT produzidos por uma execução DSSAT.

Uso local após uma simulação:
    python inspect_dssat_outputs.py --output-dir "C:\\DSSAT48\\Soybean"

Nenhum campo é convertido para Hydros neste passo. O objetivo é capturar a
proveniência real dos nomes de colunas antes de implementar a ponte semântica.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from src.evaluation.dssat_output_parser import (
    DSSATOutputParseError,
    inventory_dssat_output_file,
)

BASE = Path(__file__).resolve().parent
RESULT_DIR = BASE / "results" / "experimento_2b"

PREFERRED = (
    "SoilWat.OUT",
    "SoilWater.OUT",
    "PlantGro.OUT",
    "Summary.OUT",
    "Weather.OUT",
    "ET.OUT",
    "Evaluate.OUT",
    "MgmtEvents.OUT",
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=RESULT_DIR / "inventario_outputs_dssat.json")
    args = parser.parse_args()

    output_dir = args.output_dir.resolve()
    if not output_dir.is_dir():
        raise SystemExit(f"Diretório inexistente: {output_dir}")

    files: list[Path] = []
    seen = set()
    for name in PREFERRED:
        p = output_dir / name
        if p.is_file():
            files.append(p)
            seen.add(p.name.lower())
    for p in sorted(output_dir.glob("*.OUT")):
        if p.name.lower() not in seen:
            files.append(p)

    inventory: dict[str, object] = {
        "output_directory": str(output_dir),
        "files_found": len(files),
        "files": [],
        "parse_errors": [],
    }
    for p in files:
        try:
            inventory["files"].append(inventory_dssat_output_file(p))
        except (DSSATOutputParseError, OSError) as exc:
            inventory["parse_errors"].append({"file": p.name, "error": str(exc)})

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(inventory, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(inventory, indent=2, ensure_ascii=False))
    return 0 if files else 2


if __name__ == "__main__":
    raise SystemExit(main())
