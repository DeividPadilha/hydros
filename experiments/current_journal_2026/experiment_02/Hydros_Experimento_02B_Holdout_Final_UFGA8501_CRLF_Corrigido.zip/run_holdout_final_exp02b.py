"""Executa o holdout final HYDROS-EXP02B em UFGA8501.

Este script deve ser executado UMA ÚNICA VEZ depois do congelamento da versão.
Ele implementa exatamente o desenho pré-registrado v2:

* ambos os ramos usam o tratamento-base 2 do UFGA8501;
* referência: programação oficial de irrigação MI=1 transplantada para MI=2;
* Hydros: prefixo fixo comum (85172/13 mm e 85175/10 mm), seguido de
  ciclo fechado C(t) -> Hydros -> manejo(t+1) -> nova simulação DSSAT;
* nenhuma calibração é feita a partir do resultado do holdout.

Uso:
    python run_holdout_final_exp02b.py --dssat-root "C:\\DSSAT48"
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import asdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import statistics

import pandas as pd

from src.evaluation.dssat_cli import DSSATCommandConfig, run_dssat_command
from src.evaluation.dssat_hydros_mapping import build_hydros_context_from_dssat_outputs
from src.evaluation.dssat_sbx_schedule import (
    IrrigationEvent,
    extract_irrigation_events,
    extract_treatment_irrigation_events,
    get_treatment_factor_level,
    replace_irrigation_events,
)
from src.evaluation.irrigation_policy import IrrigationActionPolicy, IrrigationPolicyConfig
from src.services.hydros_engine import HydrosEngine

ROOT = Path(__file__).resolve().parent
RESULT_ROOT = ROOT / "results" / "experimento_2b" / "holdout_final_ufga8501"
PRE_REG = ROOT / "results" / "experimento_2b" / "pre_registro_experimento_02b_v2.json"
MANIFEST = ROOT / "results" / "experimento_2b" / "manifesto_holdout_ufga8501.json"
EXPECTED_OFFICIAL_SHA256 = "9262220adef9d76061f0f8ae6f8394466e13537485382d5aef76fba0d897bda0"
EXP_CODE = "UFGA8501"
REFERENCE_TMP = "H85REF.SBX"
HYDROS_TMP = "H85HYD.SBX"
BASE_TREATMENT = 2
CONTROL_DAP_MIN = 20  # política congelada nos cenários de desenvolvimento


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text_normalized(path: Path) -> str:
    """Hash semântico do arquivo DSSAT, normalizando apenas finais de linha.

    O repositório oficial usa LF, enquanto instalações Windows podem materializar
    o mesmo texto com CRLF. Essa normalização NÃO altera espaços internos, campos
    de largura fixa, valores ou comentários do arquivo .SBX.
    """
    data = path.read_bytes().replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    return hashlib.sha256(data).hexdigest()


def yyyymmdd_to_yyddd(value: str) -> int:
    dt = pd.to_datetime(str(value))
    return int(f"{dt.year % 100:02d}{dt.dayofyear:03d}")


def policy_from_reference_events(events: list[IrrigationEvent]) -> IrrigationPolicyConfig:
    amounts = sorted(float(e.amount_mm) for e in events if float(e.amount_mm) > 0)
    if not amounts:
        raise ValueError("Programação de referência não possui eventos de irrigação.")
    unique = sorted(set(amounts))
    diffs = [b - a for a, b in zip(unique, unique[1:]) if b > a]
    step = statistics.median(diffs) if diffs else max(statistics.median(amounts) * 0.10, 1.0)
    return IrrigationPolicyConfig(
        base_mm=float(statistics.median(amounts)),
        step_mm=float(step),
        min_mm=float(min(amounts)),
        max_mm=float(max(amounts)),
        inconclusive_policy="sem_aplicacao",
        provenance="eventos_brutos_MI1_UFGA8501_pre_registrados_antes_do_holdout",
    )


def run_dssat(exe: Path, experiment: Path, treatment: int) -> None:
    completed = run_dssat_command(
        DSSATCommandConfig(
            executable=exe,
            experiment_file=experiment,
            treatment=int(treatment),
            working_directory=experiment.parent,
            timeout_seconds=240,
        )
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"DSSAT falhou em {experiment.name} T{treatment}: "
            f"returncode={completed.returncode}\n{completed.stderr or ''}"
        )


def copy_outs(source_dir: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=False)
    files = sorted(source_dir.glob("*.OUT"))
    if not files:
        raise RuntimeError(f"Nenhum .OUT encontrado em {source_dir}")
    for source in files:
        shutil.copy2(source, destination / source.name)


def contexts_from_outputs(soybean: Path, scenario_id: str) -> pd.DataFrame:
    return build_hydros_context_from_dssat_outputs(soybean, scenario_id=scenario_id)


def aligned_weather_check(reference: pd.DataFrame, current: pd.DataFrame, until_date: str | None = None) -> dict:
    cols = ["data", "precipitacao", "temp_maxima", "temp_minima"]
    a = reference[cols].copy()
    b = current[cols].copy()
    if until_date is not None:
        a = a[pd.to_datetime(a["data"]) <= pd.to_datetime(until_date)]
        b = b[pd.to_datetime(b["data"]) <= pd.to_datetime(until_date)]
    merged = a.merge(b, on="data", suffixes=("_ref", "_cur"), how="inner")
    if merged.empty:
        return {"same_weather": False, "reason": "sem_datas_comuns", "n_common": 0}
    max_diff = {}
    for col in cols[1:]:
        diff = (
            pd.to_numeric(merged[f"{col}_ref"], errors="coerce")
            - pd.to_numeric(merged[f"{col}_cur"], errors="coerce")
        ).abs()
        max_diff[col] = float(diff.max())
    return {
        "same_weather": all(v <= 1e-9 for v in max_diff.values()),
        "n_common": int(len(merged)),
        "reference_rows": int(len(a)),
        "current_rows": int(len(b)),
        "max_abs_diff": max_diff,
        "common_start": str(merged["data"].iloc[0]),
        "common_end": str(merged["data"].iloc[-1]),
    }


def summarize_contexts(contexts: pd.DataFrame, *, dap_min: int = CONTROL_DAP_MIN) -> dict:
    control = contexts[contexts["dap"] >= int(dap_min)].copy()
    stress = pd.to_numeric(control["dssat_estresse_max"], errors="coerce").fillna(0.0)
    final = contexts.iloc[-1]
    eff = float(pd.to_numeric(contexts["irrigacao_aplicada"], errors="coerce").fillna(0.0).sum())
    yld = float(final["dssat_GWAD_kg_ha"])
    return {
        "n_rows": int(len(contexts)),
        "n_control_dap_ge_20": int(len(control)),
        "effective_irrigation_mm": round(eff, 6),
        "yield_GWAD_final_kg_ha": round(yld, 6),
        "irrigation_water_productivity_kg_ha_mm": round(yld / eff, 6) if eff > 0 else None,
        "stress_days_ge_0_25_control": int((stress >= 0.25).sum()),
        "stress_sum_control": round(float(stress.sum()), 6),
        "drainage_final_mm": round(float(final["dssat_drenagem_cumulativa_mm"]), 6),
        "final_date": str(final["data"]),
    }


def decision_trace_row(contexts: pd.DataFrame, engine: HydrosEngine) -> tuple[str | None, dict]:
    result = engine.processar(contexts, modo_execucao="historico", propriedade_id="UF_Gainesville")
    amdh = result["amdh"]
    action = amdh.get("D(Ui)")
    return action, {
        "status": amdh.get("status_processamento"),
        "motivos_inconclusao": list(amdh.get("motivos_inconclusao", [])),
        "Ehid": result["ahid"].get("Ehid"),
        "Ehc": result["aiec"].get("Ehc"),
        "Earg": result["arg"].get("Earg"),
        "Eaps": result["aps"].get("Eaps"),
        "aps_status_dominio": result["aps"].get("status_dominio"),
        "confianca": amdh.get("confianca"),
        "indice_conflito": amdh.get("indice_conflito"),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dssat-root", type=Path, required=True)
    args = parser.parse_args()

    dssat_root = args.dssat_root.resolve()
    exe = dssat_root / "DSCSM048.EXE"
    soybean = dssat_root / "Soybean"
    source = soybean / "UFGA8501.SBX"
    if not exe.exists():
        raise FileNotFoundError(exe)
    if not source.exists():
        raise FileNotFoundError(source)
    if not PRE_REG.exists() or not MANIFEST.exists():
        raise RuntimeError("Pré-registro/manifesto do holdout ausente. Não execute o teste final.")

    actual_hash_raw = sha256_file(source)
    actual_hash = sha256_text_normalized(source)
    if actual_hash.lower() != EXPECTED_OFFICIAL_SHA256.lower():
        raise RuntimeError(
            "UFGA8501.SBX instalado não corresponde semanticamente ao fixture congelado. "
            f"Esperado(normalizado) {EXPECTED_OFFICIAL_SHA256}; "
            f"obtido(normalizado) {actual_hash}; bruto {actual_hash_raw}."
        )

    text = source.read_text(encoding="utf-8")
    t2_level = get_treatment_factor_level(text, BASE_TREATMENT, "MI")
    if t2_level != 2:
        raise RuntimeError(f"Contrato pré-registrado esperava MI=2 no tratamento 2; obtido MI={t2_level}.")
    ref_events = extract_irrigation_events(text, 1)
    prefix = extract_irrigation_events(text, 2)
    expected_prefix = [(85172, 13.0), (85175, 10.0)]
    actual_prefix = [(int(e.date_code), float(e.amount_mm)) for e in prefix]
    if actual_prefix != expected_prefix:
        raise RuntimeError(f"Prefixo do holdout mudou: {actual_prefix}")
    if round(sum(float(e.amount_mm) for e in ref_events), 6) != 217.0:
        raise RuntimeError("Programação de referência congelada não totaliza 217 mm brutos.")

    policy_config = policy_from_reference_events(ref_events)
    ref_tmp = soybean / REFERENCE_TMP
    hyd_tmp = soybean / HYDROS_TMP
    for temp in (ref_tmp, hyd_tmp):
        if temp.exists():
            raise RuntimeError(f"Arquivo temporário já existe: {temp}. Remova somente se for de execução anterior deste experimento.")

    RESULT_ROOT.mkdir(parents=True, exist_ok=False)
    frozen = {
        "experiment": "HYDROS-EXP02B HOLDOUT FINAL",
        "protocol_id": "HYDROS-EXP02B-2026-08-14-v2",
        "holdout": EXP_CODE,
        "official_source_sha256_normalized": actual_hash,
        "official_source_sha256_raw": actual_hash_raw,
        "base_treatment_both_branches": BASE_TREATMENT,
        "mi_level_both_branches": t2_level,
        "reference_events": [asdict(e) for e in ref_events],
        "hydros_fixed_prefix": [asdict(e) for e in prefix],
        "policy": policy_config.to_dict(),
        "control_dap_min": CONTROL_DAP_MIN,
        "no_post_holdout_calibration": True,
        "started_at": datetime.now().isoformat(timespec="seconds"),
    }
    (RESULT_ROOT / "FREEZE_BEFORE_HOLDOUT.json").write_text(
        json.dumps(frozen, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    try:
        # REFERÊNCIA: tratamento 2 com programação MI=1 transplantada para MI=2.
        ref_text = replace_irrigation_events(text, level=t2_level, events=ref_events)
        ref_tmp.write_text(ref_text, encoding="utf-8", newline="\n")
        run_dssat(exe, ref_tmp, BASE_TREATMENT)
        reference = contexts_from_outputs(soybean, "UFGA8501_reference_T2_same_base")
        copy_outs(soybean, RESULT_ROOT / "reference_OUT")
        reference.to_csv(RESULT_ROOT / "reference_contexts.csv", index=False)

        # HYDROS seed: mesmo tratamento 2, apenas prefixo fixo MI=2.
        schedule: dict[int, float] = {int(e.date_code): float(e.amount_mm) for e in prefix}
        hyd_text = replace_irrigation_events(text, level=t2_level, events=prefix)
        hyd_tmp.write_text(hyd_text, encoding="utf-8", newline="\n")
        run_dssat(exe, hyd_tmp, BASE_TREATMENT)
        current = contexts_from_outputs(soybean, "UFGA8501_Hydros_seed")
        baseline = current.copy()
        baseline.to_csv(RESULT_ROOT / "candidate_seed_contexts.csv", index=False)

        # Mesma regra congelada de desenvolvimento: DAP >= 20 e sempre após o prefixo.
        candidates = baseline.index[baseline["dap"] >= CONTROL_DAP_MIN].tolist()
        if not candidates:
            raise RuntimeError("Nenhum período com DAP >= 20.")
        control_start = int(candidates[0])
        last_prefix = max(int(e.date_code) for e in prefix)
        idx_after_prefix = [
            int(i) for i, d in enumerate(baseline["data"]) if yyyymmdd_to_yyddd(d) >= last_prefix
        ]
        if idx_after_prefix:
            control_start = max(control_start, idx_after_prefix[0])
        control_dates = list(baseline["data"].iloc[control_start:].astype(str))
        if len(control_dates) < 2:
            raise RuntimeError("Horizonte de controle insuficiente.")

        policy = IrrigationActionPolicy(policy_config)
        start_code = yyyymmdd_to_yyddd(control_dates[0])
        policy.set_previous_mm(float(schedule.get(start_code, 0.0)))
        engine = HydrosEngine(modo_execucao="historico")
        trace: list[dict] = []
        n_dssat_runs_candidate = 1

        for pos in range(len(control_dates) - 1):
            current_date = control_dates[pos]
            next_date = control_dates[pos + 1]
            matched = current.index[current["data"].astype(str) == current_date].tolist()
            if not matched:
                trace.append({"data_contexto": current_date, "status": "controle_encerrado_data_ausente"})
                break
            idx = int(matched[0])
            history = current.iloc[: idx + 1].copy().reset_index(drop=True)
            action, meta = decision_trace_row(history, engine)
            planned_gross = float(policy.apply(action))
            next_code = yyyymmdd_to_yyddd(next_date)
            previous = float(schedule.get(next_code, 0.0))
            schedule[next_code] = planned_gross
            rerun = abs(previous - planned_gross) > 1e-9

            if rerun:
                events = [IrrigationEvent(code, mm) for code, mm in sorted(schedule.items()) if mm > 0]
                hyd_text = replace_irrigation_events(text, level=t2_level, events=events)
                hyd_tmp.write_text(hyd_text, encoding="utf-8", newline="\n")
                run_dssat(exe, hyd_tmp, BASE_TREATMENT)
                n_dssat_runs_candidate += 1
                new_current = contexts_from_outputs(soybean, "UFGA8501_Hydros_closed_loop")
                weather = aligned_weather_check(baseline, new_current, until_date=next_date)
                if not weather["same_weather"]:
                    raise RuntimeError(f"Clima mudou até {next_date}: {weather}")
                next_match = new_current.index[new_current["data"].astype(str) == next_date].tolist()
                if not next_match:
                    raise RuntimeError(f"Trajetória não alcançou {next_date}.")
                sim_eff = float(new_current.iloc[int(next_match[0])]["irrigacao_aplicada"])
                if planned_gross > 0 and sim_eff <= 0:
                    raise RuntimeError(f"DSSAT não registrou irrigação em {next_date} para {planned_gross} mm brutos.")
                if planned_gross <= 0 and sim_eff > 1e-9:
                    raise RuntimeError(f"DSSAT registrou irrigação não planejada em {next_date}: {sim_eff} mm.")
                current = new_current
            else:
                sim_match = current.index[current["data"].astype(str) == next_date].tolist()
                sim_eff = float(current.iloc[int(sim_match[0])]["irrigacao_aplicada"]) if sim_match else None

            row_now = history.iloc[-1]
            trace.append({
                "data_contexto_t": current_date,
                "data_manejo_t_mais_1": next_date,
                "DAP_t": int(row_now["dap"]),
                "stress_dssat_t": float(row_now["dssat_estresse_max"]),
                "umidade_solo_t": float(row_now["umidade_solo"]),
                "agua_disponivel_t": float(row_now["agua_disponivel"]),
                "acao": action,
                "irrigacao_bruta_planejada_t_mais_1_mm": round(planned_gross, 6),
                "irrigacao_efetiva_simulada_t_mais_1_mm": None if sim_eff is None else round(float(sim_eff), 6),
                "dssat_reexecutado": bool(rerun),
                **meta,
            })

        # Execução terminal do manejo congelado.
        events = [IrrigationEvent(code, mm) for code, mm in sorted(schedule.items()) if mm > 0]
        hyd_text = replace_irrigation_events(text, level=t2_level, events=events)
        hyd_tmp.write_text(hyd_text, encoding="utf-8", newline="\n")
        run_dssat(exe, hyd_tmp, BASE_TREATMENT)
        n_dssat_runs_candidate += 1
        final_candidate = contexts_from_outputs(soybean, "UFGA8501_Hydros_final")
        copy_outs(soybean, RESULT_ROOT / "hydros_OUT")
        final_candidate.to_csv(RESULT_ROOT / "hydros_contexts.csv", index=False)
        trace_df = pd.DataFrame(trace)
        trace_df.to_csv(RESULT_ROOT / "trace_closed_loop.csv", index=False)

        ref_summary = summarize_contexts(reference)
        hyd_summary = summarize_contexts(final_candidate)
        weather_final = aligned_weather_check(reference, final_candidate)
        gross_ref = round(sum(float(e.amount_mm) for e in ref_events), 6)
        gross_hyd = round(sum(float(v) for v in schedule.values()), 6)
        eff_ref = float(ref_summary["effective_irrigation_mm"])
        eff_hyd = float(hyd_summary["effective_irrigation_mm"])
        y_ref = float(ref_summary["yield_GWAD_final_kg_ha"])
        y_hyd = float(hyd_summary["yield_GWAD_final_kg_ha"])

        actions = Counter(trace_df.get("acao", pd.Series(dtype=str)).fillna("<null>"))
        domain = Counter(trace_df.get("aps_status_dominio", pd.Series(dtype=str)).fillna("<null>"))

        result = {
            "experiment": "HYDROS-EXP02B HOLDOUT FINAL",
            "protocol_id": "HYDROS-EXP02B-2026-08-14-v2",
            "holdout": EXP_CODE,
            "reference_same_base_T2": ref_summary,
            "hydros_same_base_T2": hyd_summary,
            "gross_irrigation_reference_mm": gross_ref,
            "gross_irrigation_hydros_mm": gross_hyd,
            "gross_water_saving_mm": round(gross_ref - gross_hyd, 6),
            "gross_water_saving_pct": round(100.0 * (gross_ref - gross_hyd) / gross_ref, 6) if gross_ref > 0 else None,
            "effective_water_saving_mm": round(eff_ref - eff_hyd, 6),
            "effective_water_saving_pct": round(100.0 * (eff_ref - eff_hyd) / eff_ref, 6) if eff_ref > 0 else None,
            "yield_delta_kg_ha": round(y_hyd - y_ref, 6),
            "yield_retention_pct": round(100.0 * y_hyd / y_ref, 6) if y_ref > 0 else None,
            "stress_days_delta": int(hyd_summary["stress_days_ge_0_25_control"] - ref_summary["stress_days_ge_0_25_control"]),
            "stress_sum_delta": round(float(hyd_summary["stress_sum_control"] - ref_summary["stress_sum_control"]), 6),
            "drainage_delta_mm": round(float(hyd_summary["drainage_final_mm"] - ref_summary["drainage_final_mm"]), 6),
            "irrigation_water_productivity_delta_kg_ha_mm": (
                None if ref_summary["irrigation_water_productivity_kg_ha_mm"] is None or hyd_summary["irrigation_water_productivity_kg_ha_mm"] is None
                else round(float(hyd_summary["irrigation_water_productivity_kg_ha_mm"] - ref_summary["irrigation_water_productivity_kg_ha_mm"]), 6)
            ),
            "weather_overlap": weather_final,
            "actions": {str(k): int(v) for k, v in actions.items()},
            "aps_domain": {str(k): int(v) for k, v in domain.items()},
            "n_dssat_runs_hydros_branch": int(n_dssat_runs_candidate),
            "control_start_date": control_dates[0],
            "control_end_date_seed": control_dates[-1],
            "control_dap_min": CONTROL_DAP_MIN,
            "descriptive_checks": {
                "water_saving_positive": bool(eff_ref - eff_hyd > 0),
                "yield_retention_ge_95pct": bool(y_ref > 0 and 100.0 * y_hyd / y_ref >= 95.0),
                "weather_unchanged_on_overlap": bool(weather_final.get("same_weather", False)),
                "stress_days_not_increased": bool(hyd_summary["stress_days_ge_0_25_control"] <= ref_summary["stress_days_ge_0_25_control"]),
                "stress_sum_not_increased": bool(hyd_summary["stress_sum_control"] <= ref_summary["stress_sum_control"]),
            },
            "post_holdout_calibration_allowed": False,
            "finished_at": datetime.now().isoformat(timespec="seconds"),
        }
        (RESULT_ROOT / "RESULTADO_FINAL_HOLDOUT_UFGA8501.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        (RESULT_ROOT / "schedule_hydros_final.json").write_text(
            json.dumps({str(k): v for k, v in sorted(schedule.items())}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

        print(json.dumps(result, ensure_ascii=False, indent=2))
        print(f"\nResultado final gravado em: {RESULT_ROOT / 'RESULTADO_FINAL_HOLDOUT_UFGA8501.json'}")
        print("IMPORTANTE: o holdout foi aberto. Não recalibrar o Hydros a partir deste resultado.")
        return 0
    finally:
        for temp in (ref_tmp, hyd_tmp):
            if temp.exists():
                temp.unlink()


if __name__ == "__main__":
    raise SystemExit(main())
