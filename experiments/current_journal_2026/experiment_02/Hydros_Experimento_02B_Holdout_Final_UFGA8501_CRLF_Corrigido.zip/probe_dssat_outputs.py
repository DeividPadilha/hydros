"""Executa uma simulação DSSAT de diagnóstico e captura os arquivos .OUT.

Este utilitário NÃO executa o holdout Hydros e NÃO calibra parâmetros. Use de
preferência um experimento legado/de desenvolvimento, por exemplo UFGA7901,
apenas para validar o contrato de linha de comando e descobrir os cabeçalhos
reais dos arquivos de saída da instalação DSSAT local.
"""

from __future__ import annotations

import argparse
from datetime import datetime
import json
from pathlib import Path
import shutil

from src.evaluation.dssat_cli import DSSATCommandConfig, run_dssat_command
from src.evaluation.dssat_output_parser import (
    DSSATOutputParseError,
    inventory_dssat_output_file,
)

BASE = Path(__file__).resolve().parent
RESULT_ROOT = BASE / "results" / "experimento_2b" / "dssat_probe"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--exe", type=Path, required=True)
    parser.add_argument("--experiment", type=Path, required=True)
    parser.add_argument("--treatment", type=int, default=2)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--label", default="diagnostico")
    args = parser.parse_args()

    experiment = args.experiment.resolve()
    config = DSSATCommandConfig(
        executable=args.exe.resolve(),
        experiment_file=experiment,
        treatment=args.treatment,
        working_directory=experiment.parent,
        timeout_seconds=args.timeout,
    )
    completed = run_dssat_command(config)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    destination = RESULT_ROOT / f"{args.label}_{experiment.stem}_T{args.treatment}_{stamp}"
    destination.mkdir(parents=True, exist_ok=False)

    (destination / "stdout.txt").write_text(completed.stdout or "", encoding="utf-8")
    (destination / "stderr.txt").write_text(completed.stderr or "", encoding="utf-8")

    inventory: dict[str, object] = {
        "experiment": str(experiment),
        "treatment": int(args.treatment),
        "returncode": int(completed.returncode),
        "output_source_directory": str(experiment.parent),
        "captured_directory": str(destination),
        "files": [],
        "parse_errors": [],
    }

    for source in sorted(experiment.parent.glob("*.OUT")):
        target = destination / source.name
        shutil.copy2(source, target)
        try:
            inventory["files"].append(inventory_dssat_output_file(target))
        except (DSSATOutputParseError, OSError) as exc:
            inventory["parse_errors"].append({"file": target.name, "error": str(exc)})

    (destination / "inventario_outputs_dssat.json").write_text(
        json.dumps(inventory, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(inventory, indent=2, ensure_ascii=False))
    return 0 if completed.returncode == 0 else completed.returncode or 1


if __name__ == "__main__":
    raise SystemExit(main())
