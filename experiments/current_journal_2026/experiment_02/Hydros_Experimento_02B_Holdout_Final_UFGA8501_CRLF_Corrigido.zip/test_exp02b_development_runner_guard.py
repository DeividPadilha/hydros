import run_desenvolvimento_exp02b_v3 as runner


def test_holdout_nao_esta_na_lista_de_desenvolvimento():
    assert runner.HOLDOUT_FORBIDDEN == "UFGA8501"
    assert runner.HOLDOUT_FORBIDDEN not in runner.DEVELOPMENT_EXPERIMENTS
    assert set(runner.DEVELOPMENT_EXPERIMENTS) == {"UFGA7801", "UFGA8401"}
