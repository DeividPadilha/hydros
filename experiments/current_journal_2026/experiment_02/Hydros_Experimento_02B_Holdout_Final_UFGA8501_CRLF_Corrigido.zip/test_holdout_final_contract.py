from pathlib import Path
import hashlib

from run_holdout_final_exp02b import sha256_text_normalized

from src.evaluation.dssat_sbx_schedule import (
    extract_irrigation_events,
    get_treatment_factor_level,
    replace_irrigation_events,
)

ROOT = Path(__file__).resolve().parent
FIXTURE = ROOT / 'results' / 'experimento_2b' / 'official_UFGA8501.SBX'
EXPECTED = '9262220adef9d76061f0f8ae6f8394466e13537485382d5aef76fba0d897bda0'


def test_holdout_fixture_hash_and_contract():
    assert sha256_text_normalized(FIXTURE) == EXPECTED
    text = FIXTURE.read_text(encoding='utf-8')
    assert get_treatment_factor_level(text, 2, 'MI') == 2
    ref = extract_irrigation_events(text, 1)
    prefix = extract_irrigation_events(text, 2)
    assert round(sum(e.amount_mm for e in ref), 6) == 217.0
    assert [(e.date_code, e.amount_mm) for e in prefix] == [(85172, 13.0), (85175, 10.0)]
    replaced = replace_irrigation_events(text, level=2, events=ref)
    copied = extract_irrigation_events(replaced, 2)
    assert [(e.date_code, e.amount_mm) for e in copied] == [(e.date_code, e.amount_mm) for e in ref]


def test_holdout_hash_accepts_windows_crlf(tmp_path):
    source = FIXTURE.read_bytes()
    win = tmp_path / "UFGA8501.SBX"
    win.write_bytes(source.replace(b"\n", b"\r\n"))
    assert hashlib.sha256(win.read_bytes()).hexdigest() != EXPECTED
    assert sha256_text_normalized(win) == EXPECTED
