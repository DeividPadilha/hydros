from run_closed_loop_desenvolvimento_exp02b_v4 import (
    longest_common_prefix,
    policy_from_reference_events,
    yyyymmdd_to_yyddd,
)
from src.evaluation.dssat_sbx_schedule import IrrigationEvent


def test_date_conversion_to_dssat_yyddd():
    assert yyyymmdd_to_yyddd("1985/06/21") == 85172


def test_common_prefix_stops_at_first_divergence():
    a = [IrrigationEvent(85172, 13), IrrigationEvent(85175, 10), IrrigationEvent(85200, 12)]
    b = [IrrigationEvent(85172, 13), IrrigationEvent(85175, 10), IrrigationEvent(85210, 8)]
    prefix = longest_common_prefix(a, b)
    assert [(e.date_code, e.amount_mm) for e in prefix] == [(85172, 13), (85175, 10)]


def test_policy_is_derived_only_from_reference_events():
    events = [IrrigationEvent(85172, 10), IrrigationEvent(85180, 20), IrrigationEvent(85190, 30)]
    cfg = policy_from_reference_events(events)
    assert cfg.base_mm == 20.0
    assert cfg.step_mm == 10.0
    assert cfg.min_mm == 10.0
    assert cfg.max_mm == 30.0
