# Preservação da Entrega 6 e 7

Entrada utilizada: `hydros_entrega_5_aps_tres_classes.zip`

SHA-256 da entrada:

`4e1bd6c16fbaf7b6dcad886d448f46cedd3f7fd77843861bb6aab019507f8d52`

Foi realizada comparação direta entre a árvore da Entrega 5 e a árvore desta entrega. Os arquivos existentes de `src/`, `data/`, `ontology/` e dos resultados anteriores permaneceram inalterados. As diferenças são somente novos módulos de avaliação, novos testes, novos relatórios e atualização dos arquivos de status/changelog.

Hashes de dois artefatos anteriores conferidos após os Módulos 6 e 7:

- `results/experimento_1/metricas_resumo.csv`: `ff6b8de4373d8569ee8bb7f9b17a4c176aa410105d84930446aef10c754ffd63`
- `results/aps_modulo5/prontidao_cientifica.json`: `8cf9d95b30e06d6d69060b5a0b7fd77fe970c02f28ccd0951164973dfbd25b62`

Nenhum resultado anterior foi sobrescrito pelos Módulos 6 e 7.
