# Módulo 7 — Experimento II: efeito do Hydros no gerenciamento hídrico

Data: 12/08/2026

## Ponto de retorno

A Entrega 5 e todos os resultados dos módulos anteriores permanecem preservados. O Módulo 7 adiciona apenas componentes de avaliação e um novo diretório de resultados.

## Objetivo

Comparar Hydros Histórico com um manejo de referência em indicadores ligados diretamente ao gerenciamento hídrico: água de irrigação, produtividade, ocorrência e intensidade de estresse e eficiência do uso da água de irrigação.

## Par DSSAT disponível

O conjunto atual contém duas trajetórias de 128 períodos com os mesmos fatores exógenos: mesmas datas, localização, solo, cultura, precipitação, temperatura, temperaturas máxima e mínima e graus-dia.

- manejo de referência: `irrigado`, run 1, 85 mm de irrigação;
- trajetória candidata ao Hydros: `sem_irrigacao`, run 2, 0 mm de irrigação.

A trajetória candidata somente foi usada como resultado do Hydros após uma verificação adicional: a política operacional gerada a partir das ações do Hydros Histórico produziu exatamente 0 mm em todos os períodos, coincidindo com a programação efetivamente simulada no run 2. Portanto, nesta trajetória específica, a saída do DSSAT é compatível com o manejo que o Hydros efetivamente produziria segundo a política implementada.

## Política operacional

Foi implementada a formulação `I_t = pi(D(U_i,t), I_{t-1}, R_t)` em `src/evaluation/irrigation_policy.py`.

Os parâmetros do protótipo foram definidos antes da comparação a partir da programação de referência, sem consultar as métricas de resultado do Hydros:

- lâmina-base: 10 mm;
- passo: 1 mm;
- mínimo por evento: 8 mm;
- máximo por evento: 12 mm;
- processamento inconclusivo: sem nova aplicação de água.

A política é parametrizável e poderá receber valores agronômicos documentados na avaliação final sem alteração do pipeline.

## Resultado da trajetória atual

| Indicador | Hydros Histórico | Manejo de referência |
|---|---:|---:|
| Água de irrigação acumulada | 0 mm | 85 mm |
| Produtividade final | 3061 kg/ha | 3114 kg/ha |
| Períodos com estresse DSSAT > 0 | 17 | 2 |
| Intensidade acumulada de estresse | 4,285 | 0,204 |
| EUA de irrigação | não definida, pois irrigação=0 | 36,635294 kg/ha/mm |

Diferenças Hydros - referência:

- água: -85 mm;
- produtividade: -53 kg/ha;
- períodos com estresse: +15;
- intensidade acumulada do estresse: +4,081.

Segundo o critério pré-definido de reduzir ou manter o uso de água sem aumentar estresse e sem reduzir produtividade, o resultado desta trajetória é **não favorável ao Hydros**.

## Limitações importantes

Este resultado corresponde a uma única trajetória pareada e não permite generalização. O APS atual permanece provisório. Além disso, o conjunto exportado do DSSAT não contém variável explícita de excesso de água, drenagem ou saturação. Por isso a métrica de excesso não foi fabricada por proxy e permanece indisponível.

O resultado desfavorável foi mantido integralmente. Nenhum peso, regra ou volume foi alterado depois de observar os resultados.

## Artefatos

- `src/evaluation/irrigation_policy.py`
- `run_experimento_2.py`
- `test_hydros_experiment2.py`
- `results/experimento_2/politica_operacional.json`
- `results/experimento_2/manejo_hydros_verificacao.csv`
- `results/experimento_2/manejo_referencia.csv`
- `results/experimento_2/metricas_experimento_2.csv`
- `results/experimento_2/comparacao_experimento_2.csv`
- `results/experimento_2/status_experimento_2.json`

## Situação

O pipeline do Experimento II está implementado e executado para o único par atual em que a programação do Hydros coincide com uma trajetória DSSAT já simulada. Novas trajetórias independentes e políticas agronômicas documentadas continuam necessárias para a avaliação final da tese.
