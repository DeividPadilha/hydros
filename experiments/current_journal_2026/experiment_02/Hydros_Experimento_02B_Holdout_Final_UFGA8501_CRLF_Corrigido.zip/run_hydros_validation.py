"""Validação integral do software e dos artefatos experimentais do Hydros.

Por padrão, a rotina valida todos os testes, artefatos e hashes já produzidos.
Use ``--reproduce-experiments`` para regenerar os experimentos antes da
validação. Essa opção é mais demorada porque o Experimento I executa o Hydros
em duas configurações sobre todas as observações pareadas.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
import platform
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from src.config.hydros_terms import VERSAO_ARQUITETURA

ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "results" / "validation"
EXP1_DIR = ROOT / "results" / "experimento_1"
SENS_DIR = ROOT / "results" / "modulo_6_sensibilidade"
EXP2_DIR = ROOT / "results" / "experimento_2"
APS_DIR = ROOT / "results" / "aps_modulo5"

TESTS = sorted(path.name for path in ROOT.glob("test_*.py"))

EXPERIMENT_GENERATORS = [
    ("run_experimento_1.py", 1200),
    ("diagnostico_resultados.py", 240),
    ("run_sensibilidade.py", 1200),
    ("run_experimento_2.py", 1200),
]

REQUIRED_ARTIFACTS = [
    "results/experimento_1/comparacao_detalhada.csv",
    "results/experimento_1/metricas_resumo.csv",
    "results/experimento_1/comparacao_pareada.csv",
    "results/experimento_1/resumo_pareado.csv",
    "results/experimento_1/metricas_por_cenario.csv",
    "results/experimento_1/diagnostico/metricas_multiclasse.csv",
    "results/experimento_1/diagnostico/metricas_binarias.csv",
    "results/experimento_1/artigo/table_main_metrics.csv",
    "results/experimento_1/artigo/experimental_results_summary.md",
    "results/aps_modulo5/prontidao_cientifica.json",
    "results/aps_modulo5/distribuicao_classes.csv",
    "results/modulo_6_sensibilidade/resumo_sensibilidade.csv",
    "results/modulo_6_sensibilidade/detalhes_sensibilidade.csv",
    "results/modulo_6_sensibilidade/sintese_por_grupo.csv",
    "results/experimento_2/politica_operacional.json",
    "results/experimento_2/manejo_hydros_verificacao.csv",
    "results/experimento_2/manejo_referencia.csv",
    "results/experimento_2/metricas_experimento_2.csv",
    "results/experimento_2/comparacao_experimento_2.csv",
    "results/experimento_2/status_experimento_2.json",
    "ontology/hydrosonto.owl",
    "src/models/aps_model_metadata.json",
]

HASH_TARGETS = [
    "src/config/hydros_terms.py",
    "src/core/contracts.py",
    "src/services/hydros_engine.py",
    "src/agents/aiec_agent.py",
    "src/agents/arg_agent.py",
    "src/agents/aps_agent.py",
    "src/agents/amdh_agent.py",
    "src/ontology/hydros_onto.py",
    "ontology/hydrosonto.owl",
    "src/models/aps_random_forest_model.pkl",
    "src/models/aps_model_metadata.json",
    "src/integrations/dssat_adapter.py",
    "src/evaluation/irrigation_policy.py",
    "data/hydros_soja_dssat_real_v2.csv",
    "results/experimento_1/metricas_resumo.csv",
    "results/modulo_6_sensibilidade/resumo_sensibilidade.csv",
    "results/experimento_2/metricas_experimento_2.csv",
]


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def package_version(name: str) -> str | None:
    try:
        module = importlib.import_module(name)
    except Exception:
        return None
    return str(getattr(module, "__version__", "não informado"))


def run_script(filename: str, timeout: int) -> dict[str, Any]:
    path = ROOT / filename
    started = time.perf_counter()
    if not path.exists():
        return {
            "script": filename,
            "status": "ausente",
            "returncode": None,
            "elapsed_seconds": 0.0,
            "stdout": "",
            "stderr": f"Arquivo não encontrado: {path}",
        }

    env = os.environ.copy()
    for key in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        env[key] = "1"

    try:
        with tempfile.TemporaryFile(mode="w+", encoding="utf-8") as out, \
             tempfile.TemporaryFile(mode="w+", encoding="utf-8") as err:
            proc = subprocess.run(
                [sys.executable, str(path)],
                cwd=ROOT,
                stdout=out,
                stderr=err,
                text=True,
                timeout=timeout,
                check=False,
                env=env,
            )
            out.seek(0)
            err.seek(0)
            stdout_text = out.read()
            stderr_text = err.read()
        return {
            "script": filename,
            "status": "ok" if proc.returncode == 0 else "falhou",
            "returncode": proc.returncode,
            "elapsed_seconds": round(time.perf_counter() - started, 3),
            "stdout": stdout_text,
            "stderr": stderr_text,
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "script": filename,
            "status": "timeout",
            "returncode": None,
            "elapsed_seconds": round(time.perf_counter() - started, 3),
            "stdout": exc.stdout if isinstance(exc.stdout, str) else "",
            "stderr": f"Tempo limite excedido: {timeout}s.",
        }


def read_csv(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    return json.loads(
        pd.read_csv(path).to_json(orient="records", force_ascii=False)
    )


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def scientific_summary() -> dict[str, Any]:
    detailed = (
        pd.read_csv(EXP1_DIR / "comparacao_detalhada.csv")
        if (EXP1_DIR / "comparacao_detalhada.csv").exists()
        else pd.DataFrame()
    )
    divergences = 0
    if "mesma_saida_hydros" in detailed.columns:
        divergences = int((~detailed["mesma_saida_hydros"].astype(bool)).sum())

    aps = read_json(APS_DIR / "prontidao_cientifica.json")
    exp2 = read_json(EXP2_DIR / "status_experimento_2.json")
    scientific_ready = bool(aps.get("ready", False)) and (
        exp2.get("scientific_scope") == "avaliacao_ampla_multitrajetoria"
    )

    return {
        "status": "apto" if scientific_ready else "provisorio",
        "n_observations_experiment_1": int(len(detailed)),
        "n_dssat_runs_experiment_1": (
            int(detailed["cenario_id"].nunique())
            if "cenario_id" in detailed.columns
            else 0
        ),
        "n_mode_divergences": divergences,
        "experiment_1_metrics": read_csv(EXP1_DIR / "metricas_resumo.csv"),
        "sensitivity_summary": read_csv(SENS_DIR / "sintese_por_grupo.csv"),
        "experiment_2_metrics": read_csv(EXP2_DIR / "metricas_experimento_2.csv"),
        "experiment_2_status": exp2,
        "aps_readiness": aps,
        "limitations": [
            "O APS ativo usa as três classes canônicas, mas permanece provisório por falta de trajetórias independentes e representação adequada da classe crítica em validação e teste.",
            "O Experimento I utiliza somente duas execuções DSSAT e apresenta forte desbalanceamento entre ações de referência.",
            "O Experimento II atual está restrito a uma única trajetória pareada em que a programação do Hydros coincide com uma trajetória DSSAT já simulada.",
            "A métrica explícita de excesso de água não está disponível no dataset DSSAT atual e não foi substituída por proxy.",
            "Os resultados atuais constituem avaliação experimental preliminar e não validação agronômica para uso operacional em campo.",
        ],
    }


def markdown_report(report: dict[str, Any]) -> str:
    lines = [
        "# Relatório de validação integral do Hydros",
        "",
        f"- Versão: `{report['architecture_version']}`",
        f"- Data UTC: `{report['generated_at_utc']}`",
        f"- Validação de software: **{report['overall_status'].upper()}**",
        f"- Prontidão científica: **{report['scientific_summary']['status'].upper()}**",
        f"- Regeneração dos experimentos: **{report['experiment_regeneration']}**",
        f"- Python: `{report['environment']['python'].split()[0]}`",
        "",
        "## Testes",
        "",
        "| Script | Status | Tempo (s) |",
        "|---|---:|---:|",
    ]
    for item in report["tests"]:
        lines.append(
            f"| `{item['script']}` | {item['status']} | {item['elapsed_seconds']:.3f} |"
        )

    if report["experiment_generators"]:
        lines += [
            "",
            "## Regeneração experimental",
            "",
            "| Script | Status | Tempo (s) |",
            "|---|---:|---:|",
        ]
        for item in report["experiment_generators"]:
            lines.append(
                f"| `{item['script']}` | {item['status']} | {item['elapsed_seconds']:.3f} |"
            )

    summary = report["scientific_summary"]
    lines += [
        "",
        "## Síntese científica atual",
        "",
        f"- Observações do Experimento I: **{summary['n_observations_experiment_1']}**",
        f"- Execuções DSSAT do Experimento I: **{summary['n_dssat_runs_experiment_1']}**",
        f"- Divergências entre modos: **{summary['n_mode_divergences']}**",
        "",
        "## Limitações abertas",
        "",
    ]
    lines.extend(f"- {item}" for item in summary["limitations"])

    lines += ["", "## Artefatos obrigatórios", ""]
    for item in report["artifacts"]:
        lines.append(
            f"- `{item['path']}`: {item['status']} ({item['size_bytes']} bytes)"
        )

    lines += ["", "## SHA-256 de artefatos centrais", ""]
    for item in report["hashes"]:
        lines.append(f"- `{item['path']}`: `{item['sha256']}`")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--reproduce-experiments",
        action="store_true",
        help="Regenera Experimento I, sensibilidade e Experimento II antes de validar.",
    )
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    print("\n=== VALIDAÇÃO INTEGRAL DO HYDROS ===")
    print(f"Versão: {VERSAO_ARQUITETURA}")
    print(f"Python: {sys.version.split()[0]}")

    generators: list[dict[str, Any]] = []
    if args.reproduce_experiments:
        for script, timeout in EXPERIMENT_GENERATORS:
            print(f"[REPRODUÇÃO] {script} ... ", end="", flush=True)
            result = run_script(script, timeout)
            generators.append(result)
            print(result["status"].upper())
            if result["status"] != "ok":
                print(result["stderr"] or result["stdout"][-3000:])
                break

    test_results: list[dict[str, Any]] = []
    for index, script in enumerate(TESTS, start=1):
        print(f"[TESTE {index:02d}/{len(TESTS):02d}] {script} ... ", end="", flush=True)
        result = run_script(script, 240)
        test_results.append(result)
        print(result["status"].upper())
        if result["status"] != "ok":
            print(result["stderr"] or result["stdout"][-2500:])

    artifacts = []
    for relative in REQUIRED_ARTIFACTS:
        path = ROOT / relative
        artifacts.append(
            {
                "path": relative,
                "status": "ok" if path.exists() and path.stat().st_size > 0 else "ausente",
                "size_bytes": path.stat().st_size if path.exists() else 0,
            }
        )

    hashes = []
    for relative in HASH_TARGETS:
        path = ROOT / relative
        if path.exists():
            hashes.append({"path": relative, "sha256": sha256(path)})

    generators_ok = (
        not args.reproduce_experiments
        or (
            len(generators) == len(EXPERIMENT_GENERATORS)
            and all(item["status"] == "ok" for item in generators)
        )
    )
    tests_ok = all(item["status"] == "ok" for item in test_results)
    artifacts_ok = all(item["status"] == "ok" for item in artifacts)
    overall_ok = generators_ok and tests_ok and artifacts_ok

    report = {
        "schema_version": "2.1",
        "architecture_version": VERSAO_ARQUITETURA,
        "generated_at_utc": now_utc(),
        "overall_status": "ok" if overall_ok else "falhou",
        "scientific_readiness_is_release_blocker": False,
        "experiment_regeneration": (
            "executed" if args.reproduce_experiments else "not_requested_current_artifacts_verified"
        ),
        "environment": {
            "python": sys.version.replace("\n", " "),
            "executable": sys.executable,
            "platform": platform.platform(),
            "packages": {
                "numpy": package_version("numpy"),
                "pandas": package_version("pandas"),
                "pyarrow": package_version("pyarrow"),
                "scikit-learn": package_version("sklearn"),
                "streamlit": package_version("streamlit"),
                "rdflib": package_version("rdflib"),
            },
        },
        "tests": test_results,
        "experiment_generators": generators,
        "artifacts": artifacts,
        "hashes": hashes,
        "scientific_summary": scientific_summary(),
    }

    json_path = OUTPUT_DIR / "hydros_validation_report.json"
    md_path = OUTPUT_DIR / "hydros_validation_report.md"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(markdown_report(report), encoding="utf-8")

    passed = sum(item["status"] == "ok" for item in test_results)
    print("\n=== RESUMO DA VALIDAÇÃO ===")
    print(f"Testes: {passed}/{len(TESTS)}")
    print(f"Artefatos: {'OK' if artifacts_ok else 'INCOMPLETOS'}")
    print(f"Prontidão científica: {report['scientific_summary']['status'].upper()}")
    print(f"Regeneração experimental: {report['experiment_regeneration']}")
    print(f"Relatório: {md_path}")
    print(f"VALIDAÇÃO DE SOFTWARE: {'OK' if overall_ok else 'FALHOU'}")

    if not overall_ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
