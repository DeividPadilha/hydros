"""Executa o Experimento II-B V4 em ciclo fechado nos cenários de desenvolvimento.

IMPORTANTE
---------
* UFGA8501 continua bloqueado como holdout final.
* O script NÃO altera os arquivos oficiais UFGA7801.SBX/UFGA8401.SBX.
* Uma cópia candidata curta (H7801C.SBX/H8401C.SBX) é criada temporariamente
  no diretório Soybean e removida ao final.
* O tratamento 1 permanece como referência DSSAT.
* O tratamento 2 recebe somente o prefixo de irrigação comum a T1/T2 e,
  depois do início do controle, as lâminas determinadas causalmente pelo Hydros.
* D(t) só é aplicado em t+1.

Uso:
    python run_closed_loop_desenvolvimento_exp02b_v4.py --dssat-root "C:\\DSSAT48"
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import asdict
from datetime import datetime
import json
from pathlib import Path
import shutil
import statistics
from typing import Iterable

import pandas as pd

from src.evaluation.dssat_cli import DSSATCommandConfig, run_dssat_command
from src.evaluation.dssat_hydros_mapping import build_hydros_context_from_dssat_outputs
from src.evaluation.dssat_sbx_schedule import (
    IrrigationEvent,
    extract_irrigation_events,
    extract_treatment_irrigation_events,
    get_treatment_factor_level,
    replace_irrigation_events,
)
from src.evaluation.irrigation_policy import IrrigationActionPolicy, IrrigationPolicyConfig
from src.services.hydros_engine import HydrosEngine

ROOT = Path(__file__).resolve().parent
RESULT_ROOT = ROOT / "results" / "experimento_2b" / "desenvolvimento_v4_closed_loop"
DEVELOPMENT = ("UFGA7801", "UFGA8401")
HOLDOUT_FORBIDDEN = "UFGA8501"


def yyyymmdd_to_yyddd(value: str) -> int:
    dt = pd.to_datetime(str(value))
    return int(f"{dt.year % 100:02d}{dt.dayofyear:03d}")


def longest_common_prefix(
    a: Iterable[IrrigationEvent], b: Iterable[IrrigationEvent]
) -> list[IrrigationEvent]:
    aa = list(a)
    bb = list(b)
    result: list[IrrigationEvent] = []
    for left, right in zip(aa, bb):
        if (
            int(left.date_code) == int(right.date_code)
            and abs(float(left.amount_mm) - float(right.amount_mm)) <= 1e-9
            and str(left.operation) == str(right.operation)
        ):
            result.append(left)
        else:
            break
    return result


def policy_from_reference_events(events: list[IrrigationEvent]) -> IrrigationPolicyConfig:
    amounts = sorted(float(e.amount_mm) for e in events if float(e.amount_mm) > 0)
    if not amounts:
        raise ValueError("Tratamento de referência não possui eventos de irrigação.")
    unique = sorted(set(amounts))
    diffs = [b - a for a, b in zip(unique, unique[1:]) if b > a]
    step = statistics.median(diffs) if diffs else max(statistics.median(amounts) * 0.10, 1.0)
    return IrrigationPolicyConfig(
        base_mm=float(statistics.median(amounts)),
        step_mm=float(step),
        min_mm=float(min(amounts)),
        max_mm=float(max(amounts)),
        inconclusive_policy="sem_aplicacao",
        provenance="eventos_brutos_T1_DSSAT_preexistentes_antes_do_holdout",
    )


def run_dssat(exe: Path, experiment: Path, treatment: int) -> None:
    completed = run_dssat_command(
        DSSATCommandConfig(
            executable=exe,
            experiment_file=experiment,
            treatment=int(treatment),
            working_directory=experiment.parent,
            timeout_seconds=240,
        )
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"DSSAT falhou em {experiment.name} T{treatment}: "
            f"returncode={completed.returncode}\n{completed.stderr or ''}"
        )


def copy_outs(source_dir: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=False)
    files = sorted(source_dir.glob("*.OUT"))
    if not files:
        raise RuntimeError(f"Nenhum .OUT encontrado em {source_dir}")
    for source in files:
        shutil.copy2(source, destination / source.name)


def contexts_from_current_outputs(soybean: Path, scenario_id: str) -> pd.DataFrame:
    return build_hydros_context_from_dssat_outputs(soybean, scenario_id=scenario_id)


def aligned_weather_check(reference: pd.DataFrame, current: pd.DataFrame, until_date: str | None = None) -> dict:
    cols = ["data", "precipitacao", "temp_maxima", "temp_minima"]
    a = reference[cols].copy()
    b = current[cols].copy()
    if until_date is not None:
        a = a[pd.to_datetime(a["data"]) <= pd.to_datetime(until_date)]
        b = b[pd.to_datetime(b["data"]) <= pd.to_datetime(until_date)]
    merged = a.merge(b, on="data", suffixes=("_ref", "_cur"), how="inner")
    if merged.empty:
        return {"same_weather": False, "reason": "sem_datas_comuns", "n_common": 0}
    max_diff = {}
    for col in cols[1:]:
        diff = (
            pd.to_numeric(merged[f"{col}_ref"], errors="coerce")
            - pd.to_numeric(merged[f"{col}_cur"], errors="coerce")
        ).abs()
        max_diff[col] = float(diff.max())
    return {
        "same_weather": all(v <= 1e-9 for v in max_diff.values()),
        "n_common": int(len(merged)),
        "reference_rows": int(len(a)),
        "current_rows": int(len(b)),
        "max_abs_diff": max_diff,
        "common_start": str(merged["data"].iloc[0]),
        "common_end": str(merged["data"].iloc[-1]),
    }


def summarize_contexts(contexts: pd.DataFrame, *, dap_min: int = 20) -> dict:
    control = contexts[contexts["dap"] >= int(dap_min)].copy()
    stress = pd.to_numeric(control["dssat_estresse_max"], errors="coerce").fillna(0.0)
    final = contexts.iloc[-1]
    return {
        "n_rows": int(len(contexts)),
        "n_control_dap_ge_20": int(len(control)),
        "effective_irrigation_mm": round(float(pd.to_numeric(contexts["irrigacao_aplicada"]).sum()), 6),
        "yield_GWAD_final_kg_ha": round(float(final["dssat_GWAD_kg_ha"]), 6),
        "stress_days_ge_0_25_control": int((stress >= 0.25).sum()),
        "stress_sum_control": round(float(stress.sum()), 6),
        "drainage_final_mm": round(float(final["dssat_drenagem_cumulativa_mm"]), 6),
        "final_date": str(final["data"]),
    }


def decision_trace_row(contexts: pd.DataFrame, engine: HydrosEngine) -> tuple[str | None, dict]:
    result = engine.processar(contexts, modo_execucao="historico", propriedade_id="UF_Gainesville")
    amdh = result["amdh"]
    action = amdh.get("D(Ui)")
    return action, {
        "status": amdh.get("status_processamento"),
        "motivos_inconclusao": list(amdh.get("motivos_inconclusao", [])),
        "Ehid": result["ahid"].get("Ehid"),
        "Ehc": result["aiec"].get("Ehc"),
        "Earg": result["arg"].get("Earg"),
        "Eaps": result["aps"].get("Eaps"),
        "aps_status_dominio": result["aps"].get("status_dominio"),
        "confianca": amdh.get("confianca"),
        "indice_conflito": amdh.get("indice_conflito"),
    }


def run_scenario(exe: Path, soybean: Path, exp_code: str) -> dict:
    if exp_code == HOLDOUT_FORBIDDEN:
        raise RuntimeError("Holdout bloqueado no runner de desenvolvimento.")

    source = soybean / f"{exp_code}.SBX"
    if not source.exists():
        raise FileNotFoundError(source)

    text = source.read_text(encoding="utf-8")
    # O número do tratamento NÃO é necessariamente o número do nível MI.
    # Ex.: UFGA7801 T2 usa MI=0 (rainfed), portanto não existe bloco de
    # irrigação nível 2. A programação é obtida pela referência de fator MI
    # declarada em *TREATMENTS.
    reference_irrigation_level = get_treatment_factor_level(text, 1, "MI")
    if reference_irrigation_level <= 0:
        raise RuntimeError("Tratamento de referência T1 não possui manejo de irrigação explícito.")
    ref_events = extract_treatment_irrigation_events(text, 1)
    t2_irrigation_level = get_treatment_factor_level(text, 2, "MI")
    t2_events = extract_treatment_irrigation_events(text, 2)
    common_prefix = longest_common_prefix(ref_events, t2_events)
    policy_config = policy_from_reference_events(ref_events)

    candidate_name = {"UFGA7801": "H7801C.SBX", "UFGA8401": "H8401C.SBX"}[exp_code]
    candidate = soybean / candidate_name
    if candidate.exists():
        raise RuntimeError(
            f"Arquivo temporário já existe: {candidate}. Remova somente se tiver certeza de que é de uma execução anterior do Hydros."
        )

    scenario_dir = RESULT_ROOT / exp_code
    scenario_dir.mkdir(parents=True, exist_ok=True)
    original_hash_note = {
        "source": str(source),
        "candidate": str(candidate),
        "reference_irrigation_level_T1": int(reference_irrigation_level),
        "t2_irrigation_level": int(t2_irrigation_level),
        "reference_events_T1": [asdict(e) for e in ref_events],
        "original_events_T2": [asdict(e) for e in t2_events],
        "common_prefix_events": [asdict(e) for e in common_prefix],
        "policy": policy_config.to_dict(),
    }

    try:
        # Referência oficial T1, sem nenhuma modificação.
        run_dssat(exe, source, 1)
        reference = contexts_from_current_outputs(soybean, f"{exp_code}_T1_reference")
        copy_outs(soybean, scenario_dir / "reference_T1_OUT")
        reference.to_csv(scenario_dir / "reference_T1_contexts.csv", index=False)

        # O candidato é uma cópia do próprio T1 de referência com APENAS a
        # programação de irrigação substituída. Isso mantém todos os demais
        # fatores exatamente iguais ao comparador. O prefixo do tratamento T2
        # é usado apenas como condição inicial observacional; para MI=0, ele é
        # naturalmente vazio.
        schedule: dict[int, float] = {
            int(e.date_code): float(e.amount_mm) for e in common_prefix
        }
        updated = replace_irrigation_events(
            text, level=reference_irrigation_level, events=list(common_prefix)
        )
        candidate.write_text(updated, encoding="utf-8", newline="\n")
        run_dssat(exe, candidate, 1)
        current = contexts_from_current_outputs(soybean, f"{exp_code}_Hydros_seed")

        baseline = current.copy()
        baseline.to_csv(scenario_dir / "candidate_seed_contexts.csv", index=False)
        control_candidates = baseline.index[baseline["dap"] >= 20].tolist()
        if not control_candidates:
            raise RuntimeError("Nenhum período com DAP >= 20 para iniciar controle.")
        control_start = int(control_candidates[0])
        if common_prefix:
            last_prefix = max(int(e.date_code) for e in common_prefix)
            idx_after_prefix = [
                int(i) for i, d in enumerate(baseline["data"]) if yyyymmdd_to_yyddd(d) >= last_prefix
            ]
            if idx_after_prefix:
                control_start = max(control_start, idx_after_prefix[0])

        control_dates = list(baseline["data"].iloc[control_start:].astype(str))
        if len(control_dates) < 2:
            raise RuntimeError("Horizonte de controle insuficiente.")

        policy = IrrigationActionPolicy(policy_config)
        start_code = yyyymmdd_to_yyddd(control_dates[0])
        policy.set_previous_mm(float(schedule.get(start_code, 0.0)))
        engine = HydrosEngine(modo_execucao="historico")
        trace: list[dict] = []
        n_dssat_runs_candidate = 1

        # O horizonte é congelado a partir da trajetória seed. A irrigação pode
        # prolongar a safra; isso será capturado na execução final, mas não cria
        # novas oportunidades de controle escolhidas depois de observar o resultado.
        for pos in range(len(control_dates) - 1):
            current_date = control_dates[pos]
            next_date = control_dates[pos + 1]
            matched = current.index[current["data"].astype(str) == current_date].tolist()
            if not matched:
                trace.append({
                    "data_contexto": current_date,
                    "status": "controle_encerrado_data_ausente_na_trajetoria",
                })
                break
            idx = int(matched[0])
            history = current.iloc[: idx + 1].copy().reset_index(drop=True)
            action, meta = decision_trace_row(history, engine)
            planned_gross = float(policy.apply(action))
            next_code = yyyymmdd_to_yyddd(next_date)
            previous_planned = float(schedule.get(next_code, 0.0))
            schedule[next_code] = planned_gross

            rerun = abs(previous_planned - planned_gross) > 1e-9
            if rerun:
                events = [IrrigationEvent(code, mm) for code, mm in schedule.items() if mm > 0]
                updated = replace_irrigation_events(text, level=reference_irrigation_level, events=events)
                candidate.write_text(updated, encoding="utf-8", newline="\n")
                run_dssat(exe, candidate, 1)
                n_dssat_runs_candidate += 1
                new_current = contexts_from_current_outputs(soybean, f"{exp_code}_Hydros_closed_loop")
                weather = aligned_weather_check(baseline, new_current, until_date=next_date)
                if not weather["same_weather"]:
                    raise RuntimeError(
                        f"Variáveis meteorológicas mudaram até {next_date}: {weather}"
                    )
                # Se houve evento planejado, o DSSAT precisa registrar irrigação
                # efetiva positiva na data correspondente. A magnitude efetiva é
                # responsabilidade do EFIR do próprio experimento.
                next_match = new_current.index[new_current["data"].astype(str) == next_date].tolist()
                if not next_match:
                    raise RuntimeError(
                        f"A trajetória candidata não alcançou a data controlada {next_date}."
                    )
                sim_eff = float(new_current.iloc[int(next_match[0])]["irrigacao_aplicada"])
                if planned_gross > 0 and sim_eff <= 0:
                    raise RuntimeError(
                        f"DSSAT não registrou irrigação efetiva em {next_date} para evento bruto {planned_gross} mm."
                    )
                if planned_gross <= 0 and sim_eff > 1e-9:
                    raise RuntimeError(
                        f"DSSAT registrou irrigação não planejada em {next_date}: {sim_eff} mm."
                    )
                current = new_current
            else:
                sim_match = current.index[current["data"].astype(str) == next_date].tolist()
                sim_eff = (
                    float(current.iloc[int(sim_match[0])]["irrigacao_aplicada"])
                    if sim_match else None
                )

            row_now = history.iloc[-1]
            trace.append({
                "data_contexto_t": current_date,
                "data_manejo_t_mais_1": next_date,
                "DAP_t": int(row_now["dap"]),
                "stress_dssat_t": float(row_now["dssat_estresse_max"]),
                "umidade_solo_t": float(row_now["umidade_solo"]),
                "agua_disponivel_t": float(row_now["agua_disponivel"]),
                "acao": action,
                "irrigacao_bruta_planejada_t_mais_1_mm": round(planned_gross, 6),
                "irrigacao_efetiva_simulada_t_mais_1_mm": (
                    None if sim_eff is None else round(float(sim_eff), 6)
                ),
                "dssat_reexecutado": bool(rerun),
                **meta,
            })

        # Uma execução final garante que o resultado terminal corresponde ao
        # manejo final congelado, inclusive após o fim do horizonte controlado.
        events = [IrrigationEvent(code, mm) for code, mm in schedule.items() if mm > 0]
        updated = replace_irrigation_events(text, level=reference_irrigation_level, events=events)
        candidate.write_text(updated, encoding="utf-8", newline="\n")
        run_dssat(exe, candidate, 1)
        n_dssat_runs_candidate += 1
        final_candidate = contexts_from_current_outputs(soybean, f"{exp_code}_Hydros_final")
        copy_outs(soybean, scenario_dir / "candidate_Hydros_final_OUT")
        final_candidate.to_csv(scenario_dir / "candidate_Hydros_final_contexts.csv", index=False)
        trace_df = pd.DataFrame(trace)
        trace_df.to_csv(scenario_dir / "trace_closed_loop.csv", index=False)

        weather_final = aligned_weather_check(reference, final_candidate)
        ref_summary = summarize_contexts(reference)
        cand_summary = summarize_contexts(final_candidate)
        gross_ref = round(sum(float(e.amount_mm) for e in ref_events), 6)
        gross_hydros = round(sum(float(v) for v in schedule.values()), 6)
        eff_ref = float(ref_summary["effective_irrigation_mm"])
        eff_hydros = float(cand_summary["effective_irrigation_mm"])
        yield_ref = float(ref_summary["yield_GWAD_final_kg_ha"])
        yield_h = float(cand_summary["yield_GWAD_final_kg_ha"])

        actions = Counter(trace_df.get("acao", pd.Series(dtype=str)).fillna("<null>"))
        domain = Counter(trace_df.get("aps_status_dominio", pd.Series(dtype=str)).fillna("<null>"))
        null_reasons = Counter()
        for value in trace_df.get("motivos_inconclusao", pd.Series(dtype=object)):
            if isinstance(value, list):
                null_reasons.update(str(v) for v in value)

        metrics = {
            "reference_T1": ref_summary,
            "hydros_candidate": cand_summary,
            "gross_irrigation_reference_mm": gross_ref,
            "gross_irrigation_hydros_mm": gross_hydros,
            "gross_water_saving_mm": round(gross_ref - gross_hydros, 6),
            "gross_water_saving_pct": round(100.0 * (gross_ref - gross_hydros) / gross_ref, 6) if gross_ref > 0 else None,
            "effective_water_saving_mm": round(eff_ref - eff_hydros, 6),
            "effective_water_saving_pct": round(100.0 * (eff_ref - eff_hydros) / eff_ref, 6) if eff_ref > 0 else None,
            "yield_delta_kg_ha": round(yield_h - yield_ref, 6),
            "yield_retention_pct": round(100.0 * yield_h / yield_ref, 6) if yield_ref > 0 else None,
            "stress_days_delta": int(cand_summary["stress_days_ge_0_25_control"] - ref_summary["stress_days_ge_0_25_control"]),
            "stress_sum_delta": round(float(cand_summary["stress_sum_control"] - ref_summary["stress_sum_control"]), 6),
            "drainage_delta_mm": round(float(cand_summary["drainage_final_mm"] - ref_summary["drainage_final_mm"]), 6),
            "weather_overlap": weather_final,
            "actions": {str(k): int(v) for k, v in actions.items()},
            "aps_domain": {str(k): int(v) for k, v in domain.items()},
            "n_dssat_runs_candidate": int(n_dssat_runs_candidate),
            "control_start_date": control_dates[0],
            "control_end_date_seed": control_dates[-1],
            "control_start_index_seed": int(control_start),
        }

        # Critérios transparentes de desenvolvimento. Eles NÃO são usados para
        # selecionar o melhor cenário e NÃO serão recalibrados no holdout.
        # A classificação abaixo é apenas um gate de engenharia antes de abrir
        # UFGA8501; as métricas contínuas permanecem o resultado principal.
        metrics["development_gate"] = {
            "water_saving_positive": bool(metrics["effective_water_saving_mm"] > 0),
            "yield_retention_ge_95pct": bool(metrics["yield_retention_pct"] is not None and metrics["yield_retention_pct"] >= 95.0),
            "no_weather_change_on_overlap": bool(weather_final.get("same_weather", False)),
        }
        metrics["development_gate"]["pass"] = all(metrics["development_gate"].values())

        (scenario_dir / "scenario_manifest.json").write_text(
            json.dumps({**original_hash_note, "metrics": metrics}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return metrics
    finally:
        if candidate.exists():
            candidate.unlink()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dssat-root", type=Path, required=True)
    parser.add_argument(
        "--scenario",
        choices=DEVELOPMENT,
        default=None,
        help="Executa somente um cenário de desenvolvimento. Omitido = executa ambos.",
    )
    args = parser.parse_args()

    dssat_root = args.dssat_root.resolve()
    exe = dssat_root / "DSCSM048.EXE"
    soybean = dssat_root / "Soybean"
    if not exe.exists():
        raise FileNotFoundError(exe)
    if not soybean.is_dir():
        raise FileNotFoundError(soybean)

    # Guard adicional: nenhuma referência ao holdout é passada ao executor.
    if any(code == HOLDOUT_FORBIDDEN for code in DEVELOPMENT):
        raise RuntimeError("Holdout incluído indevidamente na lista de desenvolvimento.")

    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    result = {
        "experiment": "HYDROS-EXP02B V4 closed-loop development",
        "holdout_executed": False,
        "holdout_forbidden": HOLDOUT_FORBIDDEN,
        "started_at": datetime.now().isoformat(timespec="seconds"),
        "scenarios": {},
    }
    selected = (args.scenario,) if args.scenario else DEVELOPMENT
    if any(code == HOLDOUT_FORBIDDEN for code in selected):
        raise RuntimeError("Holdout incluído indevidamente na execução.")

    for code in selected:
        print(f"\n=== {code}: ciclo fechado de desenvolvimento ===", flush=True)
        result["scenarios"][code] = run_scenario(exe, soybean, code)
        print(json.dumps(result["scenarios"][code], ensure_ascii=False, indent=2), flush=True)

    result["finished_at"] = datetime.now().isoformat(timespec="seconds")
    summary = RESULT_ROOT / "RESUMO_CLOSED_LOOP_DESENVOLVIMENTO_V4.json"
    summary.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"\nResumo gravado em: {summary}")
    print("UFGA8501 NÃO foi executado.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
