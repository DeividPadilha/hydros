# Hydros 0.4.1-qualificacao-final

O Hydros é um protótipo computacional para gerenciamento hídrico inteligente em Agricultura Digital. A contribuição investigada é o uso de históricos de contextos agrícolas como memória temporal para determinar ações de manejo hídrico em unidades de manejo.

Esta versão está alinhada à tese de qualificação e preserva os resultados experimentais obtidos até os Módulos 6 e 7.

## Escopo atual

O Hydros determina uma ação computacional de manejo, mas **não aciona fisicamente** equipamentos de irrigação. As ações possíveis são:

- `iniciar_irrigacao`;
- `manter_irrigacao`;
- `aumentar_irrigacao`;
- `reduzir_irrigacao`;
- `finalizar_irrigacao`.

Quando dados, confiança ou conflitos impedem uma determinação segura, o processamento é registrado como `inconclusivo` e nenhuma ação conclusiva é emitida.

## Arquitetura

O processamento é organizado em três ramos.

1. Contextual: Aclim, Ahid, Afen, Ageo, Aprod e Ahist, coordenados pelo AIEC, que produz `Ehc`.
2. Agronômico: ARG, que produz `Earg` a partir de regras explícitas.
3. Preditivo: APS, inicialmente baseado em Random Forest, que produz `Eaps`.

O AMDH integra `Ehc`, `Earg` e `Eaps`, verifica consistência e determina a ação de manejo. A HydrosOnto é consultada como recurso de **verificação semântica e rastreabilidade** e não participa direta ou indiretamente do cálculo do score do AMDH.

A ontologia formal está em:

```text
ontology/hydrosonto.owl
```

## Modos experimentais

A comparação principal do Experimento I usa as mesmas observações nos dois modos:

- **Hydros Histórico**: utiliza `C(t)` e o histórico `H(Ui)`;
- **Hydros sem Histórico**: utiliza somente `C(t)`.

O valor padrão da janela histórica é cinco contextos e pode ser alterado na interface ou na criação do `HydrosEngine`. O APS registra incompatibilidade quando a janela de execução difere da janela usada no treinamento.

## Estrutura principal

```text
src/
├── agents/
│   ├── aclim_agent.py
│   ├── ahid_agent.py
│   ├── afen_agent.py
│   ├── ageo_agent.py
│   ├── aprod_agent.py
│   ├── ahist_agent.py
│   ├── aiec_agent.py
│   ├── arg_agent.py
│   ├── aps_agent.py
│   └── amdh_agent.py
├── config/hydros_terms.py
├── core/
├── database/
├── evaluation/irrigation_policy.py
├── integrations/dssat_adapter.py
├── ontology/hydros_onto.py
├── services/
└── models/
```

## Variáveis do contexto

O contexto agrícola pode incluir:

```text
data
talhao
cultura
loc
solo
precipitacao
temperatura
graus_dia_periodo
soma_termica_acumulada
evapotranspiracao
coeficiente_cultura
umidade_solo
agua_disponivel
irrigacao_aplicada
irrigacao_ativa
estagio_fenologico
estresse_hidrico
produtividade
```

## Instalação

No PowerShell:

```powershell
python -m venv .venv-1
.\.venv-1\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Interface

```powershell
streamlit run app.py
```

A interface permite executar Histórico e sem Histórico, comparar ações, visualizar evidências, regras, inferências, scores, confiança, completude e conflitos, e persistir a execução.

## Experimento I

Execução canônica:

```powershell
python run_experimento_1.py
python diagnostico_resultados.py
python test_hydros_article_outputs.py
```

Resultados atuais, com 256 observações pareadas:

| Indicador | Histórico | sem Histórico |
|---|---:|---:|
| Processamentos conclusivos | 254 | 255 |
| Taxa conclusiva | 0,9922 | 0,9961 |
| Acurácia global | 0,9492 | 0,9531 |
| Acurácia entre conclusivas | 0,9567 | 0,9569 |
| F1 macro | 0,1948 | 0,1952 |
| Confiança média | 0,6816 | 0,5841 |

Foi observada 1 saída diferente entre os modos. Em 243 observações ambos concordaram com a referência e em 12 nenhum concordou. O único caso divergente favoreceu o modo sem Histórico. Nenhum modo detectou os 11 eventos de `iniciar_irrigacao` da referência atual.

Esses resultados são preliminares e não constituem validação agronômica.

A partir do checkpoint C, `gd` corresponde à `soma_termica_acumulada`, conforme a tese. O incremento térmico de cada período é preservado separadamente em `graus_dia_periodo`. A coluna antiga `graus_dia` continua aceita apenas como alias legado de entrada.

## APS

O APS utiliza as classes canônicas:

```text
adequada
atencao
critica
```

A divisão de treino evita embaralhamento aleatório de registros consecutivos. Quando há grupos independentes suficientes, a divisão é feita por trajetórias; na base atual, que contém uma única trajetória, usa-se divisão cronológica.

O modelo ativo está explicitamente marcado como **provisório** porque a base atual não possui trajetórias independentes suficientes e a classe `critica` não aparece nos conjuntos de validação e teste. Portanto, métricas do APS não devem ser apresentadas como validação científica final.

## Módulo 6: análise de sensibilidade

```powershell
python run_sensibilidade.py
python test_hydros_sensitivity.py
```

Foram avaliadas 25 configurações pré-definidas. A configuração-base da sensibilidade reproduz exatamente as saídas do Hydros Histórico no Experimento I. Nas perturbações atuais, a estabilidade mínima dos pesos do AMDH foi 0,992188 e as variações dos pesos do AIEC mantiveram as mesmas ações da configuração-base. Nenhuma configuração detectou os 11 eventos de intensificação. Os pesos-base foram mantidos e não houve otimização posterior aos resultados.

Resultados:

```text
results/modulo_6_sensibilidade/
```

## Experimento II

```powershell
python run_experimento_2.py
python test_hydros_experiment2.py
```

O pipeline converte ações do Hydros Histórico em uma programação de irrigação por meio de uma política operacional explícita. No único par DSSAT atualmente compatível, a programação produzida pelo Hydros coincidiu com uma trajetória já simulada sem irrigação.

Resultado atual:

| Indicador | Hydros Histórico | Manejo de referência |
|---|---:|---:|
| Irrigação acumulada | 0 mm | 85 mm |
| Produtividade final | 3061 kg/ha | 3114 kg/ha |
| Períodos com estresse | 17 | 2 |
| Intensidade acumulada de estresse | 4,285 | 0,204 |
| EUA de irrigação | não definida | 36,635294 kg/ha/mm |

Nesse cenário, o resultado foi **não favorável ao Hydros**: houve economia de água, porém com aumento do estresse e redução da produtividade. O resultado foi preservado sem ajuste oportunista de pesos, regras ou volumes.

O DSSAT é usado como **benchmark de simulação** na avaliação e não faz parte do núcleo do Hydros.

## Validação integral

```powershell
python run_hydros_validation.py
```

Por padrão, a validação executa os 24 testes atuais e verifica os artefatos já produzidos, sem sobrescrever os resultados experimentais. Para regenerar Experimento I, sensibilidade e Experimento II antes da validação, use `python run_hydros_validation.py --reproduce-experiments`. Os relatórios são gerados em:

```text
results/validation/hydros_validation_report.json
results/validation/hydros_validation_report.md
```

A validação atual aprovou **24/24 testes**. A validação de software pode ser aprovada mesmo com prontidão científica marcada como `provisorio`. Isso é intencional: o protótipo pode estar funcional e reproduzível sem que os resultados atuais sejam suficientes para uma conclusão agronômica definitiva.

## Congelamento da versão

Após `VALIDAÇÃO DE SOFTWARE: OK`:

```powershell
python freeze_hydros_release.py
```

O script gera um ZIP, manifesto e checksum SHA-256 em `releases/`.

## Limitações científicas atuais

- APS ainda provisório por falta de trajetórias independentes e representação suficiente da classe crítica;
- Experimento I limitado a duas execuções DSSAT e referência fortemente desbalanceada;
- Experimento II limitado a uma trajetória pareada compatível;
- variável explícita de excesso/drenagem não está disponível no dataset DSSAT atual;
- ainda é necessária ampliação com novos cenários e, posteriormente, dados agrícolas reais.

Portanto, esta versão deve ser tratada como **prova de conceito funcional e rastreável para avaliação experimental**, não como sistema agronomicamente validado para uso operacional.

## Fechamento para qualificação

A versão `0.4.1-qualificacao-final` fecha o protótipo conforme o contrato funcional descrito no Capítulo 6 da tese. O relatório `FINALIZACAO_QUALIFICACAO.md` relaciona cada requisito à implementação e aos testes executados. Esta etapa não altera pesos, regras agronômicas, limiares, modelos ou resultados experimentais para favorecer o Hydros.
