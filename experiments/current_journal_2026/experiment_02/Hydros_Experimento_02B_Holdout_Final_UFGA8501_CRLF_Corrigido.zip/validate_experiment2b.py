"""Validação consolidada e auditável do Experimento II-B do Hydros.

Este script não executa o DSSAT e não altera o núcleo do Hydros. Ele consolida:
- testes locais;
- integridade da pré-registração e dos fixtures do holdout;
- congelamento dos arquivos científicos centrais em relação ao ZIP-base;
- prontidão do ambiente para uma execução DSSAT real.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results" / "experimento_2b"

CORE_FILES = (
    "src/agents/amdh_agent.py",
    "src/agents/aiec_agent.py",
    "src/agents/arg_agent.py",
    "src/agents/aps_agent.py",
    "src/config/hydros_terms.py",
    "src/ontology/hydros_onto.py",
    "ontology/hydrosonto.owl",
    "src/models/aps_random_forest_model.pkl",
    "src/models/aps_model_metadata.json",
    "src/integrations/dssat_adapter.py",
)

EXPECTED_MUTABLE_EVALUATION_FILES = (
    "src/evaluation/irrigation_policy.py",
    "run_experimento_2.py",
)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def find_zip_member(zf: zipfile.ZipFile, relative: str) -> str:
    suffix = "/" + relative.replace("\\", "/")
    matches = [n for n in zf.namelist() if n.endswith(suffix)]
    if len(matches) != 1:
        raise RuntimeError(
            f"Esperado exatamente um arquivo {relative!r} no ZIP; encontrados: {matches}"
        )
    return matches[0]


def compare_core_against_zip(baseline_zip: Path) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    with zipfile.ZipFile(baseline_zip) as zf:
        for relative in CORE_FILES:
            local = ROOT / relative
            member = find_zip_member(zf, relative)
            baseline_hash = sha256_bytes(zf.read(member))
            local_hash = sha256_file(local)
            rows.append(
                {
                    "file": relative,
                    "baseline_sha256": baseline_hash,
                    "working_sha256": local_hash,
                    "identical": baseline_hash == local_hash,
                }
            )

        expected_diffs: list[dict[str, object]] = []
        for relative in EXPECTED_MUTABLE_EVALUATION_FILES:
            local = ROOT / relative
            member = find_zip_member(zf, relative)
            baseline_hash = sha256_bytes(zf.read(member))
            local_hash = sha256_file(local)
            expected_diffs.append(
                {
                    "file": relative,
                    "baseline_sha256": baseline_hash,
                    "working_sha256": local_hash,
                    "identical": baseline_hash == local_hash,
                    "change_class": "esperada_apenas_na_camada_experimental",
                }
            )

    return {
        "all_core_identical": all(bool(r["identical"]) for r in rows),
        "core_files": rows,
        "expected_evaluation_differences": expected_diffs,
    }


def run_pytest() -> dict[str, object]:
    completed = subprocess.run(
        [sys.executable, "-m", "pytest", "-q"],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    output = completed.stdout.strip()
    return {
        "returncode": completed.returncode,
        "passed": completed.returncode == 0,
        "output": output,
    }


def verify_preregistration() -> dict[str, object]:
    checks = []
    for stem in ("pre_registro_experimento_02b", "pre_registro_experimento_02b_v2"):
        json_path = RESULTS / f"{stem}.json"
        sha_path = RESULTS / f"{stem}.sha256"
        expected = sha_path.read_text(encoding="utf-8").strip().split()[0]
        actual = sha256_file(json_path)
        checks.append(
            {
                "file": json_path.name,
                "expected_sha256": expected,
                "actual_sha256": actual,
                "valid": expected == actual,
            }
        )
    return {
        "all_valid": all(bool(c["valid"]) for c in checks),
        "checks": checks,
    }


def verify_holdout_manifest() -> dict[str, object]:
    manifest_path = RESULTS / "manifesto_holdout_ufga8501.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    rows = []
    for name, expected in manifest.items():
        path = RESULTS / name
        exists = path.is_file()
        actual_hash = sha256_file(path) if exists else None
        actual_size = path.stat().st_size if exists else None
        rows.append(
            {
                "file": name,
                "exists": exists,
                "expected_sha256": expected.get("sha256"),
                "actual_sha256": actual_hash,
                "sha256_valid": exists and actual_hash == expected.get("sha256"),
                "expected_size_bytes": expected.get("size_bytes"),
                "actual_size_bytes": actual_size,
                "size_valid": exists and actual_size == expected.get("size_bytes"),
            }
        )
    return {
        "all_valid": all(bool(r["sha256_valid"] and r["size_valid"]) for r in rows),
        "checks": rows,
    }


def load_preflight() -> dict[str, object]:
    path = RESULTS / "preflight_atual.json"
    return json.loads(path.read_text(encoding="utf-8"))


def render_markdown(report: dict[str, object]) -> str:
    pytest = report["pytest"]
    core = report["core_freeze"]
    prereg = report["preregistration"]
    holdout = report["holdout_manifest"]
    preflight = report["dssat_preflight"]

    lines = [
        "# Validação consolidada do Experimento 02B",
        "",
        f"Data: {report['date']}",
        "",
        "## Estado geral",
        "",
        f"- testes Python: **{'OK' if pytest['passed'] else 'FALHA'}**;",
        f"- pré-registros: **{'íntegros' if prereg['all_valid'] else 'divergentes'}**;",
        f"- fixture/templates do holdout: **{'íntegros' if holdout['all_valid'] else 'divergentes'}**;",
        f"- núcleo científico do Hydros em relação ao ZIP-base: **{'inalterado' if core['all_core_identical'] else 'ALTERADO'}**;",
        f"- ambiente DSSAT real: **{'pronto' if preflight.get('ready_for_real_dssat_execution') else 'ainda bloqueado'}**.",
        "",
        "## Testes",
        "",
        "```text",
        pytest["output"],
        "```",
        "",
        "## Congelamento do núcleo",
        "",
    ]
    for row in core["core_files"]:
        lines.append(f"- `{row['file']}`: {'idêntico' if row['identical'] else 'DIVERGENTE'}")

    lines.extend([
        "",
        "Alterações esperadas e limitadas à infraestrutura experimental:",
        "",
    ])
    for row in core["expected_evaluation_differences"]:
        status = "sem alteração" if row["identical"] else "alterado na cópia de trabalho"
        lines.append(f"- `{row['file']}`: {status}.")

    lines.extend([
        "",
        "## Pré-registro",
        "",
    ])
    for row in prereg["checks"]:
        lines.append(
            f"- `{row['file']}`: {'SHA-256 confirmado' if row['valid'] else 'SHA-256 divergente'} "
            f"(`{row['actual_sha256']}`)."
        )

    lines.extend([
        "",
        "## Holdout UFGA8501",
        "",
    ])
    for row in holdout["checks"]:
        ok = row["sha256_valid"] and row["size_valid"]
        lines.append(f"- `{row['file']}`: {'íntegro' if ok else 'DIVERGENTE'}.")

    lines.extend([
        "",
        "## Bloqueio atual para execução DSSAT real",
        "",
    ])
    problems = preflight.get("problems") or []
    if problems:
        for p in problems:
            lines.append(f"- {p}")
    else:
        lines.append("- Nenhum bloqueio detectado pelo preflight.")

    lines.extend([
        "",
        "## Interpretação",
        "",
        "O Experimento 02B está metodologicamente preparado até o ponto em que uma execução real do DSSAT é necessária. "
        "Não foi calculada produtividade, estresse ou eficiência contrafactual sem que a programação Hydros tenha sido realmente simulada.",
        "",
        "A etapa seguinte é executar o preflight em uma instalação DSSAT 4.8.x, validar a leitura dos arquivos de saída diários e, só então, acoplar o backend real ao runner causal fechado.",
        "",
    ])
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--baseline-zip",
        type=Path,
        default=Path("/mnt/data/Hydros(1).zip"),
        help="ZIP-base preservado do Hydros 0.4.1.",
    )
    args = parser.parse_args()

    if not args.baseline_zip.is_file():
        raise SystemExit(f"ZIP-base não encontrado: {args.baseline_zip}")

    report = {
        "date": "2026-08-14",
        "baseline_zip": str(args.baseline_zip),
        "pytest": run_pytest(),
        "core_freeze": compare_core_against_zip(args.baseline_zip),
        "preregistration": verify_preregistration(),
        "holdout_manifest": verify_holdout_manifest(),
        "dssat_preflight": load_preflight(),
    }
    report["ready_until_real_dssat"] = bool(
        report["pytest"]["passed"]
        and report["core_freeze"]["all_core_identical"]
        and report["preregistration"]["all_valid"]
        and report["holdout_manifest"]["all_valid"]
    )

    RESULTS.mkdir(parents=True, exist_ok=True)
    json_path = RESULTS / "validacao_02b_atual.json"
    md_path = RESULTS / "VALIDACAO_02B_ATUAL.md"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    md_path.write_text(render_markdown(report), encoding="utf-8")

    print(json.dumps({
        "ready_until_real_dssat": report["ready_until_real_dssat"],
        "pytest": report["pytest"]["output"],
        "core_unchanged": report["core_freeze"]["all_core_identical"],
        "preregistration_valid": report["preregistration"]["all_valid"],
        "holdout_manifest_valid": report["holdout_manifest"]["all_valid"],
        "dssat_ready": report["dssat_preflight"].get("ready_for_real_dssat_execution"),
        "outputs": [str(json_path), str(md_path)],
    }, indent=2, ensure_ascii=False))

    return 0 if report["ready_until_real_dssat"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
