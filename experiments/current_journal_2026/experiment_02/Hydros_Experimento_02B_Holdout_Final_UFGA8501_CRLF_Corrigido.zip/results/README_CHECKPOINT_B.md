# Estado dos resultados no Checkpoint B

- `results/experimento_1`: **regenerado no Checkpoint B** após separar confiança de criticidade.
- `results/modulo_6_sensibilidade`: preservado do checkpoint anterior, ainda não regenerado.
- `results/experimento_2`: preservado do checkpoint anterior, ainda não regenerado.
- `results/aps_modulo5`: preservado, pois o modelo APS não foi retreinado neste checkpoint.

Os resultados preservados continuam disponíveis para rollback e comparação, mas somente o Experimento I representa o comportamento do código do Checkpoint B.
