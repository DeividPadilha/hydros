# Síntese do Experimento I do Hydros

## Configuração

Foram analisadas **256 observações pareadas** provenientes de **2 execuções DSSAT**. Em cada observação, os dois modos receberam o mesmo contexto atual; apenas o Hydros Histórico teve acesso ao histórico de contextos. A referência operacional apresentou: manter_irrigacao=245, iniciar_irrigacao=11.

## Histórico versus sem Histórico

| Métrica | Hydros Histórico | Hydros sem Histórico |
|---|---:|---:|
| Taxa conclusiva | 0.9922 | 0.9961 |
| Acurácia multiclasse | 0.9492 | 0.9531 |
| F1 macro multiclasse | 0.1948 | 0.1952 |
| Precisão de intensificação | 0.0000 | 0.0000 |
| Recall de intensificação | 0.0000 | 0.0000 |
| F1 de intensificação | 0.0000 | 0.0000 |
| MCC de intensificação | 0.0000 | 0.0000 |

Foram observadas **1 saídas diferentes** entre os modos. Em 0 observações somente o modo Histórico concordou com a referência e em 1 somente o modo sem Histórico concordou. Processamentos inconclusivos foram preservados como inconclusivos e não convertidos artificialmente em uma ação de manejo.

## Interpretação

A comparação isola a disponibilidade da memória temporal mantendo o restante da arquitetura. Assim, diferenças entre as saídas fornecem evidência experimental sobre o efeito do histórico no protótipo. A interpretação deve permanecer descritiva nesta etapa, principalmente porque há apenas duas trajetórias simuladas e o APS atual ainda é legado.

## Limitações

1. O DSSAT é utilizado para construir cenários controlados; a ação de referência não é tratada como verdade agronômica absoluta.
2. O conjunto atual possui apenas duas execuções e cobertura limitada das cinco ações possíveis.
3. Foram registradas 0 saídas de ações que não ocorrem na referência; elas são exploratórias.
4. O APS atual requer retreinamento com separação por trajetórias independentes e com as três classes finais.
5. O Experimento I avalia a contribuição do histórico para as saídas do Hydros. Ele não demonstra, por si só, economia de água, redução de estresse ou ganho de produtividade; esses efeitos pertencem ao Experimento II.
