# Validação consolidada do Experimento 02B

Data: 2026-08-14

## Estado geral

- testes Python: **OK**;
- pré-registros: **íntegros**;
- fixture/templates do holdout: **íntegros**;
- núcleo científico do Hydros em relação ao ZIP-base: **inalterado**;
- ambiente DSSAT real: **ainda bloqueado**.

## Testes

```text
...........................                                              [100%]
27 passed in 2.24s
```

## Congelamento do núcleo

- `src/agents/amdh_agent.py`: idêntico
- `src/agents/aiec_agent.py`: idêntico
- `src/agents/arg_agent.py`: idêntico
- `src/agents/aps_agent.py`: idêntico
- `src/config/hydros_terms.py`: idêntico
- `src/ontology/hydros_onto.py`: idêntico
- `ontology/hydrosonto.owl`: idêntico
- `src/models/aps_random_forest_model.pkl`: idêntico
- `src/models/aps_model_metadata.json`: idêntico
- `src/integrations/dssat_adapter.py`: idêntico

Alterações esperadas e limitadas à infraestrutura experimental:

- `src/evaluation/irrigation_policy.py`: alterado na cópia de trabalho.
- `run_experimento_2.py`: alterado na cópia de trabalho.

## Pré-registro

- `pre_registro_experimento_02b.json`: SHA-256 confirmado (`f392e05d81e6845f29a4da9565ab8825e1f51d73ad2578969202d9351601b727`).
- `pre_registro_experimento_02b_v2.json`: SHA-256 confirmado (`f4e39ffe4066d67795c8555ead2d5917e8befdbde69fde76f5144927fd988a71`).

## Holdout UFGA8501

- `official_UFGA8501.SBX`: íntegro.
- `UFGA8501_REFERENCE_T2.SBX`: íntegro.
- `UFGA8501_HYDROS_TEMPLATE_T2.SBX`: íntegro.
- `pre_registro_experimento_02b_v2.json`: íntegro.

## Bloqueio atual para execução DSSAT real

- DSSAT_HOME não informado
- executável dscsm048/DSCSM048 não encontrado

## Interpretação

O Experimento 02B está metodologicamente preparado até o ponto em que uma execução real do DSSAT é necessária. Não foi calculada produtividade, estresse ou eficiência contrafactual sem que a programação Hydros tenha sido realmente simulada.

A etapa seguinte é executar o preflight em uma instalação DSSAT 4.8.x, validar a leitura dos arquivos de saída diários e, só então, acoplar o backend real ao runner causal fechado.
