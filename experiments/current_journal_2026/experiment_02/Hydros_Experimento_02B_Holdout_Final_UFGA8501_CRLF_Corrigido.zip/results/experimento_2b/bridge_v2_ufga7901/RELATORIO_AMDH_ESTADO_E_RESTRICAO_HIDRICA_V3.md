# Checkpoint Exp02B V3: AMDH sensível ao estado e à elegibilidade hídrica

Data: 2026-08-14
Status: candidato de desenvolvimento, NÃO é resultado final e NÃO usa o holdout UFGA8501.

## Problema confirmado

Depois da correção da ponte DSSAT -> Hydros, o núcleo 0.4.1 ainda mantinha a irrigação desligada em todos os 8 dias de estresse hídrico observados no UFGA7901 T2. A causa não estava mais no mapeamento: quando a irrigação estava inativa, `manter_irrigacao` usava um alvo de criticidade próximo de `atencao`, embora operacionalmente significasse continuar sem irrigar.

Uma primeira correção por estado (`manter_irrigacao=1.0` quando inativa) aumentou a sensibilidade, mas também produziu 25 inícios no T1 irrigado sem estresse DSSAT. Esses falsos inícios eram causados por atenção climática/fenológica/histórica mesmo com Ehid adequada.

## Correção candidata V3

Foram introduzidas duas restrições sem alterar os pesos whc/warg/waps:

1. quando a irrigação está inativa, `manter_irrigacao` representa condição hídrica adequada e usa alvo 1.0;
2. Ehid funciona apenas como restrição operacional de elegibilidade:
   - Ehid adequada + irrigação inativa: `iniciar_irrigacao` fica bloqueada;
   - Ehid atenção + irrigação inativa: `manter` e `iniciar` continuam concorrendo pelo mesmo argmax;
   - Ehid crítica + irrigação inativa: `manter_irrigacao` fica bloqueada.

Ehid não foi adicionada ao escore ponderado do AMDH. O escore permanece baseado em Ehc, Earg e Eaps, preservando a arquitetura híbrida. A restrição apenas impede uma ação que contradiz diretamente a evidência hídrica especializada.

## Testes

- testes específicos de alvo por estado: OK;
- testes específicos de elegibilidade hídrica: OK;
- suíte completa: **40/40 aprovados**;
- nenhuma falha registrada.

## Diagnóstico UFGA7901 após a correção candidata

### T1 irrigado

Período controlado DAP >= 20: 108 dias.

- Ehid: 108 adequada;
- dias DSSAT com estresse >= 0,25: 0;
- ações: 105 manter, 1 finalizar, 2 inconclusivas;
- **inícios indevidos: 0**.

A restrição hídrica eliminou os 25 inícios indevidos observados na versão candidata anterior.

### T2 rainfed

Período controlado DAP >= 20: 108 dias.

- Ehid: 100 adequada, 8 atenção;
- dias DSSAT com estresse >= 0,25: 8;
- ações: 101 manter, 7 iniciar;
- nos 8 dias de estresse: **7 iniciar e 1 manter**;
- escore médio nos dias de estresse: iniciar 0,674225; manter 0,525775.

O único dia de estresse que permaneceu em `manter` é um caso em que Ehid está em atenção, mas Ehc fica adequada. Ele foi mantido como discordância real, em vez de forçar uma regra para obter 8/8.

## Interpretação

O comportamento passou a respeitar melhor a semântica operacional:

- atenção genérica, sem problema hídrico especializado, não liga a irrigação;
- um alerta hídrico real torna o início elegível;
- o AMDH ainda pode decidir manter quando as demais evidências não sustentam suficientemente a mudança.

Isso é um checkpoint de desenvolvimento. Ainda NÃO demonstra economia de água ou produtividade do manejo Hydros, porque a trajetória observada não foi re-simulada com a programação produzida pelo Hydros.

## Próximo teste obrigatório antes do holdout

Executar a mesma versão candidata nos cenários de desenvolvimento pré-registrados UFGA7801 e UFGA8401. O UFGA8501 permanece fechado. Somente depois de avaliar o comportamento nos cenários de desenvolvimento o núcleo poderá ser congelado para o teste final.
