# HYDROS-EXP02B - Ponte DSSAT → Hydros v2

Data: 2026-08-14
Status: desenvolvimento, UFGA7901, não holdout.

## Alterações feitas

A camada experimental foi corrigida sem alterar pesos, limiares, APS, ontologia ou agentes do núcleo Hydros.

- A umidade usada pelo Hydros passou a representar a fração de água extraível na zona radicular, calculada com `SW1D..SW9D`, `LL1D..LL9D`, `DUL1D..DUL9D` e `RDPD`.
- A água disponível usada pelo Hydros passou a ser a fração de água extraível da zona radicular normalizada para a PAWC total do perfil, em mm equivalentes. Os valores físicos brutos permanecem em colunas de auditoria.
- `SWXD` e `SWTD` permanecem preservados como saídas físicas DSSAT, mas não são confundidos com disponibilidade efetiva na zona radicular.
- O estágio fenológico passou a usar `GSTD` e `L#SD` observados no próprio dia, sem consultar datas futuras.
- O Kc não é mais inferido de `ETAA/EOAA`. O bridge usa valores externos de referência por fase e registra a proveniência em coluna própria.
- `produtividade` não recebe mais o rendimento final da safra nos dias anteriores. Usa `GWAD` corrente apenas como proxy causal de massa de grãos acumulada, com a limitação explicitada.
- O estresse diário usa o maior valor entre `WSPD` e `WSGD`, mantendo os valores DSSAT brutos.
- A irrigação diária efetiva é obtida por diferença do `IRRC` cumulativo.

## Verificação

- Testes novos da ponte: 4/4 aprovados.
- Suite completa após a alteração experimental: 31/31 aprovada.
- T1 e T2 continuam com 128 períodos e clima idêntico.
- T1: 85 mm de irrigação efetiva acumulada e 3114 kg/ha de `GWAD` final.
- T2: 0 mm e 3061 kg/ha.

## Resultado do Hydros com o núcleo 0.4.1 inalterado

Após DAP 20:

### T1 irrigado
- `Ehid`: 108 adequada.
- ações: 105 manter, 1 finalizar e 2 inconclusivas.

### T2 rainfed
- 8 dias com estresse DSSAT >= 0,25.
- `Ehid`: 100 adequada e 8 atenção.
- `Earg`: 68 atenção e 40 adequada.
- `Eaps`: 70 atenção e 38 adequada, todos os períodos parcialmente fora do domínio APS.
- ação: 108 vezes `manter_irrigacao`.
- nos 8 dias de estresse DSSAT, a ação também foi `manter_irrigacao`.

## Diagnóstico estrutural após corrigir a ponte

A ponte antiga não era a única causa do resultado. Com a ponte corrigida, o AMDH 0.4.1 ainda favorece `manter_irrigacao` quando a irrigação está inativa e a condição é `atenção`.

O motivo é semântico: o alvo global de `manter_irrigacao` é 1,90, adequado à ideia de manter uma irrigação já ativa sob atenção, mas o mesmo alvo é reutilizado quando a irrigação está inativa. Nesse estado, `manter_irrigacao` significa, na prática, continuar sem irrigar. Portanto, uma evidência de atenção fica numericamente mais próxima de `manter` do que de `iniciar`, cujo alvo é 2,55.

A próxima etapa de desenvolvimento deve tornar o alvo de `manter_irrigacao` dependente do estado operacional. Essa mudança deve ser validada somente em cenários de desenvolvimento e congelada antes do UFGA8501.
