# Comparacao diagnostica UFGA7901 T1 vs T2

- T1: `C:\Users\Padilha\Downloads\hydros_exp02b_checkpoint_2026-08-14\hydros_exp02b_work\results\experimento_2b\dssat_probe\ufga7901_UFGA7901_T1_20260814_102645`
- T2: `C:\Users\Padilha\Downloads\hydros_exp02b_checkpoint_2026-08-14\hydros_exp02b_work\results\experimento_2b\dssat_probe\ufga7901_UFGA7901_T2_20260814_102430`
- Mesmo clima: **True**
- Linhas meteorologicas comparadas: **128**

| Metrica DSSAT | T1 irrigado | T2 rainfed | Delta T1-T2 |
|---|---:|---:|---:|
| IRRC_final | 85 | 0 | 85 |
| PREC_final | 695 | 695 | 0 |
| DRNC_final | 338 | 291 | 47 |
| ROFC_final | 12 | 11 | 1 |
| SWXD_mean | 163.86 | 156.984 | 6.87597 |
| SWXD_min | 126 | 107 | 19 |
| SWXD_final | 126 | 107 | 19 |
| SWTD_mean | 219.078 | 212.24 | 6.83721 |
| SWTD_min | 181 | 162 | 19 |
| SWTD_final | 181 | 162 | 19 |
| WSPD_mean | 0 | 0.0071875 | -0.0071875 |
| WSPD_min | 0 | 0 | 0 |
| WSGD_mean | 0.00159375 | 0.0334766 | -0.0318828 |
| WSGD_min | 0 | 0 | 0 |
| LAID_max | 5.537 | 5.283 | 0.254 |
| GWAD_final | 3114 | 3061 | 53 |
| ETAC_final | 460.71 | 441.98 | 18.73 |
| EPAC_final | 339.48 | 336.74 | 2.74 |
| ESAC_final | 121.23 | 105.24 | 15.99 |
| HWAMS | 3114 | 3061 | 53 |
| HWAMM | -99 | -99 | 0 |

Este arquivo e diagnostico. O UFGA8501 permanece reservado como holdout final.
Os erros de parsing de `OVERVIEW.OUT` e `Summary.OUT` nao afetam esta comparacao, pois estes arquivos nao sao usados aqui.
