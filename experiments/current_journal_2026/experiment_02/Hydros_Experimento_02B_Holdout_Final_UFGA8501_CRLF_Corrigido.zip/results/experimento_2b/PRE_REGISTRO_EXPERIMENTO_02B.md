# Pré-registro interno do Experimento 02B

Data de congelamento: 14/08/2026  
ID: `HYDROS-EXP02B-2026-08-14-v1`

## Objetivo

O Experimento 02B avaliará efeitos agronômicos somente em trajetórias DSSAT que tenham executado de fato a programação de irrigação produzida pelo Hydros. O protocolo causal será `C(t) -> decisão após C(t) -> manejo no intervalo t+1 -> nova simulação DSSAT -> C(t+1)`.

## Separação desenvolvimento e teste

O experimento UFGA7901 permanece como diagnóstico legado. Como seus resultados já foram vistos durante a auditoria, ele não será chamado de holdout cego nem será usado para justificar calibração orientada ao resultado.

Para desenvolvimento da ponte semântica DSSAT/Hydros e da política operacional serão usados UFGA7801 e UFGA8401. O resultado primário de teste foi congelado antecipadamente em UFGA8501, que utiliza a cultivar Cobb e possui tratamentos irrigado e não irrigado. A escolha foi registrada antes de calcular qualquer saída do Hydros sobre esse experimento.

## Regra de não favorecimento

Durante a etapa de mapeamento ficam congelados pesos do AMDH, limiares dos agentes, alvos de criticidade das ações, ontologia e o modelo APS operacional. O holdout UFGA8501 não poderá ser usado para escolher parâmetros. Qualquer mudança futura do APS ou das regras deverá ser justificada em conjunto de desenvolvimento separado e gerar uma nova versão explicitamente registrada.

## Variáveis e proveniência

Os valores físicos vindos do DSSAT serão preservados. Índices derivados para compatibilidade com o domínio sintético do Experimento I terão nomes próprios e nunca substituirão silenciosamente `umidade_solo` ou `agua_disponivel`.

A série `agua_disponivel` do CSV legado é altamente consistente com `SWXD`, água extraível do perfil, mas o CDE de origem não foi registrado no arquivo. A nova extração deverá registrar explicitamente `SWXD`, `SWTD`, água por camada, limites LL/DUL/SAT e profundidade radicular. Isso permitirá distinguir água total do perfil de água efetivamente acessível à zona radicular.

Os rótulos fenológicos textuais do CSV legado não serão convertidos arbitrariamente para V/R. A nova execução deverá preservar o código fenológico DSSAT de origem. A produtividade final também não será reutilizada como se fosse estimativa diária para o Aprod.

## Resultados

Resultados principais: água acumulada de irrigação, produtividade final, número de períodos com estresse, intensidade acumulada do estresse e eficiência do uso da água de irrigação. Drenagem/excesso de água será incluída quando houver saída explícita disponível.

Menor uso de água isoladamente não será considerado sucesso. A comparação reportará todos os deltas, inclusive quando desfavoráveis.

## Fontes oficiais usadas para selecionar os cenários

- Repositório DSSAT `dssat-csm-data`, diretório Soybean.
- UFGA7801: experimento Bragg irrigado e rainfed.
- UFGA8401: experimento Bragg irrigado e rainfed com irrigação tardia.
- UFGA8501: experimento Cobb irrigado e não irrigado.
- UFGA7901: experimento de 1979 já usado no diagnóstico legado.
- Documentação oficial DSSAT sobre manejo de irrigação, que permite eventos observados ou regras automáticas baseadas no estado simulado.
