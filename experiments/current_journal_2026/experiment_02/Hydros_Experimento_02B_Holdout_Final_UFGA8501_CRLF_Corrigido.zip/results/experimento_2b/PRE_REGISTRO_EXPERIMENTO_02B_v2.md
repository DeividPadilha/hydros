# Pré-registro do Experimento 02B, versão 2

Protocolo: `HYDROS-EXP02B-2026-08-14-v2`

SHA-256: `f4e39ffe4066d67795c8555ead2d5917e8befdbde69fde76f5144927fd988a71`

A versão 1 permanece preservada. Esta versão 2 apenas torna explícito o desenho de comparação controlada antes de qualquer resultado do Hydros no holdout UFGA8501.

## Desenho travado

O UFGA8501 permanece como holdout primário. As duas simulações computacionais principais usarão o **tratamento-base 2**. Isso evita atribuir ao Hydros diferenças causadas por outros níveis de fator entre os tratamentos oficiais.

- Prefixo comum de estabelecimento: 85172 = 13 mm e 85175 = 10 mm.
- Ramo de referência: programação oficial do nível de irrigação 1, com 16 eventos e 217.0 mm brutos, transplantada para MI=2.
- Ramo Hydros: mesmo prefixo inicial; depois, decisões causais do Hydros aplicadas apenas ao próximo intervalo e efetivamente reexecutadas no DSSAT.
- O resultado de UFGA8501 não poderá ser usado para recalibrar pesos do AMDH, limiares dos agentes, APS, mapeamento fenológico ou política operacional.

## Contrato de execução

O código oficial do CSM define o modo `C` como execução por linha de comando com arquivo experimental e número do tratamento. O runner local utilizará esse contrato e registrará a versão DSSAT presente nos arquivos de saída.
