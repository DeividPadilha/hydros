"""Experimento II: efeito do Hydros no gerenciamento hídrico.

O experimento procura um par DSSAT com os mesmos fatores exógenos e estratégias
de irrigação distintas. A estratégia de maior irrigação é tratada como manejo
de referência pré-configurado. A trajetória candidata ao Hydros somente é
usada como resultado do Hydros quando a programação produzida pelas ações do
Hydros Histórico coincide integralmente com a irrigação efetivamente simulada
nessa trajetória. Essa verificação evita atribuir ao Hydros resultados de uma
simulação que não executou seu manejo.

Saídas em ``results/experimento_2``.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.evaluation.irrigation_policy import derive_policy_from_reference
from src.evaluation.experiment2_protocol import (
    build_verification_table,
    schedule_from_causal_actions,
    verify_planned_against_simulated,
)
from src.integrations.dssat_adapter import DSSATAdapter


ARQUIVO_CENARIOS = Path("data/hydros_soja_dssat_real_v2.csv")
ARQUIVO_ACOES = Path("results/experimento_1/comparacao_detalhada.csv")
PASTA_SAIDA = Path("results/experimento_2")
COLUNAS_EXOGENAS = [
    "data", "loc", "solo", "cultura", "precipitacao", "temperatura",
    "temp_maxima", "temp_minima", "graus_dia_periodo", "soma_termica_acumulada",
]


def _same_exogenous(a: pd.DataFrame, b: pd.DataFrame) -> bool:
    if len(a) != len(b):
        return False
    for col in COLUNAS_EXOGENAS:
        if col not in a.columns or col not in b.columns:
            return False
        sa = a[col].reset_index(drop=True)
        sb = b[col].reset_index(drop=True)
        if pd.api.types.is_numeric_dtype(sa) and pd.api.types.is_numeric_dtype(sb):
            if not np.allclose(sa.astype(float), sb.astype(float), rtol=0, atol=1e-9, equal_nan=True):
                return False
        elif not sa.astype(str).equals(sb.astype(str)):
            return False
    return True


def selecionar_par(dados_originais: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    grupos = [g.reset_index(drop=True) for _, g in dados_originais.groupby(["cenario", "dssat_run"], sort=False)]
    candidatos = []
    for i, a in enumerate(grupos):
        for b in grupos[i + 1:]:
            if _same_exogenous(a, b):
                ta = float(a["irrigacao_aplicada"].sum())
                tb = float(b["irrigacao_aplicada"].sum())
                reference, hydros_candidate = (a, b) if ta >= tb else (b, a)
                candidatos.append((abs(ta - tb), reference, hydros_candidate))
    if not candidatos:
        raise RuntimeError("Não foi encontrado par DSSAT comparável com fatores exógenos idênticos.")
    candidatos.sort(key=lambda x: x[0], reverse=True)
    _, reference, candidate = candidatos[0]
    meta = {
        "reference_scenario": str(reference.iloc[0]["cenario"]),
        "reference_run": int(reference.iloc[0]["dssat_run"]),
        "candidate_scenario": str(candidate.iloc[0]["cenario"]),
        "candidate_run": int(candidate.iloc[0]["dssat_run"]),
        "same_exogenous_inputs": True,
    }
    return reference, candidate, meta


def carregar_acoes_hydros(candidate: pd.DataFrame) -> pd.DataFrame:
    actions = pd.read_csv(ARQUIVO_ACOES)
    cid = f"{candidate.iloc[0]['cenario']}_run_{candidate.iloc[0]['dssat_run']}"
    g = actions[actions["cenario_id"].astype(str) == cid].copy()
    if g.empty:
        raise RuntimeError(f"Ações do Hydros não encontradas para {cid}.")
    if len(g) != len(candidate):
        raise RuntimeError("Número de ações Hydros difere da trajetória DSSAT candidata.")
    return g.reset_index(drop=True)


def calcular_metricas_trajetoria(df: pd.DataFrame, strategy: str) -> dict[str, Any]:
    water = float(pd.to_numeric(df["irrigacao_aplicada"], errors="coerce").sum())
    productivity = float(pd.to_numeric(df["produtividade"], errors="coerce").iloc[-1])

    if "estresse_hidrico_dssat_original" in df.columns:
        stress = pd.to_numeric(df["estresse_hidrico_dssat_original"], errors="coerce").fillna(0.0)
    else:
        stress = pd.to_numeric(df["estresse_hidrico"], errors="coerce").fillna(0.0)
    stress_periods = int((stress > 0.0).sum())
    stress_acc = float(stress.sum())

    # O conjunto atual não contém variável explícita de drenagem, saturação ou
    # excesso de água. Não é criado um proxy não fundamentado.
    excess_available = False
    excess_periods: int | None = None
    for col in ("excesso_agua", "water_excess", "alagamento"):
        if col in df.columns:
            values = pd.to_numeric(df[col], errors="coerce").fillna(0.0)
            excess_periods = int((values > 0).sum())
            excess_available = True
            break

    iwue = productivity / water if water > 0 else np.nan
    return {
        "estrategia": strategy,
        "n_periodos": int(len(df)),
        "agua_irrigacao_total_mm": round(water, 6),
        "produtividade_final_kg_ha": round(productivity, 6),
        "periodos_com_estresse": stress_periods,
        "intensidade_acumulada_estresse": round(stress_acc, 6),
        "excesso_agua_disponivel_no_dataset": excess_available,
        "periodos_com_excesso_agua": excess_periods,
        "eua_irrigacao_kg_ha_por_mm": round(float(iwue), 6) if np.isfinite(iwue) else np.nan,
    }


def main() -> None:
    PASTA_SAIDA.mkdir(parents=True, exist_ok=True)

    raw = pd.read_csv(ARQUIVO_CENARIOS)
    reference, candidate, meta = selecionar_par(raw)
    policy = derive_policy_from_reference(reference)
    actions = carregar_acoes_hydros(candidate)

    decisions = actions["acao_hydros_historico"].where(
        actions["acao_hydros_historico"].notna(), None
    ).tolist()
    applied_actions, planned = schedule_from_causal_actions(decisions, policy)
    simulated = pd.to_numeric(
        candidate["irrigacao_aplicada"], errors="coerce"
    ).astype(float).tolist()
    dates = candidate["data"].astype(str).tolist()
    verification = verify_planned_against_simulated(
        planned, simulated, dates=dates
    )
    schedule = build_verification_table(
        dates=dates,
        decisions_after_context=decisions,
        applied_actions=applied_actions,
        planned_mm=planned,
        simulated_mm=simulated,
        processing_status=actions["status_processamento_historico"].astype(str).tolist(),
    )
    schedule_match = verification.exact_match

    reference_schedule = reference[["data", "irrigacao_aplicada", "decisao_referencia"]].copy()
    reference_schedule.columns = ["data", "irrigacao_referencia_mm", "acao_referencia"]

    schedule.to_csv(PASTA_SAIDA / "manejo_hydros_verificacao.csv", index=False)
    reference_schedule.to_csv(PASTA_SAIDA / "manejo_referencia.csv", index=False)
    with (PASTA_SAIDA / "politica_operacional.json").open("w", encoding="utf-8") as f:
        json.dump(policy.to_dict(), f, indent=2, ensure_ascii=False)

    meta.update({
        "hydros_schedule_matches_candidate_dssat": schedule_match,
        "planned_hydros_water_mm": round(float(sum(planned)), 6),
        "candidate_dssat_water_mm": round(float(candidate["irrigacao_aplicada"].sum()), 6),
        "reference_water_mm": round(float(reference["irrigacao_aplicada"].sum()), 6),
        "n_inconclusive_hydros": int((schedule["acao_decidida_apos_contexto_t"] == "inconclusivo").sum()),
        "causal_alignment": "C(t)_determina_manejo_do_intervalo_t+1",
        "schedule_verification": verification.to_dict(),
    })

    if schedule_match:
        metrics = pd.DataFrame([
            calcular_metricas_trajetoria(candidate, "Hydros_Historico"),
            calcular_metricas_trajetoria(reference, "Manejo_referencia"),
        ])
        metrics.to_csv(PASTA_SAIDA / "metricas_experimento_2.csv", index=False)

        h = metrics.iloc[0]
        r = metrics.iloc[1]
        comparison = {
            "delta_agua_mm_hydros_menos_referencia": round(float(h["agua_irrigacao_total_mm"] - r["agua_irrigacao_total_mm"]), 6),
            "delta_produtividade_kg_ha_hydros_menos_referencia": round(float(h["produtividade_final_kg_ha"] - r["produtividade_final_kg_ha"]), 6),
            "delta_periodos_estresse_hydros_menos_referencia": int(h["periodos_com_estresse"] - r["periodos_com_estresse"]),
            "delta_intensidade_estresse_hydros_menos_referencia": round(float(h["intensidade_acumulada_estresse"] - r["intensidade_acumulada_estresse"]), 6),
            "resultado_favoravel": bool(
                h["agua_irrigacao_total_mm"] <= r["agua_irrigacao_total_mm"]
                and h["produtividade_final_kg_ha"] >= r["produtividade_final_kg_ha"]
                and h["periodos_com_estresse"] <= r["periodos_com_estresse"]
                and h["intensidade_acumulada_estresse"] <= r["intensidade_acumulada_estresse"]
            ),
            "criterio": "menor_ou_igual_agua_sem_aumentar_estresse_e_sem_reduzir_produtividade",
        }
        pd.DataFrame([comparison]).to_csv(PASTA_SAIDA / "comparacao_experimento_2.csv", index=False)
        meta["effect_metrics_computable"] = True
        meta["result_favorable"] = comparison["resultado_favoravel"]
    else:
        meta["effect_metrics_computable"] = False
        meta["result_favorable"] = None
        meta["blocking_reason"] = verification.reason

    meta["excess_water_metric_note"] = "Indisponível no dataset atual por ausência de variável explícita de excesso/drenagem; nenhum proxy foi inventado."
    meta["scientific_scope"] = "resultado_controlado_de_uma_unica_trajetoria_pareada_nao_generalizavel"
    with (PASTA_SAIDA / "status_experimento_2.json").open("w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)

    print("=== EXPERIMENTO II ===")
    print(json.dumps(meta, indent=2, ensure_ascii=False))
    if schedule_match:
        print("\nMétricas:")
        print(pd.read_csv(PASTA_SAIDA / "metricas_experimento_2.csv").to_string(index=False))
        print("\nComparação:")
        print(pd.read_csv(PASTA_SAIDA / "comparacao_experimento_2.csv").to_string(index=False))
    print(f"\nSaídas: {PASTA_SAIDA.resolve()}")
    print("MODULO 7: OK")


if __name__ == "__main__":
    main()
