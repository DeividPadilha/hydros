"""Teste da integração semântica e rastreável da HydrosOnto oficial."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from src.ontology.hydros_onto import HydrosOnto
from src.services.hydros_engine import HydrosEngine


def validate_result(result: dict, mode: str) -> None:
    inference = result["hydros_onto"]
    trace = result["registro_execucao"]
    arg = result["arg"]

    assert inference["ontology"] == "HydrosOnto"
    assert inference["mode"] == mode
    assert inference["semantic_condition"] in {
        "adequada",
        "atencao",
        "critica",
    }
    assert inference["ontology_class"] in {
        "CondicaoAdequada",
        "CondicaoAtencao",
        "CondicaoCritica",
    }
    assert inference["source_rule"].startswith("Regra_Condicao_")
    assert inference["affects_amdh_score"] is False
    assert inference["consistency"] in {"concordante", "divergente"}
    assert trace["semantic_inferences"]
    assert (
        trace["metadata"]["ontology_integrated"]
        == "semantic_verification_and_traceability"
    )
    assert arg["inferencia_semantica"]["inference_id"] == inference["inference_id"]
    assert arg["impacto_semantico"] == 0.0
    assert result["amdh"]["verificacao_semantica"]["affects_amdh_score"] is False
    json.dumps(trace, ensure_ascii=False)


def main() -> None:
    ontology_file = Path("ontology/hydrosonto.owl")
    assert ontology_file.exists()

    ontology = HydrosOnto()
    assert ontology.validation["minimum_vocabulary_valid"] is True
    assert ontology.validation["rdfxml_syntax_validated"] is True

    dataframe = pd.read_csv("data/historico_contexto_exemplo.csv")
    engine = HydrosEngine()

    historical = engine.processar(dataframe, modo_execucao="historico")
    without_history = engine.processar(dataframe, modo_execucao="sem_historico")

    validate_result(historical, "historico")
    validate_result(without_history, "sem_historico")

    print("\n=== HYDROSONTO ===")
    print("Arquivo:", ontology.validation["path"])
    print("Backend:", ontology.validation["backend"])
    print("RDF/XML validado:", ontology.validation["rdfxml_syntax_validated"])
    print("Condição histórica:", historical["hydros_onto"]["semantic_condition"])
    print("Classe inferida:", historical["hydros_onto"]["ontology_class"])
    print("Regra ontológica:", historical["hydros_onto"]["source_rule"])
    print("Afeta score do AMDH:", historical["hydros_onto"]["affects_amdh_score"])
    print("Rastreabilidade da ação:", historical["rastreabilidade_semantica"]["registered"])
    print("HYDROSONTO: OK")


if __name__ == "__main__":
    main()
