"""Experimento 01B do Hydros: reanálise Histórico vs Sem Histórico com contrato 0.4.1.

Usa o FeatureExtractor da versão 0.4.1, Random Forest idêntico nos dois modos,
divisão por trajetórias do experimento auditado e bootstrap pareado por trajetória.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, matthews_corrcoef

CLASSES = ["adequada", "atencao", "critica"]
CATEGORICAS = ["cultura", "loc", "solo", "estagio_fenologico"]
RANDOM_STATE = 42
N_BOOTSTRAP = 1000


def metricas(y, pred):
    return {
        "accuracy": float(accuracy_score(y, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "f1_macro": float(f1_score(y, pred, labels=CLASSES, average="macro", zero_division=0)),
        "mcc": float(matthews_corrcoef(y, pred)),
    }


def preparar_amostras(base_path: Path, split_path: Path, hydros_root: Path):
    sys.path.insert(0, str(hydros_root))
    from src.services.feature_extractor import FeatureExtractor

    df = pd.read_csv(base_path)
    divisao = pd.read_csv(split_path)
    df["data"] = pd.to_datetime(df["data"])
    df = df.sort_values(["trajetoria_id", "data"], kind="stable").copy()

    # Adequação explícita ao contrato térmico atual da versão 0.4.1.
    df["soma_termica_acumulada"] = df["graus_dia"]
    df["graus_dia_periodo"] = (
        df.groupby("trajetoria_id")["soma_termica_acumulada"].diff()
        .fillna(df["soma_termica_acumulada"])
    )
    df["produtividade"] = df["produtividade_estimada"]
    df["estresse_hidrico"] = df["condicao_hidrica"]

    extrator = FeatureExtractor(tamanho_janela=5)
    registros = []
    for traj, grupo in df.groupby("trajetoria_id", sort=False):
        grupo = grupo.sort_values("data", kind="stable").reset_index(drop=True)
        for i in range(4, len(grupo)):
            janela = grupo.iloc[i - 4 : i + 1]
            atual = grupo.iloc[[i]]
            hist = extrator.extrair(janela).iloc[0].to_dict()
            sem_hist = extrator.extrair(atual).iloc[0].to_dict()
            linha = {
                "trajetoria_id": traj,
                "data": grupo.loc[i, "data"],
                "classe": grupo.loc[i, "condicao_hidrica"],
            }
            linha.update({f"historico__{k}": v for k, v in hist.items()})
            linha.update({f"sem_historico__{k}": v for k, v in sem_hist.items()})
            registros.append(linha)

    dados = pd.DataFrame(registros)
    dados["conjunto"] = dados["trajetoria_id"].map(
        dict(zip(divisao["trajetoria_id"], divisao["conjunto"]))
    )
    return dados, list(extrator.extrair(df.iloc[:5]).columns)


def treinar_e_predizer(dados, features_base, modo):
    prefixo = f"{modo}__"
    colunas = [prefixo + c for c in features_base]
    treino = dados[dados["conjunto"] == "treinamento"].copy()

    encoders = {}
    for c in CATEGORICAS:
        col = prefixo + c
        enc = LabelEncoder()
        enc.fit(treino[col].astype(str))
        encoders[col] = enc

    def transformar(frame):
        x = frame[colunas].copy()
        for col, enc in encoders.items():
            mapa = {str(v): i for i, v in enumerate(enc.classes_)}
            x[col] = x[col].astype(str).map(mapa).fillna(-1).astype(int)
        return x

    modelo = RandomForestClassifier(
        n_estimators=200,
        random_state=RANDOM_STATE,
        class_weight="balanced",
        n_jobs=-1,
    )
    modelo.fit(transformar(treino), treino["classe"])

    saidas = {}
    for conjunto in ["validacao", "teste", "teste_climatico"]:
        alvo = dados[dados["conjunto"] == conjunto].copy()
        alvo["predicao"] = modelo.predict(transformar(alvo))
        saidas[conjunto] = alvo[["trajetoria_id", "data", "classe", "predicao"]]
    return saidas


def bootstrap_pareado(hist, sem_hist, n=N_BOOTSTRAP, seed=RANDOM_STATE):
    pareado = hist.merge(
        sem_hist,
        on=["trajetoria_id", "data", "classe"],
        suffixes=("_historico", "_sem_historico"),
    )
    trajs = pareado["trajetoria_id"].drop_duplicates().to_numpy()
    grupos = {t: g.index.to_numpy() for t, g in pareado.groupby("trajetoria_id", sort=False)}
    y = pareado["classe"].to_numpy()
    ph = pareado["predicao_historico"].to_numpy()
    ps = pareado["predicao_sem_historico"].to_numpy()

    def f1(indices):
        return (
            f1_score(y[indices], ph[indices], labels=CLASSES, average="macro", zero_division=0)
            - f1_score(y[indices], ps[indices], labels=CLASSES, average="macro", zero_division=0)
        )

    rng = np.random.default_rng(seed)
    valores = np.empty(n, dtype=float)
    for i in range(n):
        sorteadas = rng.choice(trajs, size=len(trajs), replace=True)
        idx = np.concatenate([grupos[t] for t in sorteadas])
        valores[i] = f1(idx)
    return {
        "delta_f1": float(f1(np.arange(len(pareado)))),
        "ci95_low": float(np.quantile(valores, 0.025)),
        "ci95_high": float(np.quantile(valores, 0.975)),
        "bootstrap_iterations": int(n),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True, type=Path)
    ap.add_argument("--split", required=True, type=Path)
    ap.add_argument("--hydros-root", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    dados, features = preparar_amostras(args.base, args.split, args.hydros_root)
    pred_h = treinar_e_predizer(dados, features, "historico")
    pred_s = treinar_e_predizer(dados, features, "sem_historico")

    resumo = {
        "metodologia": {
            "versao_hydros": "0.4.1-qualificacao-final",
            "feature_extractor": "FeatureExtractor atual",
            "algoritmo": "RandomForestClassifier",
            "n_estimators": 200,
            "random_state": 42,
            "class_weight": "balanced",
            "janela_historica": 5,
            "amostras": int(len(dados)),
            "trajetorias": int(dados["trajetoria_id"].nunique()),
        },
        "conjuntos": {},
    }
    for conjunto in ["validacao", "teste", "teste_climatico"]:
        h = pred_h[conjunto]
        s = pred_s[conjunto]
        item = {
            "historico": metricas(h["classe"], h["predicao"]),
            "sem_historico": metricas(s["classe"], s["predicao"]),
        }
        if conjunto in {"teste", "teste_climatico"}:
            item["comparacao_pareada"] = bootstrap_pareado(h, s)
        resumo["conjuntos"][conjunto] = item
        h.to_csv(args.out / f"predicoes_historico_{conjunto}.csv", index=False)
        s.to_csv(args.out / f"predicoes_sem_historico_{conjunto}.csv", index=False)

    with (args.out / "resultados.json").open("w", encoding="utf-8") as f:
        json.dump(resumo, f, ensure_ascii=False, indent=2)
    pd.DataFrame([
        {"conjunto": c, "modo": m, **resumo["conjuntos"][c][m]}
        for c in ["validacao", "teste", "teste_climatico"]
        for m in ["historico", "sem_historico"]
    ]).to_csv(args.out / "metricas.csv", index=False)
    print(json.dumps(resumo, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
