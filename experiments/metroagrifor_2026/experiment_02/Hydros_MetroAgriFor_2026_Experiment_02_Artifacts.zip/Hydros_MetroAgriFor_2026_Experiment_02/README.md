# IEEE MetroAgriFor 2026 - Experiment II artifact package

Paper:
Hydros: A Multi-Agent Model for Explainable Irrigation Decision Support Based on Context Histories

This package preserves the DSSAT pilot artifacts corresponding to the MetroAgriFor 2026 evaluation.

Official pilot characteristics:
- 256 daily observations
- 2 DSSAT crop simulations
- 11 irrigation-intensification reference events
- Historical mode detected 4 of 11 events
- Instantaneous mode detected 0 of 11 events
- The pilot was NOT closed loop

Primary input:
data/hydros_soja_dssat_real_v2.csv

Primary execution:
python run_dssat_comparison.py
python diagnostico_resultados.py
python gerar_resultados_artigo.py

Primary outputs:
results/dssat_comparison/

This package must not be confused with the later closed-loop UFGA8501 evaluation
used in the current journal manuscript.
