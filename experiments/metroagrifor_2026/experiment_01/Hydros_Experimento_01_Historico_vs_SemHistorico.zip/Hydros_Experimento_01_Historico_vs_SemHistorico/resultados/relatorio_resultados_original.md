# Relatório automático do experimento

## Modelos selecionados

| modo        | modelo_selecionado   | criterio                 |   f1_macro_validacao |
|:------------|:---------------------|:-------------------------|---------------------:|
| historico   | gradient_boosting    | maior_f1_macro_validacao |             0.899951 |
| instantaneo | gradient_boosting    | maior_f1_macro_validacao |             0.814274 |

## Métricas dos modelos selecionados

| modo        | modelo            | conjunto        |    n |   acuracia |   acuracia_balanceada |   precisao_macro |   revocacao_macro |   f1_macro |      mcc |
|:------------|:------------------|:----------------|-----:|-----------:|----------------------:|-----------------:|------------------:|-----------:|---------:|
| historico   | gradient_boosting | validacao       | 1008 |   0.91369  |              0.883559 |         0.918686 |          0.883559 |   0.899951 | 0.834349 |
| historico   | gradient_boosting | teste           | 1008 |   0.927579 |              0.908752 |         0.940546 |          0.908752 |   0.923464 | 0.870754 |
| historico   | gradient_boosting | teste_climatico | 1008 |   0.9375   |              0.920513 |         0.923669 |          0.920513 |   0.920275 | 0.868152 |
| instantaneo | gradient_boosting | validacao       | 1008 |   0.808532 |              0.796041 |         0.835777 |          0.796041 |   0.814274 | 0.632355 |
| instantaneo | gradient_boosting | teste           | 1008 |   0.781746 |              0.794585 |         0.837048 |          0.794585 |   0.813306 | 0.609309 |
| instantaneo | gradient_boosting | teste_climatico | 1008 |   0.862103 |              0.838328 |         0.770507 |          0.838328 |   0.785637 | 0.728797 |

## Intervalos de confiança por bootstrap de trajetórias

| modo        | modelo            | conjunto        | metrica             |   estimativa |   ic95_inferior |   ic95_superior |   iteracoes | unidade_reamostragem   |
|:------------|:------------------|:----------------|:--------------------|-------------:|----------------:|----------------:|------------:|:-----------------------|
| historico   | gradient_boosting | teste           | f1_macro            |     0.923464 |        0.760247 |        0.946455 |        1000 | trajetoria             |
| historico   | gradient_boosting | teste           | acuracia_balanceada |     0.908752 |        0.732512 |        0.93713  |        1000 | trajetoria             |
| historico   | gradient_boosting | teste_climatico | f1_macro            |     0.920275 |        0.868379 |        0.946542 |        1000 | trajetoria             |
| historico   | gradient_boosting | teste_climatico | acuracia_balanceada |     0.920513 |        0.845291 |        0.954864 |        1000 | trajetoria             |
| instantaneo | gradient_boosting | teste           | f1_macro            |     0.813306 |        0.635347 |        0.842712 |        1000 | trajetoria             |
| instantaneo | gradient_boosting | teste           | acuracia_balanceada |     0.794585 |        0.607548 |        0.833949 |        1000 | trajetoria             |
| instantaneo | gradient_boosting | teste_climatico | f1_macro            |     0.785637 |        0.72506  |        0.827933 |        1000 | trajetoria             |
| instantaneo | gradient_boosting | teste_climatico | acuracia_balanceada |     0.838328 |        0.777384 |        0.885809 |        1000 | trajetoria             |

## Diferença pareada entre os modos

| conjunto        | metrica             |   diferenca_historico_menos_instantaneo |   ic95_inferior |   ic95_superior |   proporcao_bootstrap_diferenca_positiva |   iteracoes | unidade_reamostragem   |
|:----------------|:--------------------|----------------------------------------:|----------------:|----------------:|-----------------------------------------:|------------:|:-----------------------|
| teste           | f1_macro            |                                0.110157 |       0.0748821 |        0.14914  |                                    0.999 |        1000 | trajetoria_pareada     |
| teste           | acuracia_balanceada |                                0.114167 |       0.0724423 |        0.159805 |                                    0.997 |        1000 | trajetoria_pareada     |
| teste_climatico | f1_macro            |                                0.134639 |       0.102687  |        0.165014 |                                    1     |        1000 | trajetoria_pareada     |
| teste_climatico | acuracia_balanceada |                                0.082185 |       0.0370531 |        0.112558 |                                    0.999 |        1000 | trajetoria_pareada     |

> Os resultados provêm de dados sintéticos e não constituem validação agronômica em campo.